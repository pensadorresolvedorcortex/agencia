=== Blog Privilége ===
Contributors: Blog Privilége
Tags: blog, posts automáticos, wordpress, woocommerce, marketing digital
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later

== Descrição ==
Blog Privilége é um plugin autônomo para WordPress que cria automaticamente posts publicados para blog.

Funcionalidades:
- Cria 1 post a cada 2 minutos via WP-Cron.
- Publica imediatamente os posts.
- Usa as categorias Notícias, Tendências ou Dicas.
- Adiciona 30 tags pertinentes ao tema.
- Gera títulos com no máximo 50 caracteres.
- Gera slugs longos e descritivos.
- Gera conteúdo entre 3.000 e 5.000 caracteres.
- Usa motor editorial com variações por semente, público, cenário, ângulo, métrica, objeção e checklist.
- Mantém histórico anti-repetição de títulos, conteúdos completos e frases longas.
- Gera imagem destacada 1920x1080.
- Prioriza fotos humanizadas por busca externa sem chave de API.
- Possui fallback local humanizado caso a busca externa falhe.

== Imagens ==
A versão 1.1.0 tenta obter fotografias humanizadas relacionadas ao tema, sem exigir chave de API ou configuração no WordPress.
Quando a busca externa não está disponível, o plugin gera uma imagem local 1920x1080 com composição humanizada, sem textos, sem ícones e sem vetores temáticos.

== Observações importantes ==
O plugin não exige chave de API, cadastro ou configuração obrigatória.
A busca externa de imagens depende da conectividade HTTP do servidor.
O fallback local de imagem depende da extensão PHP GD.
O WP-Cron depende de acessos ao site; em sites com pouco tráfego, a execução pode atrasar.

== Instalação ==
1. Acesse o painel do WordPress.
2. Vá em Plugins > Adicionar novo > Enviar plugin.
3. Envie o arquivo blog-privilege.zip.
4. Ative o plugin.
5. Acesse o menu Blog Privilége para acompanhar status, gerar um post manualmente, pausar, retomar, recriar agendamento ou limpar o histórico anti-repetição.

== Temas usados ==
O plugin trabalha com temas ligados a WordPress, WooCommerce, e-commerce, SEO, marketing digital, tráfego pago, social media, copywriting, UX/UI, segurança, analytics, automação e tendências de web design.
