
🚀 EXTREME PERFORMANCE v8.0 - MOBILE KILLER EDITION
=====================================================

FOCO: Elevar mobile de 75% para 95+ mantendo desktop em 95%

INSTALAÇÃO:
-----------
1. Extraia em /wp-content/mu-plugins/
2. Estrutura resultante:
   /wp-content/mu-plugins/
   ├── 000-privilege-site-controller.php (EXISTENTE)
   └── privilege-site-controller/
       └── modules/
           └── extreme-performance-mobile-killer-v8.php ← NOVO!

OTIMIZAÇÕES CRÍTICAS MOBILE:
----------------------------
✅ Preload LCP image com fetchpriority="high"
✅ Remove lazy da PRIMEIRA imagem (LCP killer)
✅ Critical CSS específico mobile (320-768px)
✅ Font preload + font-display:swap EXTREMO
✅ GTranslate delay 3s no mobile apenas
✅ CLS killer mobile-specific (contain, aspect-ratio)
✅ TBT reducer - throttle JS no mobile
✅ Image dimensions FORÇADAS (extraídas da URL ou default)
✅ Lazy iframes não-críticos
✅ Content-visibility auto elementos n+4
✅ Remove jQuery Migrate (85KB economia)
✅ Dequeue Gutenberg se não usado
✅ Minificação HTML agressiva
✅ Preconnect inteligente domínios críticos

MÉTRICAS ESPERADAS:
-------------------
Mobile: 75% → 95-100% ✅
Desktop: 95% → 96-100% ✅

LCP Mobile: ~3.5s → <2.0s
CLS Mobile: ~0.15 → <0.05
TBT Mobile: ~500ms → <200ms

PROBLEMAS RESOLVIDOS DO MOBILE 75%:
-----------------------------------
1. LCP alto → Preload + fetchpriority high na 1a imagem
2. CLS → contain:strict + dimensões forçadas
3. TBT → requestIdleCallback throttled no mobile
4. Font loading → font-display:swap + preload woff2
5. GTranslate bloqueante → delay 3s no mobile
6. Imagens sem dimensão → extraídas da URL ou default 800x450
7. JS não crítico → defer até window.load
8. Gutenberg CSS → dequeue se não usa blocks

CONFIGURAÇÃO FLYINGPRESS RECOMENDADA:
-------------------------------------
✅ Remove Unused CSS: ATIVO (crítico!)
✅ Minify CSS: Ativo
✅ Minify JS: Ativo  
✅ Delay JS Execution: Ativo
✅ Preload Critical Images: Ativo
✅ Lazy Background Images: Ativo

GAMBIRRAS CRIATIVAS INCLUÍDAS:
------------------------------
- Aspect-ratio via CSS contain para evitar reflow
- Content-visibility com contain-intrinsic-size
- RequestIdleCallback throttled para 1ms no mobile
- GTranslate delayed 3s APENAS em mobile detectado
- First image decoding="sync" + fetchpriority="high"
- Dimensões extraídas da URL (/800x600/) ou fallback
- Minificação HTML remove comentários + espaços
