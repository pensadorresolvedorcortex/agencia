<?php

/*----------------------------------------------------
SHORTHAND CONTANTS FOR THEME VERSION
-----------------------------------------------------*/
if ( site_url() === 'http://brandberry.local/' ) {
    define( 'BRANDBERRY_VERSION', time() );
} else {
    define( 'BRANDBERRY_VERSION', '1.0.1' );
    
}

/*----------------------------------------------------
SHORTHAND CONTANTS FOR THEME ASSETS URL
-----------------------------------------------------*/
define( 'BRANDBERRY_THEME_URI', get_template_directory_uri() );
define( 'BRANDBERRY_ASSETS', BRANDBERRY_THEME_URI . '/assets/' );
define( 'BRANDBERRY_IMG', BRANDBERRY_THEME_URI . '/assets/imgs' );
define( 'BRANDBERRY_CSS', BRANDBERRY_THEME_URI . '/assets/css' );
define( 'BRANDBERRY_JS', BRANDBERRY_THEME_URI . '/assets/js' );

/*----------------------------------------------------
SHORTHAND CONTANTS FOR THEME ASSETS DIRECTORY PATH
-----------------------------------------------------*/
define( 'BRANDBERRY_THEME_DIR', get_template_directory() );
define( 'BRANDBERRY_IMG_DIR', BRANDBERRY_THEME_DIR . '/assets/imgs' );
define( 'BRANDBERRY_CSS_DIR', BRANDBERRY_THEME_DIR . '/assets/css' );
define( 'BRANDBERRY_JS_DIR', BRANDBERRY_THEME_DIR . '/assets/js' );

if (! defined('BRANDBERRY_PRODUCT_DOMAIN')) {
  define('BRANDBERRY_PRODUCT_DOMAIN', 'https://member.treethemes.com/');
}

if (! defined('BRANDBERRY_TOKEN_ID')) {
  define('BRANDBERRY_TOKEN_ID', 'token_1765969152834');
}

if (! defined('BRANDBERRY_PARENT_PAGE_SLUG')) {
  define('BRANDBERRY_PARENT_PAGE_SLUG', 'wcf-brandberry-theme-parent');
}

if(! defined('BRANDBERRY_TPL_SLUG')){
  define('BRANDBERRY_TPL_SLUG', 'brandberry');
}

/*----------------------------------------------------
LOAD Classes
-----------------------------------------------------*/
if ( file_exists( dirname( __FILE__ ) . '/app/loader.php' ) ):
    require_once dirname( __FILE__ ) . '/app/loader.php';    
endif;
/*----------------------------------------------------
SET UP THE CONTENT WIDTH VALUE BASED ON THE THEME'S DESIGN
-----------------------------------------------------*/
if ( !isset( $content_width ) ) {
    $content_width = 800;
}

add_filter( 'use_block_editor_for_post', '__return_false' );

// Disable Gutenberg for widgets.
add_filter( 'use_widgets_block_editor', '__return_false' );


//Woocommerce Supports
function brandberry_add_woocommerce_support() {
  add_theme_support( 'woocommerce', array(
    'thumbnail_image_width' => 350,
    'single_image_width'    => 350,
    'product_grid'          => array(
      'default_rows'    => 3,
      'min_rows'        => 2,
      'max_rows'        => 8,
      'default_columns' => 4,
      'min_columns'     => 2,
      'max_columns'     => 5,
    ),
  ) );

  add_theme_support( 'wc-product-gallery-zoom' );
  add_theme_support( 'wc-product-gallery-lightbox' );
  add_theme_support( 'wc-product-gallery-slider' );


}

add_action( 'after_setup_theme', 'brandberry_add_woocommerce_support' );

use Elementor\Plugin;

class Brandberry_Elementor_Compatibility {

    public static function get_site_settings_link() {

        if ( ! class_exists( '\Elementor\Plugin' ) ) {
            return false;
        }

        $kit_id = Plugin::$instance->kits_manager->get_active_id();

        if ( ! $kit_id ) {
            return false;
        }

        return admin_url(
            'post.php?post=' . absint( $kit_id ) . '&action=elementor#site-settings'
        );
    }
}


/**
 * Find option value even if cs_get_option() returns null on frontend.
 * (Caches the discovered option_name in a static var to avoid repeated work.)
 */
function bb_get_option_anywhere($key, $default = null) {
    // 1) Try Codestar first
    if (function_exists('cs_get_option')) {
        $v = cs_get_option($key);
        if ($v !== null) return $v;
    }

    // 2) Search wp_options for a serialized array containing this key
    static $cached_option_name = null;

    if ($cached_option_name) {
        $all = get_option($cached_option_name);
        if (is_array($all) && array_key_exists($key, $all)) {
            return $all[$key];
        }
    }

    global $wpdb;
    $like = '%' . $wpdb->esc_like($key) . '%';

    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT option_name, option_value
             FROM {$wpdb->options}
             WHERE option_value LIKE %s
             LIMIT 50",
            $like
        )
    );

    foreach ($rows as $r) {
        $val = maybe_unserialize($r->option_value);
        if (is_array($val) && array_key_exists($key, $val)) {
            $cached_option_name = $r->option_name;
            return $val[$key];
        }
    }

    return $default;
}

function bb_to_bool($raw, $default = true): bool {
    if ($raw === null) return $default;
    if (is_bool($raw)) return $raw;
    if (is_int($raw)) return $raw === 1;
    if (is_string($raw)) {
        $v = strtolower(trim($raw));
        if (in_array($v, ['1','true','yes','on'], true)) return true;
        if (in_array($v, ['0','false','no','off',''], true)) return false;
    }
    return (bool) intval($raw);
}

function mytheme_enqueue_lines_script() {
  
  // Plugin not active → constant not defined → do nothing
    if ( ! defined( 'BRANDBERRY_ESSENTIAL_OPTION_KEY' ) ) {
        return;
    }
    
    $options = get_option( BRANDBERRY_ESSENTIAL_OPTION_KEY );

    // Only load JS if the switch is ON
    if ( empty( $options['show_lines_pattern'] ) ) {
        return;
    }

    wp_enqueue_script(
        'mytheme-lines-pattern',
        get_stylesheet_directory_uri() . '/assets/js/lines-pattern.js',
        array( 'jquery' ),
        '1.0',
        true
    );
}
add_action( 'wp_enqueue_scripts', 'mytheme_enqueue_lines_script' );

function brandberry_is_elementor_editor_context(): bool {
  $is_admin_editor   = is_admin() && isset($_GET['action']) && $_GET['action'] === 'elementor';
  $is_preview_iframe = isset($_GET['elementor-preview']);
  return $is_admin_editor || $is_preview_iframe;
}

function brandberry_is_elementor_preview_iframe(): bool {
  return isset($_GET['elementor-preview']);
}

function brandberry_opt(string $id, bool $default = true): bool {
    
    if (function_exists('csf_get_option')) {
    $val = csf_get_option(BRANDBERRY_ESSENTIAL_OPTION_KEY, $id);
    if ($val === null || $val === '') return $default;
    return (bool) $val;
  }
  return $default;
}


function brandberry_dequeue_aae_gsap_libs_in_editor() {
  if (!brandberry_is_elementor_preview_iframe()) return;
  if (!brandberry_opt('disable_gsap_on_elementor_editor', true)) return;

  if (empty($GLOBALS['wp_scripts']) || empty($GLOBALS['wp_scripts']->queue)) return;

  $targets = ['gsap', 'scrolltrigger', 'scrollsmoother', 'splittext', 'scrolltoplugin'];

  foreach ($GLOBALS['wp_scripts']->queue as $handle) {
    $src = $GLOBALS['wp_scripts']->registered[$handle]->src ?? '';
    if (!$src) continue;

    // Only Animation Addons PRO
    if (strpos($src, '/wp-content/plugins/animation-addons-for-elementor-pro/') === false) continue;

    $lower = strtolower($src);
    foreach ($targets as $t) {
      if (strpos($lower, $t) !== false) {
        wp_dequeue_script($handle);
        wp_deregister_script($handle);
        break;
      }
    }
  }
}

// Run late enough (Elementor + AA enqueue late)
add_action('elementor/frontend/after_enqueue_scripts', 'brandberry_dequeue_aae_gsap_libs_in_editor', 9999);
add_action('wp_print_scripts', 'brandberry_dequeue_aae_gsap_libs_in_editor', 9999);


add_filter('pre_http_request', function ($pre, $args, $url) {

  if (!brandberry_is_elementor_editor_context()) return $pre;
  if (!brandberry_opt('block_aa_fingerprint_editor', true)) return $pre;

  if (stripos($url, 'animation-addons.com/wp-json/live/v1/fingerprint/') !== false) {
    return new WP_Error('brandberry_blocked_fingerprint', 'Blocked fingerprint request in Elementor editor.');
  }

  return $pre;

}, 10, 3);


add_filter('pre_http_request', function ($pre, $args, $url) {

  if (!brandberry_is_elementor_editor_context()) return $pre;
  if (!brandberry_opt('cache_member_templates_editor', true)) return $pre;

  if (stripos($url, 'member.treethemes.com/wp-json/templates/') === false) return $pre;

  $method = strtoupper($args['method'] ?? 'GET');
  if ($method !== 'GET') return $pre;

  $key = 'brandberry_tpl_' . md5($url);
  $cached = get_transient($key);

  if ($cached !== false) {
    return $cached; // Must be WP HTTP response array
  }

  return $pre;

}, 10, 3);
if ( ! defined( 'WP_DEBUG' ) || WP_DEBUG === false ) {
  // Production-safe: do nothing
}
add_filter('http_response', function ($response, $args, $url) {

  if (stripos($url, 'member.treethemes.com/wp-json/templates/') === false) return $response;

  $method = strtoupper($args['method'] ?? 'GET');
  if ($method !== 'GET') return $response;

  if (!brandberry_opt('cache_member_templates_editor', true)) return $response;

  $code = (int) wp_remote_retrieve_response_code($response);
  if ($code >= 200 && $code < 300) {
    $key = 'brandberry_tpl_' . md5($url);
    set_transient($key, $response, 12 * HOUR_IN_SECONDS);
  }

  return $response;

}, 10, 3);

/* Preview templates on a clean template */
add_filter('template_include', function ($template) {
  if (is_user_logged_in() && !empty($_GET['elementor_library'])) {
    $custom = get_stylesheet_directory() . '/page-templates/elementor-library-preview.php';
    if (file_exists($custom)) return $custom;
  }
  return $template;
}, 99);
/**
 * WhatsApp flutuante sem corte no ícone
 * PlayBrand
 */
function playbrand_whatsapp_flutuante() {

	if ( is_admin() ) {
		return;
	}

	$whatsapp_url = 'https://api.whatsapp.com/send?phone=5511946622098&text=Acessei%20o%20site%20e%20gostaria%20de%20mais%20informa%C3%A7%C3%B5es%20sobre...';

	$icone_url = 'https://criacaositessaopaulo.com.br/wp-content/uploads/2026/07/whatsapp-1-1.png';
	?>

	<a
		id="playbrand-whatsapp-flutuante"
		href="<?php echo esc_url( $whatsapp_url ); ?>"
		target="_blank"
		rel="noopener noreferrer"
		aria-label="Fale com a PlayBrand pelo WhatsApp"
		title="Fale conosco pelo WhatsApp"
	>
		<span
			class="playbrand-whatsapp-icone"
			aria-hidden="true"
			style="background-image: url('<?php echo esc_url( $icone_url ); ?>');"
		></span>
	</a>

	<style>
		#playbrand-whatsapp-flutuante {
			position: fixed !important;
			right: calc(26px + env(safe-area-inset-right, 0px)) !important;
			bottom: calc(26px + env(safe-area-inset-bottom, 0px)) !important;
			z-index: 9999999 !important;

			display: grid !important;
			place-items: center !important;

			width: 76px !important;
			height: 76px !important;
			margin: 0 !important;
			padding: 0 !important;

			border: 0 !important;
			border-radius: 50% !important;
			background: transparent !important;
			box-shadow: none !important;

			overflow: visible !important;
			text-decoration: none !important;
			box-sizing: border-box !important;
			cursor: pointer !important;
		}

		#playbrand-whatsapp-flutuante {
	position: fixed !important;
	right: calc(34px + env(safe-area-inset-right, 0px)) !important;
	bottom: calc(34px + env(safe-area-inset-bottom, 0px)) !important;
	z-index: 9999999 !important;

	display: grid !important;
	place-items: center !important;

	width: 76px !important;
	height: 76px !important;
	margin: 0 !important;
	padding: 0 !important;

	border: 0 !important;
	border-radius: 50% !important;
	background: transparent !important;
	box-shadow: none !important;

	overflow: visible !important;
	text-decoration: none !important;
	box-sizing: border-box !important;
	cursor: pointer !important;

	isolation: isolate !important;
}

/* Pulso começa afastado do ícone */
#playbrand-whatsapp-flutuante::before {
	content: "";
	position: absolute;

	/*
	 * O valor negativo aumenta o círculo inicial.
	 * O ícone possui 60px e o pulso começa com 92px.
	 */
	inset: -8px !important;

	z-index: 0;
	border-radius: 50%;
	border: 2px solid rgba(37, 211, 102, 0.58);

	opacity: 0;
	transform: scale(1);

	animation: playbrandWhatsappPulse 2.4s ease-out infinite;
	pointer-events: none;
}

/* Mantém o ícone sempre acima da animação */
#playbrand-whatsapp-flutuante .playbrand-whatsapp-icone {
	position: relative !important;
	z-index: 2 !important;

	display: block !important;
	width: 60px !important;
	height: 60px !important;

	background-repeat: no-repeat !important;
	background-position: center !important;
	background-size: contain !important;

	border-radius: 50% !important;
	filter: drop-shadow(0 8px 14px rgba(0, 0, 0, 0.28));

	transform: translateZ(0);
	transition:
		transform 0.25s ease,
		filter 0.25s ease;

	pointer-events: none !important;
}

@keyframes playbrandWhatsappPulse {
	0% {
		opacity: 0.75;
		transform: scale(1);
	}

	70% {
		opacity: 0;
		transform: scale(1.48);
	}

	100% {
		opacity: 0;
		transform: scale(1.48);
	}
}

@media (max-width: 768px) {
	#playbrand-whatsapp-flutuante {
		right: calc(28px + env(safe-area-inset-right, 0px)) !important;
		bottom: calc(28px + env(safe-area-inset-bottom, 0px)) !important;
		width: 70px !important;
		height: 70px !important;
	}

	#playbrand-whatsapp-flutuante .playbrand-whatsapp-icone {
		width: 56px !important;
		height: 56px !important;
	}

	#playbrand-whatsapp-flutuante::before {
		inset: -8px !important;
	}
}

@media (prefers-reduced-motion: reduce) {
	#playbrand-whatsapp-flutuante::before {
		animation: none !important;
		display: none !important;
	}
}
		#playbrand-whatsapp-flutuante .playbrand-whatsapp-icone {
			display: block !important;

			width: 60px !important;
			height: 60px !important;

			background-repeat: no-repeat !important;
			background-position: center !important;
			background-size: contain !important;

			border-radius: 50% !important;
			filter: drop-shadow(0 8px 14px rgba(0, 0, 0, 0.28));

			transform: translateZ(0);
			transition:
				transform 0.25s ease,
				filter 0.25s ease;

			pointer-events: none !important;
		}

		#playbrand-whatsapp-flutuante:hover .playbrand-whatsapp-icone {
			transform: translateY(-3px) scale(1.07);
			filter: drop-shadow(0 12px 18px rgba(0, 0, 0, 0.34));
		}

		#playbrand-whatsapp-flutuante:focus-visible {
			outline: 3px solid #ffffff !important;
			outline-offset: 3px !important;
		}

		@keyframes playbrandWhatsappPulse {
			0% {
				opacity: 0.8;
				transform: scale(0.88);
			}

			70% {
				opacity: 0;
				transform: scale(1.35);
			}

			100% {
				opacity: 0;
				transform: scale(1.35);
			}
		}

		@media (max-width: 768px) {
			#playbrand-whatsapp-flutuante {
				right: calc(18px + env(safe-area-inset-right, 0px)) !important;
				bottom: calc(18px + env(safe-area-inset-bottom, 0px)) !important;

				width: 70px !important;
				height: 70px !important;
			}

			#playbrand-whatsapp-flutuante .playbrand-whatsapp-icone {
				width: 56px !important;
				height: 56px !important;
			}
		}

		@media (prefers-reduced-motion: reduce) {
			#playbrand-whatsapp-flutuante::before {
				animation: none !important;
			}

			#playbrand-whatsapp-flutuante .playbrand-whatsapp-icone {
				transition: none !important;
			}
		}
	</style>

	<?php
}

add_action( 'wp_footer', 'playbrand_whatsapp_flutuante', 999 );
/**
 * Força header branco na página ID 90
 */
add_filter('body_class', function ($classes) {

    if (is_page(90)) {
        $classes[] = 'header-branco-forcado';
    }

    return $classes;

});
/**
 * PlayBrand — SEO técnico e on-page da página inicial
 * URL-alvo: https://criacaositessaopaulo.com.br/
 * Foco: Criação de Sites e Social Media em São Paulo
 * Versão: 1.1 — 07/08/2026
 *
 * Instalação:
 * 1) Preferencialmente use um tema-filho ou o plugin Code Snippets.
 * 2) Cole este arquivo sem duplicar a abertura "<?php".
 * 3) Limpe todos os caches e regenere o CSS do Elementor.
 *
 * Compatibilidade:
 * - Integra-se ao grafo e às metatags do Yoast SEO quando ele está ativo.
 * - Sem Yoast e sem outro plugin de SEO conhecido, usa um fallback próprio.
 * - Não use simultaneamente com Rank Math, AIOSEO ou SEOPress sem adaptar
 *   os filtros específicos desses plugins.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Configuração central.
 *
 * Preencha endereço/geo somente se existir um escritório físico real em São Paulo.
 * Sem endereço físico, o código mantém Organization e usa areaServed, sem fingir
 * que a empresa é um LocalBusiness em São Paulo.
 *
 * @return array<string,mixed>
 */
function playbrand_sp_seo_config() {
    static $config = null;

    if ( null !== $config ) {
        return $config;
    }

    $config = array(
        'brand_name'       => 'PlayBrand',
        // Preencha somente se existir um nome alternativo realmente usado pela marca.
        'alternate_name'   => '',
        'title'            => 'Criação de Sites e Social Media em São Paulo | PlayBrand',
        'description'      => 'Criação de sites e Social Media em São Paulo para empresas que querem crescer. Sites profissionais, gestão de redes sociais, SEO e estratégia digital.',
        'organization_description' => 'A PlayBrand é uma agência digital especializada em criação e desenvolvimento de sites, e-commerce, Social Media, branding, SEO e experiências digitais para empresas em São Paulo.',
        'language'         => 'pt-BR',
        'locale'           => 'pt_BR',
        'home_url'         => trailingslashit( home_url( '/' ) ),
        'services_url'     => trailingslashit( home_url( '/solucoes/' ) ),
        'portfolio_url'    => trailingslashit( home_url( '/portfolio/' ) ),
        'budget_url'       => trailingslashit( home_url( '/orcamentos/' ) ),
        'blog_url'         => trailingslashit( home_url( '/blog/' ) ),

        // Imagens atualmente existentes no site analisado.
        'logo_url'         => home_url( '/wp-content/uploads/2026/03/logo.png' ),
        'logo_width'       => 1837,
        'logo_height'      => 377,
        'og_image_url'     => home_url( '/wp-content/uploads/2026/03/refresh-her.webp' ),
        'og_image_width'   => 1600,
        'og_image_height'  => 900,
        'og_image_type'    => 'image/webp',
        'hero_desktop'     => home_url( '/wp-content/uploads/2026/03/refresh-her.webp' ),
        'hero_mobile'      => home_url( '/wp-content/uploads/2026/03/refresh-hero-mobile.webp' ),

        // Telefone encontrado no botão de WhatsApp da página atual.
        // Corrija aqui caso esse número não pertença à PlayBrand.
        'telephone'        => '+5532988167666',
        'email'            => '',
        'whatsapp_url'     => 'https://wa.me/5532988167666?text=' . rawurlencode( 'Acessei o site e gostaria de informações sobre criação de sites e Social Media.' ),

        'same_as'          => array(
            'https://www.instagram.com/playbrandoficial/',
            // Adicione o LinkedIn oficial quando a URL real estiver disponível.
        ),

        // Deixe vazio se não houver escritório físico real.
        'address'          => array(
            'streetAddress'   => '',
            'addressLocality' => '',
            'addressRegion'   => '',
            'postalCode'      => '',
            'addressCountry'  => 'BR',
        ),
        'geo'              => array(
            'latitude'  => '',
            'longitude' => '',
        ),

        // Verificações: deixe vazio quando já configurado no plugin de SEO.
        'google_site_verification' => '',
        'bing_site_verification'   => '',

        // Recursos automáticos deste módulo.
        'append_visible_seo_content' => true,
        // O Google não oferece mais resultado rico de FAQ para sites comerciais;
        // mantenha false, salvo necessidade específica de outro consumidor Schema.org.
        'add_faq_schema'              => false,
        'fix_elementor_headings'     => true,
        'clean_internal_nofollow'    => true,
        'fix_theme_demo_links'       => true,
        'optimize_image_attributes'  => true,
        'preload_hero_images'        => true,
        'disable_mobile_bg_video'    => true,
        'clean_head'                 => true,
    );

    /**
     * Permite alterar a configuração sem editar esta função.
     *
     * @param array<string,mixed> $config Configuração.
     */
    $config = apply_filters( 'playbrand_sp_seo_config', $config );

    return $config;
}

/**
 * Retorna true somente na home pública.
 */
function playbrand_sp_is_home_request() {
    return ! is_admin() && ! is_feed() && ! is_embed() && is_front_page();
}

/**
 * Evita anexar conteúdo estático dentro do editor/preview do Elementor.
 */
function playbrand_sp_is_elementor_preview() {
    if ( isset( $_GET['elementor-preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        return true;
    }

    if ( class_exists( '\Elementor\Plugin' ) ) {
        $plugin = \Elementor\Plugin::$instance;

        if ( isset( $plugin->editor ) && method_exists( $plugin->editor, 'is_edit_mode' ) && $plugin->editor->is_edit_mode() ) {
            return true;
        }
    }

    return false;
}

/**
 * Detecta o Yoast SEO.
 */
function playbrand_sp_has_yoast() {
    return defined( 'WPSEO_VERSION' )
        || class_exists( 'WPSEO_Options' )
        || class_exists( '\Yoast\WP\SEO\Main' );
}

/**
 * Detecta plugins de SEO não integrados por este snippet.
 */
function playbrand_sp_has_other_seo_plugin() {
    return defined( 'RANK_MATH_VERSION' )
        || defined( 'SEOPRESS_VERSION' )
        || defined( 'AIOSEO_VERSION' )
        || class_exists( '\AIOSEO\Plugin\Common\Main' )
        || class_exists( 'RankMath' );
}

/**
 * Normaliza e valida URLs para sameAs.
 *
 * @return string[]
 */
function playbrand_sp_same_as_urls() {
    $config = playbrand_sp_seo_config();
    $urls   = array();

    foreach ( (array) $config['same_as'] as $url ) {
        $url = esc_url_raw( $url );
        if ( $url ) {
            $urls[] = $url;
        }
    }

    return array_values( array_unique( $urls ) );
}

/**
 * Área atendida — cidade e estado de São Paulo.
 *
 * @return array<int,array<string,string>>
 */
function playbrand_sp_area_served_schema() {
    return array(
        array(
            '@type' => 'City',
            'name'   => 'São Paulo',
            'sameAs' => 'https://www.wikidata.org/wiki/Q174',
        ),
        array(
            '@type' => 'AdministrativeArea',
            'name'   => 'Estado de São Paulo',
            'sameAs' => 'https://www.wikidata.org/wiki/Q175',
        ),
    );
}

/**
 * Verifica se todos os campos mínimos de endereço foram preenchidos.
 */
function playbrand_sp_has_physical_address() {
    $config  = playbrand_sp_seo_config();
    $address = (array) $config['address'];

    foreach ( array( 'streetAddress', 'addressLocality', 'addressRegion', 'postalCode', 'addressCountry' ) as $key ) {
        if ( empty( $address[ $key ] ) ) {
            return false;
        }
    }

    return true;
}

/**
 * Endereço Schema somente quando completo e verdadeiro.
 *
 * @return array<string,string>
 */
function playbrand_sp_postal_address_schema() {
    $config  = playbrand_sp_seo_config();
    $address = (array) $config['address'];

    return array(
        '@type'           => 'PostalAddress',
        'streetAddress'   => sanitize_text_field( $address['streetAddress'] ),
        'addressLocality' => sanitize_text_field( $address['addressLocality'] ),
        'addressRegion'   => sanitize_text_field( $address['addressRegion'] ),
        'postalCode'      => sanitize_text_field( $address['postalCode'] ),
        'addressCountry'  => sanitize_text_field( $address['addressCountry'] ),
    );
}

/**
 * IDs estáveis para o grafo Schema.
 *
 * @return array<string,string>
 */
function playbrand_sp_schema_ids() {
    $home = playbrand_sp_seo_config()['home_url'];

    return array(
        'organization'   => $home . '#organization',
        'website'        => $home . '#website',
        'webpage'        => $home . '#webpage',
        'logo'           => $home . '#logo',
        'service_sites'  => $home . '#service-criacao-de-sites-sao-paulo',
        'service_social' => $home . '#service-social-media-sao-paulo',
        'faq'            => $home . '#faq',
    );
}

/**
 * Dados das perguntas frequentes. O mesmo conjunto alimenta HTML e Schema.
 *
 * @return array<int,array{question:string,answer:string}>
 */
function playbrand_sp_faq_items() {
    return array(
        array(
            'question' => 'Quanto custa criar um site profissional em São Paulo?',
            'answer'   => 'O investimento varia conforme o número de páginas, as integrações, o nível de personalização, a produção de conteúdo e os objetivos comerciais. A proposta deve considerar o escopo real do projeto, evitando pacotes genéricos que não atendam à estratégia da empresa.',
        ),
        array(
            'question' => 'Quanto tempo demora o desenvolvimento de um site?',
            'answer'   => 'O prazo depende da complexidade, do volume de conteúdo e da velocidade das aprovações. Depois do diagnóstico, a PlayBrand define um cronograma com etapas de planejamento, design, desenvolvimento, revisão, testes e publicação.',
        ),
        array(
            'question' => 'O site é entregue otimizado para o Google?',
            'answer'   => 'A estrutura pode ser preparada com HTML semântico, responsividade, URLs amigáveis, metadados, desempenho, rastreabilidade e conteúdo alinhado às buscas do público. O posicionamento também depende de autoridade, concorrência, conteúdo contínuo e qualidade da experiência.',
        ),
        array(
            'question' => 'Quais tipos de site a PlayBrand desenvolve?',
            'answer'   => 'A agência trabalha com sites institucionais, landing pages, hotsites, blogs, portais, lojas virtuais e projetos digitais personalizados, sempre de acordo com a necessidade de comunicação, geração de leads ou vendas da empresa.',
        ),
        array(
            'question' => 'O que está incluído no serviço de Social Media?',
            'answer'   => 'O escopo pode incluir diagnóstico, posicionamento, planejamento editorial, definição de pautas, criação de peças, textos, calendário de publicações e acompanhamento. A composição final é definida de acordo com os canais e metas de cada marca.',
        ),
        array(
            'question' => 'A PlayBrand cria conteúdo para Instagram e outras redes sociais?',
            'answer'   => 'Sim. O planejamento pode contemplar formatos adequados ao Instagram, Facebook, LinkedIn e outros canais relevantes, mantendo consistência visual, linguagem de marca e conexão com os objetivos do negócio.',
        ),
        array(
            'question' => 'É possível contratar criação de site e Social Media juntos?',
            'answer'   => 'Sim. A estratégia integrada ajuda a alinhar identidade, conteúdo, campanhas e páginas de conversão. As redes sociais atraem e desenvolvem relacionamento, enquanto o site organiza a proposta de valor e transforma interesse em contato ou venda.',
        ),
        array(
            'question' => 'A PlayBrand atende empresas de São Paulo?',
            'answer'   => 'Sim. A página é direcionada a empresas que procuram criação de sites, e-commerce, Social Media, branding e estratégia digital em São Paulo. O formato de atendimento e as etapas do projeto são definidos na proposta comercial.',
        ),
    );
}

/**
 * Catálogo de serviços para Organization.
 *
 * @return array<string,mixed>
 */
function playbrand_sp_offer_catalog_schema() {
    $ids = playbrand_sp_schema_ids();

    return array(
        '@type'           => 'OfferCatalog',
        'name'            => 'Serviços digitais da PlayBrand',
        'itemListElement' => array(
            array(
                '@type'      => 'Offer',
                'itemOffered' => array( '@id' => $ids['service_sites'] ),
            ),
            array(
                '@type'      => 'Offer',
                'itemOffered' => array( '@id' => $ids['service_social'] ),
            ),
        ),
    );
}

/**
 * Nós Service.
 *
 * @param string $organization_id ID da organização já existente.
 * @return array<int,array<string,mixed>>
 */
function playbrand_sp_service_schema_nodes( $organization_id ) {
    $config = playbrand_sp_seo_config();
    $ids    = playbrand_sp_schema_ids();
    $area   = playbrand_sp_area_served_schema();

    return array(
        array(
            '@type'       => 'Service',
            '@id'         => $ids['service_sites'],
            'name'        => 'Criação de Sites em São Paulo',
            'alternateName' => 'Desenvolvimento de sites em São Paulo',
            'serviceType' => 'Criação e desenvolvimento de sites profissionais',
            'description' => 'Planejamento, design e desenvolvimento de sites institucionais, landing pages, portais, blogs e lojas virtuais com foco em experiência, SEO, desempenho e conversão.',
            'provider'    => array( '@id' => $organization_id ),
            'areaServed'  => $area,
            'url'         => $config['services_url'],
            'audience'    => array(
                '@type'        => 'BusinessAudience',
                'audienceType' => 'Empresas e profissionais em São Paulo',
            ),
        ),
        array(
            '@type'       => 'Service',
            '@id'         => $ids['service_social'],
            'name'        => 'Social Media em São Paulo',
            'alternateName' => 'Gestão de redes sociais em São Paulo',
            'serviceType' => 'Planejamento, criação de conteúdo e gestão de redes sociais',
            'description' => 'Estratégia de Social Media com posicionamento, calendário editorial, criação de peças e textos para fortalecer presença, relacionamento e oportunidades comerciais.',
            'provider'    => array( '@id' => $organization_id ),
            'areaServed'  => $area,
            'url'         => $config['services_url'],
            'audience'    => array(
                '@type'        => 'BusinessAudience',
                'audienceType' => 'Empresas e profissionais em São Paulo',
            ),
        ),
    );
}

/**
 * Nó FAQPage opcional. O conteúdo equivalente é exibido no HTML; por padrão,
 * a emissão está desligada porque o Google não oferece mais esse rich result
 * para sites comerciais.
 *
 * @param string $webpage_id ID do WebPage.
 * @return array<string,mixed>
 */
function playbrand_sp_faq_schema_node( $webpage_id ) {
    $config = playbrand_sp_seo_config();
    $ids    = playbrand_sp_schema_ids();
    $items  = array();

    foreach ( playbrand_sp_faq_items() as $faq ) {
        $items[] = array(
            '@type'          => 'Question',
            'name'           => $faq['question'],
            'acceptedAnswer' => array(
                '@type' => 'Answer',
                'text'  => $faq['answer'],
            ),
        );
    }

    return array(
        '@type'      => 'FAQPage',
        '@id'        => $ids['faq'],
        'url'        => $config['home_url'] . '#duvidas-frequentes',
        'name'       => 'Dúvidas sobre Criação de Sites e Social Media em São Paulo',
        'isPartOf'   => array( '@id' => $webpage_id ),
        'inLanguage' => $config['language'],
        'mainEntity' => $items,
    );
}

/* -------------------------------------------------------------------------
 * TITLE, DESCRIPTION, CANONICAL, ROBOTS, OPEN GRAPH E X/TWITTER
 * ---------------------------------------------------------------------- */

/** Título via Yoast. */
function playbrand_sp_wpseo_title( $title ) {
    return playbrand_sp_is_home_request() ? playbrand_sp_seo_config()['title'] : $title;
}
add_filter( 'wpseo_title', 'playbrand_sp_wpseo_title', 999 );

/** Descrição via Yoast. */
function playbrand_sp_wpseo_description( $description ) {
    return playbrand_sp_is_home_request() ? playbrand_sp_seo_config()['description'] : $description;
}
add_filter( 'wpseo_metadesc', 'playbrand_sp_wpseo_description', 999 );

/** Canonical via Yoast. */
function playbrand_sp_wpseo_canonical( $canonical ) {
    return playbrand_sp_is_home_request() ? playbrand_sp_seo_config()['home_url'] : $canonical;
}
add_filter( 'wpseo_canonical', 'playbrand_sp_wpseo_canonical', 999 );

/** Robots via Yoast. */
function playbrand_sp_wpseo_robots( $robots ) {
    if ( playbrand_sp_is_home_request() && get_option( 'blog_public' ) ) {
        return 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1';
    }

    return $robots;
}
add_filter( 'wpseo_robots', 'playbrand_sp_wpseo_robots', 999 );

/** Open Graph e Twitter via filtros de presenters do Yoast. */
function playbrand_sp_social_title( $value ) {
    return playbrand_sp_is_home_request() ? playbrand_sp_seo_config()['title'] : $value;
}
function playbrand_sp_social_description( $value ) {
    return playbrand_sp_is_home_request() ? playbrand_sp_seo_config()['description'] : $value;
}
function playbrand_sp_social_image( $value ) {
    return playbrand_sp_is_home_request() ? playbrand_sp_seo_config()['og_image_url'] : $value;
}
function playbrand_sp_og_url( $value ) {
    return playbrand_sp_is_home_request() ? playbrand_sp_seo_config()['home_url'] : $value;
}
function playbrand_sp_og_type( $value ) {
    return playbrand_sp_is_home_request() ? 'website' : $value;
}
function playbrand_sp_og_site_name( $value ) {
    return playbrand_sp_is_home_request() ? playbrand_sp_seo_config()['brand_name'] : $value;
}
function playbrand_sp_og_locale( $value ) {
    return playbrand_sp_is_home_request() ? playbrand_sp_seo_config()['locale'] : $value;
}
function playbrand_sp_og_image_width( $value ) {
    return playbrand_sp_is_home_request() ? (string) playbrand_sp_seo_config()['og_image_width'] : $value;
}
function playbrand_sp_og_image_height( $value ) {
    return playbrand_sp_is_home_request() ? (string) playbrand_sp_seo_config()['og_image_height'] : $value;
}
function playbrand_sp_og_image_type( $value ) {
    return playbrand_sp_is_home_request() ? playbrand_sp_seo_config()['og_image_type'] : $value;
}
add_filter( 'wpseo_opengraph_title', 'playbrand_sp_social_title', 999 );
add_filter( 'wpseo_opengraph_desc', 'playbrand_sp_social_description', 999 );
add_filter( 'wpseo_opengraph_image', 'playbrand_sp_social_image', 999 );
add_filter( 'wpseo_opengraph_url', 'playbrand_sp_og_url', 999 );
add_filter( 'wpseo_opengraph_type', 'playbrand_sp_og_type', 999 );
add_filter( 'wpseo_opengraph_site_name', 'playbrand_sp_og_site_name', 999 );
add_filter( 'wpseo_og_locale', 'playbrand_sp_og_locale', 999 );
add_filter( 'wpseo_opengraph_image_width', 'playbrand_sp_og_image_width', 999 );
add_filter( 'wpseo_opengraph_image_height', 'playbrand_sp_og_image_height', 999 );
add_filter( 'wpseo_opengraph_image_type', 'playbrand_sp_og_image_type', 999 );
add_filter( 'wpseo_twitter_title', 'playbrand_sp_social_title', 999 );
add_filter( 'wpseo_twitter_description', 'playbrand_sp_social_description', 999 );
add_filter( 'wpseo_twitter_image', 'playbrand_sp_social_image', 999 );

/**
 * Garante uma imagem Open Graph no Yoast mesmo quando nenhuma foi definida.
 */
function playbrand_sp_add_yoast_og_image( $image_container ) {
    if ( ! playbrand_sp_is_home_request() ) {
        return $image_container;
    }

    $image_id = attachment_url_to_postid( playbrand_sp_seo_config()['og_image_url'] );

    if ( $image_id && is_object( $image_container ) && method_exists( $image_container, 'add_image_by_id' ) ) {
        $image_container->add_image_by_id( $image_id );
    }

    return $image_container;
}
add_filter( 'wpseo_add_opengraph_images', 'playbrand_sp_add_yoast_og_image' );

/**
 * Título nativo quando não há plugin de SEO.
 */
function playbrand_sp_native_document_title( $title ) {
    if ( playbrand_sp_is_home_request() && ! playbrand_sp_has_yoast() && ! playbrand_sp_has_other_seo_plugin() ) {
        return playbrand_sp_seo_config()['title'];
    }

    return $title;
}
add_filter( 'pre_get_document_title', 'playbrand_sp_native_document_title', 999 );

/**
 * Robots nativo quando não há plugin de SEO.
 */
function playbrand_sp_native_robots( $robots ) {
    if ( playbrand_sp_has_yoast() || playbrand_sp_has_other_seo_plugin() ) {
        return $robots;
    }

    if ( playbrand_sp_is_home_request() && get_option( 'blog_public' ) ) {
        unset( $robots['noindex'], $robots['nofollow'] );
        $robots['index']             = true;
        $robots['follow']            = true;
        $robots['max-image-preview'] = 'large';
        $robots['max-snippet']       = '-1';
        $robots['max-video-preview'] = '-1';
    }

    if ( is_search() ) {
        unset( $robots['index'] );
        $robots['noindex'] = true;
        $robots['follow']  = true;
    }

    return $robots;
}
add_filter( 'wp_robots', 'playbrand_sp_native_robots', 999 );

/**
 * Metatags de fallback. Não imprime nada se um plugin de SEO conhecido estiver ativo.
 */
function playbrand_sp_fallback_meta_tags() {
    if ( ! playbrand_sp_is_home_request() || playbrand_sp_has_yoast() || playbrand_sp_has_other_seo_plugin() ) {
        return;
    }

    $config = playbrand_sp_seo_config();
    ?>
    <meta name="description" content="<?php echo esc_attr( $config['description'] ); ?>" />
    <link rel="canonical" href="<?php echo esc_url( $config['home_url'] ); ?>" />
    <meta property="og:locale" content="<?php echo esc_attr( $config['locale'] ); ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="<?php echo esc_attr( $config['title'] ); ?>" />
    <meta property="og:description" content="<?php echo esc_attr( $config['description'] ); ?>" />
    <meta property="og:url" content="<?php echo esc_url( $config['home_url'] ); ?>" />
    <meta property="og:site_name" content="<?php echo esc_attr( $config['brand_name'] ); ?>" />
    <meta property="og:image" content="<?php echo esc_url( $config['og_image_url'] ); ?>" />
    <meta property="og:image:secure_url" content="<?php echo esc_url( $config['og_image_url'] ); ?>" />
    <meta property="og:image:width" content="<?php echo esc_attr( (string) $config['og_image_width'] ); ?>" />
    <meta property="og:image:height" content="<?php echo esc_attr( (string) $config['og_image_height'] ); ?>" />
    <meta property="og:image:type" content="<?php echo esc_attr( $config['og_image_type'] ); ?>" />
    <meta property="og:image:alt" content="PlayBrand — criação de sites e Social Media em São Paulo" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="<?php echo esc_attr( $config['title'] ); ?>" />
    <meta name="twitter:description" content="<?php echo esc_attr( $config['description'] ); ?>" />
    <meta name="twitter:image" content="<?php echo esc_url( $config['og_image_url'] ); ?>" />
    <?php if ( ! empty( $config['google_site_verification'] ) ) : ?>
        <meta name="google-site-verification" content="<?php echo esc_attr( $config['google_site_verification'] ); ?>" />
    <?php endif; ?>
    <?php if ( ! empty( $config['bing_site_verification'] ) ) : ?>
        <meta name="msvalidate.01" content="<?php echo esc_attr( $config['bing_site_verification'] ); ?>" />
    <?php endif; ?>
    <?php
}
add_action( 'wp_head', 'playbrand_sp_fallback_meta_tags', 1 );

/* -------------------------------------------------------------------------
 * SCHEMA INTEGRADO AO YOAST + FALLBACK SEM YOAST
 * ---------------------------------------------------------------------- */

/**
 * Enriquece o Organization do Yoast sem criar uma segunda organização.
 */
function playbrand_sp_wpseo_schema_organization( $data, $context = null ) {
    if ( ! playbrand_sp_is_home_request() ) {
        return $data;
    }

    $config = playbrand_sp_seo_config();
    $ids    = playbrand_sp_schema_ids();
    $types  = array( 'Organization' );

    if ( playbrand_sp_has_physical_address() ) {
        $types[] = 'LocalBusiness';
    }

    $data['@type']       = $types;
    $data['name']        = $config['brand_name'];
    if ( ! empty( $config['alternate_name'] ) ) {
        $data['alternateName'] = $config['alternate_name'];
    }
    $data['url']         = $config['home_url'];
    $data['description'] = $config['organization_description'];
    $data['areaServed']  = playbrand_sp_area_served_schema();
    $data['knowsAbout']  = array(
        'Criação de sites',
        'Desenvolvimento web',
        'Sites institucionais',
        'Landing pages',
        'E-commerce',
        'Social Media',
        'Gestão de redes sociais',
        'Branding',
        'SEO',
        'Experiência do usuário',
    );
    $data['hasOfferCatalog'] = playbrand_sp_offer_catalog_schema();

    $same_as = array_values( array_unique( array_merge( isset( $data['sameAs'] ) ? (array) $data['sameAs'] : array(), playbrand_sp_same_as_urls() ) ) );
    if ( $same_as ) {
        $data['sameAs'] = $same_as;
    }

    if ( empty( $data['logo'] ) ) {
        $data['logo'] = array(
            '@type'      => 'ImageObject',
            '@id'        => $ids['logo'],
            'url'        => $config['logo_url'],
            'contentUrl' => $config['logo_url'],
            'caption'    => $config['brand_name'],
            'width'      => (int) $config['logo_width'],
            'height'     => (int) $config['logo_height'],
            'inLanguage' => $config['language'],
        );
    }

    if ( ! empty( $config['telephone'] ) ) {
        $data['telephone'] = $config['telephone'];
        $data['contactPoint'] = array(
            '@type'             => 'ContactPoint',
            'telephone'         => $config['telephone'],
            'contactType'       => 'sales',
            'areaServed'        => 'BR',
            'availableLanguage' => array( 'pt-BR' ),
        );
    }

    if ( ! empty( $config['email'] ) && is_email( $config['email'] ) ) {
        $data['email'] = sanitize_email( $config['email'] );
    }

    if ( playbrand_sp_has_physical_address() ) {
        $data['address'] = playbrand_sp_postal_address_schema();

        if ( ! empty( $config['geo']['latitude'] ) && ! empty( $config['geo']['longitude'] ) ) {
            $data['geo'] = array(
                '@type'    => 'GeoCoordinates',
                'latitude' => (float) $config['geo']['latitude'],
                'longitude'=> (float) $config['geo']['longitude'],
            );
        }
    }

    return $data;
}
add_filter( 'wpseo_schema_organization', 'playbrand_sp_wpseo_schema_organization', 11, 2 );

/** Site name e nome alternativo no WebSite do Yoast. */
function playbrand_sp_wpseo_schema_website( $data, $context = null ) {
    if ( playbrand_sp_is_home_request() ) {
        $config = playbrand_sp_seo_config();
        $data['name']       = $config['brand_name'];
        if ( ! empty( $config['alternate_name'] ) ) {
            $data['alternateName'] = $config['alternate_name'];
        }
        $data['inLanguage'] = $config['language'];
    }

    return $data;
}
add_filter( 'wpseo_schema_website', 'playbrand_sp_wpseo_schema_website', 11, 2 );

/** Relaciona a home aos dois serviços principais. */
function playbrand_sp_wpseo_schema_webpage( $data, $context = null ) {
    if ( playbrand_sp_is_home_request() ) {
        $config = playbrand_sp_seo_config();
        $ids    = playbrand_sp_schema_ids();
        $refs   = array(
            array( '@id' => $ids['service_sites'] ),
            array( '@id' => $ids['service_social'] ),
        );

        $data['name']        = $config['title'];
        $data['description'] = $config['description'];
        $data['inLanguage']  = $config['language'];
        $data['about']       = $refs;
        $data['mainEntity']  = $refs;
    }

    return $data;
}
add_filter( 'wpseo_schema_webpage', 'playbrand_sp_wpseo_schema_webpage', 11, 2 );

/**
 * Busca o @id de um tipo dentro do grafo do Yoast.
 */
function playbrand_sp_find_graph_id( $graph, $wanted_type ) {
    foreach ( (array) $graph as $piece ) {
        if ( empty( $piece['@id'] ) || empty( $piece['@type'] ) ) {
            continue;
        }

        if ( in_array( $wanted_type, (array) $piece['@type'], true ) ) {
            return $piece['@id'];
        }
    }

    return '';
}

/**
 * Adiciona Service e, opcionalmente, FAQPage ao mesmo @graph do Yoast.
 */
function playbrand_sp_wpseo_schema_graph( $graph, $context = null ) {
    if ( ! playbrand_sp_is_home_request() ) {
        return $graph;
    }

    $config          = playbrand_sp_seo_config();
    $ids             = playbrand_sp_schema_ids();
    $organization_id = playbrand_sp_find_graph_id( $graph, 'Organization' );
    $webpage_id      = playbrand_sp_find_graph_id( $graph, 'WebPage' );

    if ( ! $organization_id ) {
        $organization_id = $ids['organization'];
    }
    if ( ! $webpage_id ) {
        $webpage_id = $ids['webpage'];
    }

    $existing_ids = array();
    foreach ( (array) $graph as $piece ) {
        if ( ! empty( $piece['@id'] ) ) {
            $existing_ids[] = $piece['@id'];
        }
    }

    foreach ( playbrand_sp_service_schema_nodes( $organization_id ) as $service ) {
        if ( ! in_array( $service['@id'], $existing_ids, true ) ) {
            $graph[] = $service;
        }
    }

    if ( ! empty( $config['append_visible_seo_content'] ) && ! empty( $config['add_faq_schema'] ) && ! in_array( $ids['faq'], $existing_ids, true ) ) {
        $graph[] = playbrand_sp_faq_schema_node( $webpage_id );
    }

    return $graph;
}
add_filter( 'wpseo_schema_graph', 'playbrand_sp_wpseo_schema_graph', 11, 2 );

/**
 * Organization para o fallback sem Yoast.
 *
 * @return array<string,mixed>
 */
function playbrand_sp_fallback_organization_schema() {
    $config = playbrand_sp_seo_config();
    $ids    = playbrand_sp_schema_ids();
    $types  = array( 'Organization' );

    if ( playbrand_sp_has_physical_address() ) {
        $types[] = 'LocalBusiness';
    }

    $organization = array(
        '@type'       => $types,
        '@id'         => $ids['organization'],
        'name'        => $config['brand_name'],
        'url'         => $config['home_url'],
        'description' => $config['organization_description'],
        'logo'        => array(
            '@type'      => 'ImageObject',
            '@id'        => $ids['logo'],
            'url'        => $config['logo_url'],
            'contentUrl' => $config['logo_url'],
            'caption'    => $config['brand_name'],
            'width'      => (int) $config['logo_width'],
            'height'     => (int) $config['logo_height'],
        ),
        'image'           => array( '@id' => $ids['logo'] ),
        'areaServed'      => playbrand_sp_area_served_schema(),
        'sameAs'          => playbrand_sp_same_as_urls(),
        'hasOfferCatalog' => playbrand_sp_offer_catalog_schema(),
        'knowsAbout'      => array(
            'Criação de sites',
            'Desenvolvimento web',
            'E-commerce',
            'Social Media',
            'Gestão de redes sociais',
            'Branding',
            'SEO',
        ),
    );

    if ( ! empty( $config['alternate_name'] ) ) {
        $organization['alternateName'] = $config['alternate_name'];
    }

    if ( ! empty( $config['telephone'] ) ) {
        $organization['telephone'] = $config['telephone'];
        $organization['contactPoint'] = array(
            '@type'             => 'ContactPoint',
            'telephone'         => $config['telephone'],
            'contactType'       => 'sales',
            'areaServed'        => 'BR',
            'availableLanguage' => array( 'pt-BR' ),
        );
    }

    if ( ! empty( $config['email'] ) && is_email( $config['email'] ) ) {
        $organization['email'] = sanitize_email( $config['email'] );
    }

    if ( playbrand_sp_has_physical_address() ) {
        $organization['address'] = playbrand_sp_postal_address_schema();

        if ( ! empty( $config['geo']['latitude'] ) && ! empty( $config['geo']['longitude'] ) ) {
            $organization['geo'] = array(
                '@type'    => 'GeoCoordinates',
                'latitude' => (float) $config['geo']['latitude'],
                'longitude'=> (float) $config['geo']['longitude'],
            );
        }
    }

    return $organization;
}

/**
 * JSON-LD de fallback quando nenhum plugin de SEO conhecido está ativo.
 */
function playbrand_sp_fallback_schema() {
    if ( ! playbrand_sp_is_home_request() || playbrand_sp_has_yoast() || playbrand_sp_has_other_seo_plugin() ) {
        return;
    }

    $config = playbrand_sp_seo_config();
    $ids    = playbrand_sp_schema_ids();
    $graph  = array(
        playbrand_sp_fallback_organization_schema(),
        array_filter(
            array(
                '@type'         => 'WebSite',
                '@id'           => $ids['website'],
                'url'           => $config['home_url'],
                'name'          => $config['brand_name'],
                'alternateName' => ! empty( $config['alternate_name'] ) ? $config['alternate_name'] : null,
                'description'   => $config['description'],
                'publisher'     => array( '@id' => $ids['organization'] ),
                'inLanguage'    => $config['language'],
            ),
            static function ( $value ) {
                return null !== $value && '' !== $value;
            }
        ),
        array(
            '@type'        => 'WebPage',
            '@id'          => $ids['webpage'],
            'url'          => $config['home_url'],
            'name'         => $config['title'],
            'description'  => $config['description'],
            'isPartOf'     => array( '@id' => $ids['website'] ),
            'about'        => array(
                array( '@id' => $ids['service_sites'] ),
                array( '@id' => $ids['service_social'] ),
            ),
            'mainEntity'   => array(
                array( '@id' => $ids['service_sites'] ),
                array( '@id' => $ids['service_social'] ),
            ),
            'primaryImageOfPage' => array(
                '@type'      => 'ImageObject',
                'url'        => $config['og_image_url'],
                'contentUrl' => $config['og_image_url'],
                'width'      => (int) $config['og_image_width'],
                'height'     => (int) $config['og_image_height'],
            ),
            'inLanguage'   => $config['language'],
        ),
    );

    foreach ( playbrand_sp_service_schema_nodes( $ids['organization'] ) as $service ) {
        $graph[] = $service;
    }

    if ( ! empty( $config['append_visible_seo_content'] ) && ! empty( $config['add_faq_schema'] ) ) {
        $graph[] = playbrand_sp_faq_schema_node( $ids['webpage'] );
    }

    echo "\n<script type=\"application/ld+json\" class=\"playbrand-sp-schema\">";
    echo wp_json_encode(
        array(
            '@context' => 'https://schema.org',
            '@graph'   => $graph,
        ),
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
    );
    echo "</script>\n";
}
add_action( 'wp_head', 'playbrand_sp_fallback_schema', 20 );

/* -------------------------------------------------------------------------
 * CONTEÚDO VISÍVEL, H1 SEMÂNTICO E HIERARQUIA DE HEADINGS
 * ---------------------------------------------------------------------- */

/**
 * Renderiza o conteúdo SEO visível que será anexado à home.
 */
function playbrand_sp_render_visible_seo_content() {
    $config = playbrand_sp_seo_config();
    $faqs   = playbrand_sp_faq_items();

    ob_start();
    ?>
    <section id="playbrand-sp-seo-content" class="playbrand-sp-seo" aria-labelledby="playbrand-sp-seo-title">
        <div class="playbrand-sp-seo__inner">
            <div class="playbrand-sp-seo__lead">
                <p class="playbrand-sp-seo__eyebrow">Agência para empresas em São Paulo</p>
                <h2 id="playbrand-sp-seo-title">Criação de sites em São Paulo com estratégia, SEO e conversão</h2>
                <p>A presença digital de uma empresa precisa ser clara, rápida e preparada para transformar atenção em oportunidade. A PlayBrand desenvolve sites profissionais que combinam estratégia, design, tecnologia e conteúdo para apresentar serviços, fortalecer autoridade e facilitar o contato de potenciais clientes.</p>
                <p>Cada projeto parte dos objetivos do negócio. Em vez de aplicar um modelo genérico, a estrutura é planejada de acordo com o público, a jornada de decisão, as ações que o visitante deve realizar e os diferenciais que precisam aparecer. O resultado é uma experiência responsiva, organizada e coerente com a identidade da marca.</p>
            </div>

            <div class="playbrand-sp-seo__grid playbrand-sp-seo__grid--3">
                <article class="playbrand-sp-seo__card">
                    <h3>Sites institucionais e corporativos</h3>
                    <p>Projetos para empresas que precisam apresentar soluções, diferenciais, cases, equipe e canais de contato de forma profissional. A arquitetura de informação prioriza leitura, navegação e geração de leads.</p>
                </article>
                <article class="playbrand-sp-seo__card">
                    <h3>Landing pages para campanhas</h3>
                    <p>Páginas focadas em uma oferta e uma ação principal, com textos, argumentos, prova de valor e chamadas para contato alinhadas a campanhas de mídia, lançamentos e captação comercial.</p>
                </article>
                <article class="playbrand-sp-seo__card">
                    <h3>Lojas virtuais e e-commerce</h3>
                    <p>Estruturas de venda online com organização de produtos, checkout, meios de pagamento, frete e recursos que ajudam o usuário a encontrar, comparar e concluir a compra com menos atrito.</p>
                </article>
            </div>

            <div class="playbrand-sp-seo__split">
                <div>
                    <p class="playbrand-sp-seo__eyebrow">Conteúdo, posicionamento e relacionamento</p>
                    <h2>Social Media em São Paulo para fortalecer marcas</h2>
                    <p>Social Media não é apenas publicar peças isoladas. Uma presença consistente exige entendimento de público, posicionamento, linguagem, objetivos e formatos. A PlayBrand organiza a comunicação para que cada conteúdo tenha uma função dentro da estratégia da marca.</p>
                    <p>O trabalho pode incluir diagnóstico dos canais, definição de pilares editoriais, calendário de publicações, criação visual, textos, campanhas e acompanhamento. A identidade do site e das redes sociais permanece conectada, evitando uma comunicação fragmentada.</p>
                </div>
                <div class="playbrand-sp-seo__grid">
                    <article class="playbrand-sp-seo__card">
                        <h3>Planejamento editorial</h3>
                        <p>Definição de temas, formatos, frequência e objetivos para construir uma linha de conteúdo coerente com a marca e com as dúvidas do público.</p>
                    </article>
                    <article class="playbrand-sp-seo__card">
                        <h3>Criação de conteúdo</h3>
                        <p>Desenvolvimento de peças e textos pensados para informar, gerar reconhecimento, apresentar soluções e estimular ações relevantes.</p>
                    </article>
                    <article class="playbrand-sp-seo__card">
                        <h3>Gestão de redes sociais</h3>
                        <p>Organização da rotina de publicação e evolução da presença digital de acordo com o escopo contratado e os canais prioritários.</p>
                    </article>
                </div>
            </div>

            <div class="playbrand-sp-seo__lead">
                <p class="playbrand-sp-seo__eyebrow">Estratégia integrada</p>
                <h2>Site e redes sociais trabalhando para o mesmo objetivo</h2>
                <p>As redes sociais ajudam a ampliar alcance, relacionamento e lembrança de marca. O site concentra informações, organiza a proposta de valor e oferece um ambiente controlado para transformar interesse em orçamento, cadastro ou venda. Quando os dois canais compartilham mensagem, identidade e metas, a experiência se torna mais consistente.</p>
                <p>Essa integração também melhora campanhas. Um conteúdo publicado nas redes pode direcionar o usuário para uma página específica, enquanto o site pode apresentar materiais, cases e ofertas que aprofundam a decisão. Assim, a estratégia deixa de depender apenas de curtidas e passa a construir ativos digitais próprios.</p>
            </div>

            <div class="playbrand-sp-seo__process">
                <h2>Como funciona um projeto com a PlayBrand</h2>
                <ol class="playbrand-sp-seo__steps">
                    <li><strong>Diagnóstico:</strong> entendimento do negócio, público, concorrência, canais atuais e objetivos.</li>
                    <li><strong>Estratégia:</strong> definição de escopo, arquitetura, posicionamento, conteúdo e indicadores relevantes.</li>
                    <li><strong>Criação:</strong> desenvolvimento visual, produção de textos e construção das peças ou páginas.</li>
                    <li><strong>Revisão e testes:</strong> validação de conteúdo, experiência, responsividade, links e funcionamento.</li>
                    <li><strong>Publicação e evolução:</strong> entrega, acompanhamento do projeto e definição dos próximos passos.</li>
                </ol>
            </div>

            <div id="duvidas-frequentes" class="playbrand-sp-seo__faq" aria-labelledby="playbrand-sp-faq-title">
                <p class="playbrand-sp-seo__eyebrow">Perguntas frequentes</p>
                <h2 id="playbrand-sp-faq-title">Dúvidas sobre Criação de Sites e Social Media em São Paulo</h2>
                <div class="playbrand-sp-seo__faq-grid">
                    <?php foreach ( $faqs as $faq ) : ?>
                        <article class="playbrand-sp-seo__faq-item">
                            <h3><?php echo esc_html( $faq['question'] ); ?></h3>
                            <p><?php echo esc_html( $faq['answer'] ); ?></p>
                        </article>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="playbrand-sp-seo__cta">
                <div>
                    <h2>Vamos planejar sua presença digital?</h2>
                    <p>Apresente seu objetivo e receba uma proposta para criação de site, e-commerce, Social Media ou uma estratégia integrada.</p>
                </div>
                <div class="playbrand-sp-seo__actions">
                    <a class="playbrand-sp-seo__button" href="<?php echo esc_url( $config['budget_url'] ); ?>">Solicitar proposta</a>
                    <a class="playbrand-sp-seo__button playbrand-sp-seo__button--ghost" href="<?php echo esc_url( $config['whatsapp_url'] ); ?>" target="_blank" rel="noopener noreferrer">Falar pelo WhatsApp</a>
                </div>
            </div>

            <nav class="playbrand-sp-seo__related" aria-label="Links relacionados">
                <a href="<?php echo esc_url( $config['services_url'] ); ?>">Conheça as soluções</a>
                <a href="<?php echo esc_url( $config['portfolio_url'] ); ?>">Veja o portfólio</a>
                <a href="<?php echo esc_url( $config['blog_url'] ); ?>">Leia notícias e insights</a>
            </nav>
        </div>
    </section>
    <?php

    return ob_get_clean();
}

/**
 * Shortcode opcional para posicionar manualmente o bloco no Elementor:
 * [playbrand_sp_seo_content]
 *
 * Ao usar o shortcode, altere append_visible_seo_content para false para evitar
 * que o mesmo conteúdo também seja anexado automaticamente ao fim da home.
 */
function playbrand_sp_seo_content_shortcode() {
    if ( ! playbrand_sp_is_home_request() ) {
        return '';
    }

    return playbrand_sp_render_visible_seo_content();
}
add_shortcode( 'playbrand_sp_seo_content', 'playbrand_sp_seo_content_shortcode' );

/**
 * Anexa conteúdo útil e visível ao fim da home.
 */
function playbrand_sp_append_visible_seo_content( $content ) {
    static $already_added = false;
    $config = playbrand_sp_seo_config();

    if (
        $already_added
        || empty( $config['append_visible_seo_content'] )
        || ! playbrand_sp_is_home_request()
        || playbrand_sp_is_elementor_preview()
        || ! in_the_loop()
        || ! is_main_query()
    ) {
        return $content;
    }

    if ( false !== strpos( $content, 'id="playbrand-sp-seo-content"' ) ) {
        return $content;
    }

    $already_added = true;

    return $content . playbrand_sp_render_visible_seo_content();
}
add_filter( 'the_content', 'playbrand_sp_append_visible_seo_content', 95 );

/**
 * Corrige os headings decorativos 3D do template e insere um H1 real no hero.
 * O texto visual "Play / Brand" continua igual; somente a semântica muda.
 */
function playbrand_sp_fix_elementor_widget_semantics( $widget_content, $widget ) {
    static $semantic_h1_added = false;
    $config = playbrand_sp_seo_config();

    if ( ! playbrand_sp_is_home_request() || empty( $config['fix_elementor_headings'] ) ) {
        return $widget_content;
    }

    if ( false !== stripos( $widget_content, 'text-3d' ) ) {
        $plain_text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $widget_content ) ) );
        $is_play_widget = (bool) preg_match( '/^Play(?:\s*Play)?$/iu', $plain_text );

        // Headings usados apenas para o efeito 3D tornam-se divs, mantendo classes e visual.
        $widget_content = preg_replace(
            '#<(h[1-6])(\b[^>]*)>(.*?)</\1>#is',
            '<div$2>$3</div>',
            $widget_content
        );

        // O front/back duplicado do efeito é decorativo para tecnologias assistivas.
        if ( class_exists( 'WP_HTML_Tag_Processor' ) ) {
            $decorative = new WP_HTML_Tag_Processor( $widget_content );
            while ( $decorative->next_tag( 'DIV' ) ) {
                $class = (string) $decorative->get_attribute( 'class' );
                if ( preg_match( '/(?:^|\s)text-3d(?:\s|$)/', $class ) ) {
                    $decorative->set_attribute( 'aria-hidden', 'true' );
                    break;
                }
            }
            $widget_content = $decorative->get_updated_html();
        }

        if ( $is_play_widget && ! $semantic_h1_added && false === strpos( $widget_content, 'playbrand-sp-semantic-h1' ) ) {
            $widget_content     = '<h1 class="playbrand-sp-semantic-h1">Criação de Sites e Social Media em São Paulo</h1>' . $widget_content;
            $semantic_h1_added = true;
        }
    }

    return playbrand_sp_process_rendered_html( $widget_content );
}
add_filter( 'elementor/widget/render_content', 'playbrand_sp_fix_elementor_widget_semantics', 20, 2 );

/* -------------------------------------------------------------------------
 * LINKS INTERNOS, LINKS DO TEMPLATE E ATRIBUTOS DE IMAGENS
 * ---------------------------------------------------------------------- */

/** Verifica se uma URL é interna. */
function playbrand_sp_is_internal_url( $url ) {
    if ( ! is_string( $url ) || '' === trim( $url ) ) {
        return false;
    }

    $url = html_entity_decode( trim( $url ), ENT_QUOTES, 'UTF-8' );

    if ( 0 === strpos( $url, '#' ) || preg_match( '#^(?:mailto|tel|javascript):#i', $url ) ) {
        return false;
    }

    $parts = wp_parse_url( $url );
    if ( false === $parts ) {
        return false;
    }

    if ( empty( $parts['host'] ) ) {
        return true;
    }

    $home_host = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
    $url_host  = strtolower( (string) $parts['host'] );

    $home_host = preg_replace( '/^www\./i', '', $home_host );
    $url_host  = preg_replace( '/^www\./i', '', $url_host );

    return $home_host === $url_host;
}

/**
 * ALT correto para imagens conhecidas; vazio significa imagem decorativa.
 *
 * @return array<string,string>
 */
function playbrand_sp_image_alt_map() {
    return array(
        'logo.png'                    => 'PlayBrand',
        'playbrand-1.png'             => 'Logotipo PlayBrand',
        'refresh-her.webp'            => '',
        'refresh-hero-mobile.webp'    => '',
        'Sunglasses.webp'             => '',
        'man_in_orange_sunglasse.webp'=> '',
        'agency-faqs1.webp'           => '',
        'agency-faqs6.webp'           => '',
        'agency-faqs7.webp'           => '',
        'agency-faqs8.webp'           => '',
        'arrow-down-large.svg'        => '',
        'inicie.png'                  => 'Planejamento de uma apresentação digital de marca',
        'PortoSeguro.png'             => 'Porto Seguro',
        'Vale-.png'                   => 'Vale',
        'Toshiba.png'                 => 'Toshiba',
        'Bridgestone.png'             => 'Bridgestone',
        'Honda.png'                   => 'Honda',
        'Br.png'                      => 'Petrobras',
        'Mercedes.png'                => 'Mercedes-Benz',
        'Pirelli.png'                 => 'Pirelli',
        'Colgate.png'                 => 'Colgate',
        'Arezzo.png'                  => 'Arezzo',
        'Saulamerica.png'             => 'SulAmérica',
        'Coca-cola.png'               => 'Coca-Cola',
        'blog-2-300x167.jpeg'         => 'Jornada do cliente em um site profissional',
        'blog-3-300x167.jpeg'         => 'Estratégia de tráfego orgânico para pequenas empresas',
        'blog-300x167.jpeg'           => 'Site responsivo exibido em dispositivos móveis',
    );
}

/**
 * Processa HTML do Elementor/conteúdo com a API segura do WordPress.
 */
function playbrand_sp_process_rendered_html( $html ) {
    if ( ! playbrand_sp_is_home_request() || ! is_string( $html ) || '' === $html ) {
        return $html;
    }

    $config = playbrand_sp_seo_config();

    if ( ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
        return $html;
    }

    // 1) Links.
    $links = new WP_HTML_Tag_Processor( $html );
    while ( $links->next_tag( 'A' ) ) {
        $href = (string) $links->get_attribute( 'href' );

        if ( ! empty( $config['fix_theme_demo_links'] ) && false !== stripos( $href, 'preview.treethemes.com/elementor/brandberry/' ) ) {
            $href = $config['portfolio_url'];
            $links->set_attribute( 'href', $href );
        }

        if ( ! empty( $config['clean_internal_nofollow'] ) && playbrand_sp_is_internal_url( $href ) ) {
            $rel = trim( (string) $links->get_attribute( 'rel' ) );

            if ( '' !== $rel ) {
                $tokens = preg_split( '/\s+/', $rel );
                $tokens = array_values(
                    array_filter(
                        (array) $tokens,
                        static function ( $token ) {
                            return 'nofollow' !== strtolower( $token );
                        }
                    )
                );

                if ( $tokens ) {
                    $links->set_attribute( 'rel', implode( ' ', array_unique( $tokens ) ) );
                } else {
                    $links->remove_attribute( 'rel' );
                }
            }
        }
    }
    $html = $links->get_updated_html();

    // 2) Imagens.
    if ( ! empty( $config['optimize_image_attributes'] ) ) {
        $alts   = playbrand_sp_image_alt_map();
        $images = new WP_HTML_Tag_Processor( $html );

        while ( $images->next_tag( 'IMG' ) ) {
            $src      = (string) $images->get_attribute( 'src' );
            $path     = (string) wp_parse_url( $src, PHP_URL_PATH );
            $filename = rawurldecode( basename( $path ) );

            if ( array_key_exists( $filename, $alts ) ) {
                $images->set_attribute( 'alt', $alts[ $filename ] );
            }

            $images->set_attribute( 'decoding', 'async' );

            if ( in_array( $filename, array( 'refresh-her.webp', 'refresh-hero-mobile.webp' ), true ) ) {
                $images->remove_attribute( 'loading' );
                $images->set_attribute( 'fetchpriority', 'high' );
            } elseif ( in_array( $filename, array_keys( $alts ), true ) && ! in_array( $filename, array( 'logo.png', 'playbrand-1.png' ), true ) ) {
                $images->set_attribute( 'loading', 'lazy' );
            }
        }

        $html = $images->get_updated_html();
    }

    return $html;
}

/** Processa o HTML final retornado por the_content. */
function playbrand_sp_process_the_content( $content ) {
    return playbrand_sp_process_rendered_html( $content );
}
add_filter( 'the_content', 'playbrand_sp_process_the_content', 99 );
add_filter( 'widget_text_content', 'playbrand_sp_process_the_content', 99 );

/** Remove nofollow de links internos gerados por menus nativos. */
function playbrand_sp_menu_link_attributes( $atts, $menu_item = null, $args = null, $depth = 0 ) {
    $config = playbrand_sp_seo_config();

    if (
        playbrand_sp_is_home_request()
        && ! empty( $config['clean_internal_nofollow'] )
        && ! empty( $atts['href'] )
        && playbrand_sp_is_internal_url( $atts['href'] )
        && ! empty( $atts['rel'] )
    ) {
        $tokens = preg_split( '/\s+/', trim( $atts['rel'] ) );
        $tokens = array_values(
            array_filter(
                (array) $tokens,
                static function ( $token ) {
                    return 'nofollow' !== strtolower( $token );
                }
            )
        );

        if ( $tokens ) {
            $atts['rel'] = implode( ' ', array_unique( $tokens ) );
        } else {
            unset( $atts['rel'] );
        }
    }

    return $atts;
}
add_filter( 'nav_menu_link_attributes', 'playbrand_sp_menu_link_attributes', 20, 4 );

/* -------------------------------------------------------------------------
 * PERFORMANCE SEGURA E HEAD
 * ---------------------------------------------------------------------- */

/** Preconnect para Google Fonts já usados pelo template atual. */
function playbrand_sp_resource_hints( $urls, $relation_type ) {
    if ( ! playbrand_sp_is_home_request() || 'preconnect' !== $relation_type ) {
        return $urls;
    }

    $urls[] = 'https://fonts.googleapis.com';
    $urls[] = array(
        'href'        => 'https://fonts.gstatic.com',
        'crossorigin' => 'anonymous',
    );

    return $urls;
}
add_filter( 'wp_resource_hints', 'playbrand_sp_resource_hints', 10, 2 );

/** Preload responsivo das imagens principais do hero. */
function playbrand_sp_preload_hero_images() {
    $config = playbrand_sp_seo_config();

    if ( ! playbrand_sp_is_home_request() || empty( $config['preload_hero_images'] ) ) {
        return;
    }
    ?>
    <link rel="preload" as="image" href="<?php echo esc_url( $config['hero_desktop'] ); ?>" media="(min-width: 768px)" fetchpriority="high" />
    <link rel="preload" as="image" href="<?php echo esc_url( $config['hero_mobile'] ); ?>" media="(max-width: 767px)" fetchpriority="high" />
    <?php
}
add_action( 'wp_head', 'playbrand_sp_preload_hero_images', 2 );

/**
 * Desativa o vídeo de fundo em dispositivos móveis no Elementor.
 * A imagem mobile existente permanece como fundo visual.
 */
function playbrand_sp_disable_elementor_mobile_background_video( $element ) {
    $config = playbrand_sp_seo_config();

    if ( ! playbrand_sp_is_home_request() || empty( $config['disable_mobile_bg_video'] ) || ! is_object( $element ) ) {
        return;
    }

    if ( ! method_exists( $element, 'get_settings' ) || ! method_exists( $element, 'set_settings' ) ) {
        return;
    }

    $settings = $element->get_settings();

    if ( isset( $settings['background_background'] ) && 'video' === $settings['background_background'] ) {
        $element->set_settings( 'background_play_on_mobile', '' );
    }
}
add_action( 'elementor/frontend/before_render', 'playbrand_sp_disable_elementor_mobile_background_video', 10, 1 );

/** CSS do H1 e do bloco de conteúdo visível. */
function playbrand_sp_inline_styles() {
    if ( ! playbrand_sp_is_home_request() ) {
        return;
    }
    ?>
    <style id="playbrand-sp-seo-css">
        .playbrand-sp-semantic-h1{
            position:relative;z-index:3;max-width:900px;margin:0 0 18px;
            font-family:inherit;font-size:clamp(1rem,1.65vw,1.45rem);font-weight:600;
            line-height:1.35;letter-spacing:.01em;text-transform:none;color:inherit;
        }
        .playbrand-sp-seo{width:100%;padding:clamp(72px,8vw,128px) 24px;color:inherit;background:transparent}
        .playbrand-sp-seo *{box-sizing:border-box}
        .playbrand-sp-seo__inner{width:min(1240px,100%);margin:0 auto}
        .playbrand-sp-seo__lead{max-width:920px;margin-bottom:clamp(44px,6vw,80px)}
        .playbrand-sp-seo__eyebrow{margin:0 0 12px;font-size:.78rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;opacity:.72}
        .playbrand-sp-seo h2{margin:0 0 22px;font-size:clamp(2rem,4.4vw,4.6rem);line-height:1.03;letter-spacing:-.035em;color:inherit}
        .playbrand-sp-seo h3{margin:0 0 12px;font-size:clamp(1.15rem,1.7vw,1.55rem);line-height:1.2;color:inherit}
        .playbrand-sp-seo p,.playbrand-sp-seo li{font-size:clamp(1rem,1.2vw,1.15rem);line-height:1.75;color:inherit;opacity:.88}
        .playbrand-sp-seo p{margin:0 0 18px}
        .playbrand-sp-seo__grid{display:grid;grid-template-columns:1fr;gap:18px}
        .playbrand-sp-seo__grid--3{grid-template-columns:repeat(3,minmax(0,1fr));margin-bottom:clamp(64px,8vw,110px)}
        .playbrand-sp-seo__card,.playbrand-sp-seo__faq-item{padding:clamp(24px,3vw,38px);border:1px solid rgba(127,127,127,.28);border-radius:18px;background:rgba(127,127,127,.055)}
        .playbrand-sp-seo__card p,.playbrand-sp-seo__faq-item p{margin-bottom:0;font-size:1rem}
        .playbrand-sp-seo__split{display:grid;grid-template-columns:minmax(0,1.05fr) minmax(0,.95fr);gap:clamp(36px,7vw,100px);align-items:start;margin-bottom:clamp(64px,8vw,110px)}
        .playbrand-sp-seo__process{margin:clamp(64px,8vw,110px) 0}
        .playbrand-sp-seo__steps{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:14px;margin:30px 0 0;padding:0;list-style:none;counter-reset:step}
        .playbrand-sp-seo__steps li{counter-increment:step;padding:24px;border-top:1px solid rgba(127,127,127,.35);font-size:.98rem}
        .playbrand-sp-seo__steps li:before{content:counter(step,decimal-leading-zero);display:block;margin-bottom:22px;font-size:.8rem;font-weight:700;letter-spacing:.1em;opacity:.6}
        .playbrand-sp-seo__faq{scroll-margin-top:120px;margin:clamp(64px,8vw,110px) 0}
        .playbrand-sp-seo__faq-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}
        .playbrand-sp-seo__cta{display:flex;align-items:center;justify-content:space-between;gap:32px;margin-top:clamp(64px,8vw,110px);padding:clamp(28px,5vw,58px);border:1px solid rgba(127,127,127,.3);border-radius:22px}
        .playbrand-sp-seo__cta h2{font-size:clamp(1.8rem,3vw,3.2rem)}
        .playbrand-sp-seo__cta p{margin-bottom:0}
        .playbrand-sp-seo__actions{display:flex;flex-wrap:wrap;gap:12px;flex:0 0 auto}
        .playbrand-sp-seo__button{display:inline-flex;align-items:center;justify-content:center;min-height:48px;padding:12px 22px;border:1px solid currentColor;border-radius:999px;background:#fff;color:Canvas;text-decoration:none;font-weight:700;transition:transform .2s ease,opacity .2s ease}
        .playbrand-sp-seo__button:hover{transform:translateY(-2px);opacity:.85}
        .playbrand-sp-seo__button--ghost{background:transparent;color:inherit}
        .playbrand-sp-seo__related{display:flex;flex-wrap:wrap;gap:16px 28px;margin-top:28px}
        .playbrand-sp-seo__related a{color:inherit;text-underline-offset:4px}
        @media (max-width:1024px){
            .playbrand-sp-seo__grid--3,.playbrand-sp-seo__steps{grid-template-columns:repeat(2,minmax(0,1fr))}
            .playbrand-sp-seo__split{grid-template-columns:1fr}
        }
        @media (max-width:767px){
            .elementor-background-video-container{display:none!important}
            .playbrand-sp-seo{padding-inline:18px}
            .playbrand-sp-seo__grid--3,.playbrand-sp-seo__steps,.playbrand-sp-seo__faq-grid{grid-template-columns:1fr}
            .playbrand-sp-seo__cta{display:block}
            .playbrand-sp-seo__actions{margin-top:24px}
            .playbrand-sp-seo__button{width:100%}
        }
    </style>
    <?php
}
add_action( 'wp_head', 'playbrand_sp_inline_styles', 30 );

/** Limpeza moderada do head: sem remover feeds, REST ou recursos essenciais. */
function playbrand_sp_clean_head_hooks() {
    $config = playbrand_sp_seo_config();

    if ( empty( $config['clean_head'] ) ) {
        return;
    }

    remove_action( 'wp_head', 'rsd_link' );
    remove_action( 'wp_head', 'wlwmanifest_link' );
    remove_action( 'wp_head', 'wp_generator' );
    remove_action( 'wp_head', 'wp_shortlink_wp_head', 10 );
    remove_action( 'template_redirect', 'wp_shortlink_header', 11 );

    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
    remove_action( 'admin_print_styles', 'print_emoji_styles' );
    add_filter( 'emoji_svg_url', '__return_false' );
}
add_action( 'init', 'playbrand_sp_clean_head_hooks' );

/** Adiciona o sitemap ao robots.txt virtual, sem duplicar a linha. */
function playbrand_sp_robots_txt( $output, $public ) {
    if ( ! $public || playbrand_sp_has_other_seo_plugin() ) {
        return $output;
    }

    $sitemap = playbrand_sp_has_yoast()
        ? home_url( '/sitemap_index.xml' )
        : home_url( '/wp-sitemap.xml' );

    if ( false === stripos( $output, $sitemap ) ) {
        $output = rtrim( $output ) . "\nSitemap: " . esc_url_raw( $sitemap ) . "\n";
    }

    return $output;
}
add_filter( 'robots_txt', 'playbrand_sp_robots_txt', 20, 2 );

/** Redireciona páginas de anexos finas para o conteúdo pai ou para a home. */
function playbrand_sp_redirect_attachment_pages() {
    if ( ! is_attachment() ) {
        return;
    }

    $attachment_id = get_queried_object_id();
    $parent_id     = wp_get_post_parent_id( $attachment_id );
    $target        = $parent_id ? get_permalink( $parent_id ) : home_url( '/' );

    if ( $target ) {
        wp_safe_redirect( $target, 301, 'PlayBrand SEO' );
        exit;
    }
}
add_action( 'template_redirect', 'playbrand_sp_redirect_attachment_pages', 1 );

