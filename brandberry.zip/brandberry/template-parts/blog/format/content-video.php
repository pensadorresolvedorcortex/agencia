<?php

  $blog_readmore__icon = BRANDBERRY_IMG .'/default-blog/arrow-right-1.png';
  $read_more_icon_option = brandberry_option('blog_readmore__icon');
  $feature_video_url = brandberry_meta_option(get_the_ID(),'feature_video_id');
  $icon = '<i class="icon-wcf-arrow-right"></i>';

  if(is_array($read_more_icon_option) && isset($read_more_icon_option['url']) && $read_more_icon_option['url'] !=''){
    $blog_readmore__icon = $read_more_icon_option['url'];
    $icon = sprintf('<img src="%s" alt="%s">', esc_url($blog_readmore__icon), esc_attr__('arrow right','brandberry'));
  }
 
?>
<?php if(brandberry_option('blog_layout') === 'style-2'):  ?>
  <article <?php post_class('default-blog__style-2'); ?>>
    <?php if( brandberry_option('blog_author','1')  ): ?>
      <div class="author">
        <?php if( brandberry_option('blog_author_image','1')  ): ?>
          <div class="author-img">
            <?php echo wp_kses_post( get_avatar( get_the_author_meta( 'ID' ), 60 ) ); ?>
          </div>
        <?php endif; ?>
        <div class="author-bio">
          <h4><?php esc_html_e( 'Written by ', 'brandberry' ); ?></h4>
          <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php the_author(); ?></a>
        </div>
      </div>
    <?php endif; ?>

    <div class="content">
      <?php if( brandberry_option('blog_thumb','1')  ): ?>
      <div class="thumb">
        <?php if(has_post_thumbnail()): ?>
          <a href="<?php the_permalink(); ?>"><img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="<?php the_title_attribute(); ?>"></a>
        <?php endif; ?>
        <?php if($feature_video_url !=''): ?>
          <a href="<?php echo esc_url($feature_video_url); ?>" class="play-btn video-popup"><i class="icon-wcf-play-fill"></i></a>
        <?php endif; ?>
        </div>
      <?php endif; ?>

      <?php echo brandberry_post_meta_2(); ?>
      <h2 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
      <div class="cf_text">
        <?php brandberry_excerpt( 40, null ); ?>
      </div>
    </div>

    <?php if(brandberry_option('blog_readmore',1)): ?>
    <div class="cf_btn">
      <a href="<?php the_permalink(); ?>" class="link"><span class="scr_only"><?php echo esc_html('Blog details page button'); ?></span><?php echo brandberry_kses($icon); ?></a>
    </div>
    <?php endif; ?>

  </article>

<?php else: ?>
  <article <?php post_class('default-blog__item-single'); ?>>
    <?php if( brandberry_option('blog_thumb','1')  ): ?>
      <div class="def-thumb">
      <?php if(has_post_thumbnail()): ?>
        <a href="<?php the_permalink(); ?>"><img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="<?php the_title_attribute(); ?>"></a>
      <?php endif; ?>
      <?php if($feature_video_url !=''): ?>
        <a href="<?php echo esc_url($feature_video_url); ?>" class="play-btn video-popup position-absolute"><i class="icon-wcf-play-fill"></i></a>
      <?php endif; ?>
      </div>
    <?php endif; ?>
      <div class="default-blog__content">
          <?php echo brandberry_post_meta(); ?>
          <h2 class="default-blog__item-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
          <div class="cf_text">
            <?php brandberry_excerpt( 40, null ); ?>
          </div>
        <?php if(brandberry_option('blog_readmore',1)): ?>
          <div class="cf_btn">
            <a href="<?php the_permalink(); ?>" class="wc-btn-underline"><span class="scr_only"><?php echo esc_html('Blog details page button'); ?></span><?php echo esc_html(brandberry_option('blog_readmore_text','Read more')); ?><img src="<?php echo esc_url($blog_readmore__icon); ?>" alt="<?php esc_attr__('arrow right','brandberry'); ?>"> </a>
          </div>
        <?php endif; ?>
      </div>
  </article>
<?php endif; ?>