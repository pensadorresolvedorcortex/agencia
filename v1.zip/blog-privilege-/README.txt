Blog Privilège AI Premium v4 — SEO & Editorial Engine

Auditoria aplicada:
- Fluxo de geração de imagem revisado.
- Prompt editorial conectado ao motor real de imagem.
- Bloqueio de estilos ilustrativos.
- SEO slug engine revisado.

Recursos:
- Editorial Photography Engine.
- Fotografia corporativa realista.
- Slugs limpos e curtos.
- Remoção de datas, IDs e excesso de palavras-chave.
- Preservação do sistema de cron, histórico e anti-repetição.
