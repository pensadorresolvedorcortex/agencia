<?php
/**
 * Plugin Name: RSB - Atualizar Confrontos Imediato
 * Description: Atualiza de forma segura os confrontos M089 a M096 do Resenha Sagrada Bolão sem mexer em placares, palpites, pontuações ou ranking.
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) { exit; }

function rsb_confrontos_imediatos_payload(): array {
    return [
        'M089' => ['fase'=>'Mata-mata - Oitavas','grupo'=>'','rodada'=>'Oitavas de final','data_jogo'=>'2026-07-04','hora_jogo'=>'14:00:00','time_mandante'=>'Canadá','time_visitante'=>'Marrocos','local_jogo'=>'Houston, Estados Unidos','status'=>'agendado'],
        'M090' => ['fase'=>'Mata-mata - Oitavas','grupo'=>'','rodada'=>'Oitavas de final','data_jogo'=>'2026-07-04','hora_jogo'=>'18:00:00','time_mandante'=>'Paraguai','time_visitante'=>'França','local_jogo'=>'Filadélfia, Estados Unidos','status'=>'agendado'],
        'M091' => ['fase'=>'Mata-mata - Oitavas','grupo'=>'','rodada'=>'Oitavas de final','data_jogo'=>'2026-07-05','hora_jogo'=>'17:00:00','time_mandante'=>'Brasil','time_visitante'=>'Noruega','local_jogo'=>'Nova Jersey, Estados Unidos','status'=>'agendado'],
        'M092' => ['fase'=>'Mata-mata - Oitavas','grupo'=>'','rodada'=>'Oitavas de final','data_jogo'=>'2026-07-05','hora_jogo'=>'21:00:00','time_mandante'=>'México','time_visitante'=>'Inglaterra','local_jogo'=>'Cidade do México, México','status'=>'agendado'],
        'M093' => ['fase'=>'Mata-mata - Oitavas','grupo'=>'','rodada'=>'Oitavas de final','data_jogo'=>'2026-07-06','hora_jogo'=>'16:00:00','time_mandante'=>'Portugal','time_visitante'=>'Espanha','local_jogo'=>'Arlington, Estados Unidos','status'=>'agendado'],
        'M094' => ['fase'=>'Mata-mata - Oitavas','grupo'=>'','rodada'=>'Oitavas de final','data_jogo'=>'2026-07-06','hora_jogo'=>'21:00:00','time_mandante'=>'EUA','time_visitante'=>'Bélgica','local_jogo'=>'Seattle, Estados Unidos','status'=>'agendado'],
        'M095' => ['fase'=>'Mata-mata - Oitavas','grupo'=>'','rodada'=>'Oitavas de final','data_jogo'=>'2026-07-07','hora_jogo'=>'13:00:00','time_mandante'=>'Argentina','time_visitante'=>'Egito','local_jogo'=>'Atlanta, Estados Unidos','status'=>'agendado'],
        'M096' => ['fase'=>'Mata-mata - Oitavas','grupo'=>'','rodada'=>'Oitavas de final','data_jogo'=>'2026-07-07','hora_jogo'=>'17:00:00','time_mandante'=>'Suíça','time_visitante'=>'Colômbia','local_jogo'=>'Vancouver, Canadá','status'=>'agendado'],
    ];
}

function rsb_confrontos_imediatos_find_jogos_table(): string {
    global $wpdb;
    if (function_exists('rsb_table')) {
        $table = rsb_table('jogos');
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        if ($exists === $table) { return $table; }
    }
    $candidates = $wpdb->get_col("SHOW TABLES LIKE '%rsb%jogos%'");
    foreach ((array) $candidates as $table) {
        $codigo = $wpdb->get_var("SHOW COLUMNS FROM `" . esc_sql($table) . "` LIKE 'codigo_jogo'");
        if ($codigo) { return $table; }
    }
    $candidates = $wpdb->get_col("SHOW TABLES LIKE '%bolao%jogos%'");
    foreach ((array) $candidates as $table) {
        $codigo = $wpdb->get_var("SHOW COLUMNS FROM `" . esc_sql($table) . "` LIKE 'codigo_jogo'");
        if ($codigo) { return $table; }
    }
    return '';
}

function rsb_confrontos_imediatos_run(): array {
    global $wpdb;
    $table = rsb_confrontos_imediatos_find_jogos_table();
    if ($table === '') {
        return ['ok'=>false, 'message'=>'Tabela de jogos não encontrada.'];
    }

    $updated = 0;
    $missing = [];
    $now = current_time('mysql');

    foreach (rsb_confrontos_imediatos_payload() as $codigo => $game) {
        $rows = $wpdb->get_results($wpdb->prepare("SELECT id FROM `$table` WHERE codigo_jogo = %s", $codigo));
        if (!$rows) {
            $missing[] = $codigo;
            continue;
        }

        foreach ($rows as $row) {
            $payload = $game;
            $payload['updated_at'] = $now;
            $wpdb->update($table, $payload, ['id' => (int) $row->id]);
            $updated++;
        }
    }

    update_option('rsb_confrontos_imediatos_20260704_result', [
        'executed_at' => $now,
        'table' => $table,
        'updated' => $updated,
        'missing' => $missing,
    ], false);

    return ['ok'=>true, 'table'=>$table, 'updated'=>$updated, 'missing'=>$missing];
}

add_action('admin_init', function () {
    if (!current_user_can('manage_options')) { return; }
    if (get_option('rsb_confrontos_imediatos_20260704_done')) { return; }
    $result = rsb_confrontos_imediatos_run();
    if (!empty($result['ok'])) {
        update_option('rsb_confrontos_imediatos_20260704_done', 1, false);
    }
});

add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) { return; }
    $result = get_option('rsb_confrontos_imediatos_20260704_result');
    if (!$result) { return; }
    echo '<div class="notice notice-success"><p><strong>RSB:</strong> confrontos M089 a M096 atualizados. Linhas atualizadas: ' . esc_html((string) ($result['updated'] ?? 0)) . '.</p></div>';
});
