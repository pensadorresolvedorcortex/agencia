# Resenha Sagrada - Bolao da Copa 26

Plugin WordPress para gerenciar o Bolao da Copa 2026 com cadastro/login proprio, participantes, pagamentos, jogos oficiais, palpites, ranking, premiacao e logs.

Versao atual: **2026.6**

## Instalacao e atualizacao

1. Envie a pasta `resenha-sagrada-bolao` para `wp-content/plugins/` ou instale o ZIP pelo painel do WordPress.
2. Ative o plugin em **Plugins**.
3. Acesse **Resenha Sagrada** no menu administrativo.
4. Configure o bolao e, se necessario, use **Importar Copa 2026** e **Importar Paginas**.
5. Ao atualizar de uma versao anterior, limpe cache de pagina/CDN/minificacao para carregar `assets/css/public.css` e `assets/js/public.js` novos.

## Shortcodes preservados

- `[resenha_sagrada_participante]` ou `[resenha_sagrada_app]` - area completa do mau elemento.
- `[resenha_sagrada_palpites]` - jogos abertos para registrar ou editar palpites.
- `[resenha_sagrada_meus_palpites]` - historico individual de palpites e pontos.
- `[resenha_sagrada_jogos]` - calendario de jogos.
- `[resenha_sagrada_ranking]` - ranking geral.
- `[resenha_sagrada_premiacao]` - premiacao estimada.
- `[resenha_sagrada_pagamento]` - status de pagamento do participante logado.
- `[resenha_sagrada_regras]` - regras do bolao.

## Regras de palpites

- O mau elemento pode criar ou editar palpites somente ate 1 hora antes da partida, no horario de Brasilia.
- Se nao palpitar antes do prazo, perdeu o direito daquele jogo.
- A validacao e feita no servidor.
- Placar vazio, negativo, texto ou decimal nao e aceito.
- Cada mau elemento tem apenas um palpite por jogo.
- Toda criacao/edicao gera log com usuario, participante, jogo, IP, user agent e valores antigos/novos.
- Resultado oficial so pontua quando o jogo estiver `finalizado`.

## Premiacao

A premiacao nao deve ser exibida em duplicidade. Em caso de empate na mesma posicao, o sistema soma os premios das posicoes ocupadas e divide igualmente entre os empatados.

## Copa 2026

Fases padronizadas:

- `grupos` - Fase de Grupos.
- `rodada_32` - 16-avos de Final / Rodada de 32.
- `oitavas` - Oitavas de Final.
- `quartas` - Quartas de Final.
- `semifinal` - Semifinal.
- `terceiro_lugar` - Disputa de 3o Lugar.
- `final` - Final.

Formato:

- 48 selecoes.
- 12 grupos com 4 selecoes.
- 2 primeiros de cada grupo classificam.
- 8 melhores terceiros classificam.
- 32 classificados entram na Rodada de 32.
- Depois seguem oitavas, quartas, semifinais, terceiro lugar e final.

## Login e cadastro

O cadastro e o login publicos continuam internos do plugin por AJAX. O mau elemento nao deve ser enviado para `wp-login.php`, `wp-admin` ou `admin-ajax.php` como tela final.

## Icones das selecoes

A versao 2026.6 adiciona `RSB_Teams`, com mapeamento centralizado de selecoes, ISO, emoji/icone e fallback. Jogos, palpites e historico passam a renderizar icones circulares por `RSB_Teams::render_flag($team_name)`. Placeholders de mata-mata usam icone neutro circular.

## Tabelas

- `wp_rs_temporadas`
- `wp_rs_boloes`
- `wp_rs_participantes`
- `wp_rs_jogos`
- `wp_rs_palpites`
- `wp_rs_pagamentos`
- `wp_rs_ranking`
- `wp_rs_logs`
- `wp_rs_palpite_logs`

## Versao 2026.6

- Atualizado cabecalho do plugin e constante `RSB_VERSION`.
- Home publica mantem logo oficial e bola oficial com visual Copa/Brasil e animacao suave.
- Adicionado helper `RSB_Teams` para flags, metadados e placeholders.
- Melhorada a responsividade de confrontos, inputs, botoes, tabelas e nomes longos.
- JS publico agora trata JSON invalido, erro de rede e retorno `0` do WordPress com mensagem clara.
- README atualizado com instalacao, shortcodes, regras, premiacao, Copa 2026, login/cadastro e cache.
