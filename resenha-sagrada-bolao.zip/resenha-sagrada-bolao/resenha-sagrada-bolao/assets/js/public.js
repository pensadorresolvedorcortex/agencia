jQuery(function($){
  function rsbMessage(resp, fallback){
    if(resp && resp.data && resp.data.message){ return resp.data.message; }
    if(resp && typeof resp.data === 'string'){ return resp.data; }
    return fallback;
  }

  function rsbPost(form, action, successFallback){
    const btn = form.find('button[type="submit"]');
    const original = btn.text();
    btn.prop('disabled', true).text('Aguarde...');
    $.ajax({
      url: RSB_PUBLIC.ajaxUrl,
      method: 'POST',
      dataType: 'json',
      data: form.serialize() + '&action=' + encodeURIComponent(action) + '&nonce=' + encodeURIComponent(RSB_PUBLIC.nonce) + '&current_url=' + encodeURIComponent(window.location.href)
    }).done(function(resp){
      if(resp && resp.success){
        alert(rsbMessage(resp, successFallback));
        if(resp.data && resp.data.redirect){
          window.location.href = resp.data.redirect;
          return;
        }
        location.reload();
        return;
      }
      alert(rsbMessage(resp, 'Erro ao processar. Tente novamente.'));
    }).fail(function(xhr){
      const body = (xhr.responseText || '').trim();
      alert(body === '0' ? 'Sessao expirada ou acao invalida. Recarregue a pagina e tente novamente.' : 'Nao foi possivel comunicar com o servidor. Tente novamente.');
    }).always(function(){
      btn.prop('disabled', false).text(original);
    });
  }

  $('.rsb-bet-form').on('submit',function(e){
    e.preventDefault();
    rsbPost($(this), 'rsb_save_bet', 'Palpite salvo com sucesso.');
  });

  $('.rsb-profile-form').on('submit',function(e){
    e.preventDefault();
    rsbPost($(this), 'rsb_update_profile', 'Dados atualizados.');
  });

  function showAuth(target){
    $('.rsb-auth-card').removeClass('rsb-auth-visible');
    $(target).addClass('rsb-auth-visible');
    document.querySelector(target)?.scrollIntoView({behavior:'smooth', block:'center'});
  }

  $(document).on('click','.rsb-show-register',function(e){
    e.preventDefault();
    showAuth('#rsb-register-form');
  });

  $(document).on('click','.rsb-show-login',function(e){
    e.preventDefault();
    showAuth('#rsb-login-form');
  });

  $('.rsb-plugin-register-form').on('submit',function(e){
    e.preventDefault();
    rsbPost($(this), 'rsb_plugin_register', 'Conta criada com sucesso.');
  });

  $('.rsb-plugin-login-form').on('submit',function(e){
    e.preventDefault();
    rsbPost($(this), 'rsb_plugin_login', 'Login realizado com sucesso.');
  });
});
