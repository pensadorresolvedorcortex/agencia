<?php if (!defined('ABSPATH')) exit; $fmt = class_exists('RSB_WorldCup_Format') ? RSB_WorldCup_Format::format_summary() : []; $login_url = '#rsb-login-form'; $register_url = '#rsb-register-form'; ?>
<div class="rsb-public rsb-app <?php echo !is_user_logged_in() ? 'rsb-guest' : 'rsb-auth'; ?>">
    <header class="rsb-world-header">
        <div class="rsb-brand-mark"><span>⚽</span></div>
        <div class="rsb-brand-copy">
            <strong>RESENHA <span>SAGRADA</span></strong>
            <small>Bolão da Copa 26</small><em class="rsb-mobile-cup-tag">🏆 Brasil na resenha • Copa 2026</em>
        </div>
        <nav class="rsb-top-nav">
            <a href="#rsb-palpites">⚽ Palpites</a>
            <a href="#rsb-meus">📝 Meus Palpites</a>
            <a href="#rsb-ranking">🏆 Ranking</a>
            <a href="#rsb-premiacao">💰 Premiação</a>
            <a href="#rsb-regras">📋 Regras</a>
        </nav>
    </header>

    <section class="rsb-copa-hero">
        <div>
            <span class="rsb-kicker">Copa do Mundo 2026</span>
            <h2><?php echo esc_html($bolao->nome ?? 'Resenha Sagrada — Bolão da Copa 26'); ?></h2>
            <p>48 seleções, 12 grupos, rodada de 32 e disputa até a grande final. Faça seus palpites com antecedência: o sistema bloqueia cada jogo 1MIN ANTES da partida.</p>
            <div class="rsb-hero-stats">
                <span><strong>104</strong> Jogos</span>
                <span><strong><?php echo esc_html($fmt['selecoes'] ?? 48); ?></strong> Seleções</span>
                <span><strong><?php echo esc_html($fmt['grupos'] ?? 12); ?></strong> Grupos</span>
                <span><strong>32</strong> Mata-mata</span>
            </div>
        </div>
        <div class="rsb-host-flags">
            <span><?php echo rsb_flag_html('Estados Unidos'); ?><small>EUA</small></span>
            <span><?php echo rsb_flag_html('Canadá'); ?><small>Canadá</small></span>
            <span><?php echo rsb_flag_html('México'); ?><small>México</small></span>
        </div>
    </section>

    <?php if(!is_user_logged_in()): ?>
        <section class="rsb-mobile-start rsb-legacy-home" aria-label="Acesso ao bolão">
            <div class="rsb-legacy-home-bg-ball" aria-hidden="true"></div>
            <div class="rsb-mobile-logo">
                <img class="rsb-home-logo-img" src="https://www.resenhasagrada.com.br/wp-content/uploads/2026/06/resenha.png" alt="Resenha Sagrada">
                <img class="rsb-home-ball-img" src="https://www.resenhasagrada.com.br/wp-content/uploads/2026/06/cropped-bola.png" alt="Bola de futebol">
                <small>Bolão da Copa 26</small><em class="rsb-mobile-cup-tag">🏆 Brasil na resenha • Copa 2026</em>
            </div>
            <div class="rsb-mobile-actions">
                <a class="button rsb-create-account rsb-show-register" href="#rsb-register-form">Criar conta</a>
                <a class="button rsb-login rsb-show-login" href="#rsb-login-form">Entrar</a>
            </div>
        </section>
        <div class="rsb-card rsb-auth-card rsb-login-card" id="rsb-login-form">
            <h3>Entrar no bolão</h3>
            <p>Entre sem sair desta página para registrar e editar seus palpites até 1 hora antes de cada jogo, pelo horário de Brasília.</p>
            <form class="rsb-plugin-login-form">
                <label>E-mail ou usuário<input type="text" name="login" autocomplete="username" required></label>
                <label>Senha<input type="password" name="senha" autocomplete="current-password" required></label>
                <button type="submit" class="button">Entrar</button>
            </form>
            <p class="rsb-auth-links">Ainda não é mau elemento? <a class="rsb-show-register" href="#rsb-register-form">Criar conta</a></p>
        </div>
        <div class="rsb-card rsb-auth-card rsb-register-card" id="rsb-register-form">
            <h3>Criar conta do mau elemento no bolão</h3>
            <p>Cadastro do mau elemento feito pelo próprio plugin. Após criar a conta, você entra automaticamente.</p>
            <form class="rsb-plugin-register-form">
                <label>Nome completo do mau elemento<input type="text" name="nome" minlength="3" autocomplete="name" required></label>
                <label>E-mail<input type="email" name="email" autocomplete="email" required></label>
                <label>Telefone / WhatsApp<input type="text" name="telefone" autocomplete="tel"></label>
                <label>Senha<input type="password" name="senha" minlength="6" autocomplete="new-password" required></label>
                <label>Confirmar senha<input type="password" name="senha2" minlength="6" autocomplete="new-password" required></label>
                <button type="submit" class="button rsb-create-account">Criar conta e entrar</button>
            </form>
            <p class="rsb-auth-links">Já tenho conta. <a class="rsb-show-login" href="#rsb-login-form">Entrar</a></p>
        </div>
    <?php elseif(!$participant): ?>
        <div class="rsb-card rsb-alert">Seu usuário WordPress ainda não está vinculado a um mau elemento ativo deste bolão. Peça ao administrador para vincular seu cadastro.</div>
        <?php echo do_shortcode('[resenha_sagrada_ranking]'); ?>
    <?php else: ?>
        <div class="rsb-grid rsb-grid-4">
            <div class="rsb-card"><span>Status</span><strong><?php echo esc_html(ucfirst($participant->status_pagamento)); ?></strong></div>
            <div class="rsb-card"><span>Valor pago</span><strong><?php echo esc_html(rsb_money((float)$participant->valor_pago)); ?></strong></div>
            <div class="rsb-card"><span>Mau elemento</span><strong><?php echo esc_html($participant->nome); ?></strong></div>
            <div class="rsb-card"><span>Premiação atual</span><strong><?php echo esc_html(rsb_money(((float)($premiacao['primeiro'] ?? 0)) + ((float)($premiacao['segundo'] ?? 0)) + ((float)($premiacao['terceiro'] ?? 0)))); ?></strong></div>
        </div>

        <section class="rsb-card rsb-profile-panel">
            <h3>Dados do Mau Elemento</h3>
            <form class="rsb-profile-form">
                <label>Nome do mau elemento no ranking<input type="text" name="nome" value="<?php echo esc_attr($participant->nome); ?>" required minlength="3"></label>
                <label>Telefone<input type="text" name="telefone" value="<?php echo esc_attr($participant->telefone); ?>"></label>
                <button type="submit" class="button">Salvar dados do mau elemento</button>
            </form>
            <small>O e-mail e o status de pagamento do mau elemento só podem ser alterados pelo administrador.</small>
        </section>

        <section id="rsb-palpites"><?php echo do_shortcode('[resenha_sagrada_palpites]'); ?></section>
        <section id="rsb-meus"><?php echo do_shortcode('[resenha_sagrada_meus_palpites]'); ?></section>
        <section id="rsb-ranking"><?php echo do_shortcode('[resenha_sagrada_ranking]'); ?></section>
        <section id="rsb-premiacao"><?php echo do_shortcode('[resenha_sagrada_premiacao]'); ?></section>
        <section id="rsb-regras"><?php echo do_shortcode('[resenha_sagrada_regras]'); ?></section>
    <?php endif; ?>

    <footer class="rsb-world-footer">
        <div><strong>Resenha Sagrada</strong><span>Aqui a resenha é sagrada, mas a disputa é séria.</span></div>
        <div class="rsb-footer-flags"><?php echo rsb_flag_html('Brasil'); ?><?php echo rsb_flag_html('Argentina'); ?><?php echo rsb_flag_html('França'); ?><?php echo rsb_flag_html('Alemanha'); ?><?php echo rsb_flag_html('Espanha'); ?></div>
        <div><small>Formato 2026: 2 primeiros de cada grupo + 8 melhores terceiros.</small></div>
    </footer>
</div>
