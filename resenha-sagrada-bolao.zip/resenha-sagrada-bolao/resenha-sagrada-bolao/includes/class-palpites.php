<?php
if (!defined('ABSPATH')) { exit; }
class RSB_Palpites {
    public static function all(int $bolao_id): array {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare("SELECT p.*, j.codigo_jogo, j.time_mandante, j.time_visitante, part.nome participante FROM ".rsb_table('palpites')." p JOIN ".rsb_table('jogos')." j ON j.id=p.jogo_id JOIN ".rsb_table('participantes')." part ON part.id=p.participante_id WHERE p.bolao_id=%d ORDER BY p.created_at DESC", $bolao_id));
    }

    public static function by_participant(int $bolao_id, int $participante_id): array {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare("SELECT p.*, j.codigo_jogo, j.fase, j.grupo, j.rodada, j.data_jogo, j.hora_jogo, j.time_mandante, j.time_visitante, j.gols_mandante, j.gols_visitante, j.status FROM ".rsb_table('palpites')." p JOIN ".rsb_table('jogos')." j ON j.id=p.jogo_id WHERE p.bolao_id=%d AND p.participante_id=%d ORDER BY COALESCE(j.data_jogo,'2099-12-31'), j.hora_jogo", $bolao_id, $participante_id));
    }

    public static function indexed_by_jogo(array $palpites): array {
        $out=[]; foreach($palpites as $p){ $out[(int)$p->jogo_id]=$p; } return $out;
    }

    public static function log_change(?int $palpite_id, int $bolao_id, int $participante_id, int $jogo_id, $old, $new, string $acao): void {
        global $wpdb;
        $wpdb->insert(rsb_table('palpite_logs'), [
            'palpite_id'=>$palpite_id,
            'bolao_id'=>$bolao_id,
            'participante_id'=>$participante_id,
            'jogo_id'=>$jogo_id,
            'valor_antigo'=> $old === null ? null : wp_json_encode($old, JSON_UNESCAPED_UNICODE),
            'valor_novo'=> $new === null ? null : wp_json_encode($new, JSON_UNESCAPED_UNICODE),
            'acao'=>$acao,
            'ip'=>sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? ''),
            'user_agent'=>substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
            'created_at'=>current_time('mysql'),
        ]);
    }

    public static function upsert(array $data) {
        global $wpdb;
        $jogo=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".rsb_table('jogos')." WHERE id=%d", (int)$data['jogo_id']));
        if(!$jogo){ return new WP_Error('jogo_invalido', 'Jogo não encontrado.'); }
        if(!RSB_Jogos::is_bettable($jogo)){
            return new WP_Error('palpite_bloqueado', 'Palpites encerram 1 hora antes da partida, pelo horário de Brasília. Não é possível criar ou editar este palpite.');
        }
        if(!isset($data['palpite_gols_mandante'], $data['palpite_gols_visitante']) || $data['palpite_gols_mandante'] === '' || $data['palpite_gols_visitante'] === ''){
            return new WP_Error('placar_obrigatorio', 'Informe os dois placares antes do prazo. Palpite vazio não poderá ser preenchido depois.');
        }
        if(!is_numeric($data['palpite_gols_mandante']) || !is_numeric($data['palpite_gols_visitante'])){
            return new WP_Error('placar_invalido', 'Use apenas números inteiros nos placares.');
        }
        $gm = (int)$data['palpite_gols_mandante'];
        $gv = (int)$data['palpite_gols_visitante'];
        if((string)$gm !== (string)$data['palpite_gols_mandante'] || (string)$gv !== (string)$data['palpite_gols_visitante'] || $gm < 0 || $gv < 0){
            return new WP_Error('placar_invalido', 'Use apenas números inteiros iguais ou maiores que zero.');
        }
        $now=current_time('mysql');
        $payload=[
            'bolao_id'=>(int)$jogo->bolao_id,
            'jogo_id'=>(int)$jogo->id,
            'participante_id'=>(int)$data['participante_id'],
            'palpite_gols_mandante'=>$gm,
            'palpite_gols_visitante'=>$gv,
            'updated_at'=>$now
        ];
        $existing=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".rsb_table('palpites')." WHERE jogo_id=%d AND participante_id=%d", (int)$jogo->id, (int)$data['participante_id']));
        if($existing){
            $wpdb->update(rsb_table('palpites'),$payload,['id'=>(int)$existing->id]);
            self::log_change((int)$existing->id, (int)$jogo->bolao_id, (int)$data['participante_id'], (int)$jogo->id, $existing, $payload, 'editar');
            rsb_log('atualizar','palpite',(int)$existing->id,$existing,$payload);
            return (int)$existing->id;
        }
        $payload['created_at']=$now;
        $wpdb->insert(rsb_table('palpites'),$payload);
        $id=(int)$wpdb->insert_id;
        self::log_change($id, (int)$jogo->bolao_id, (int)$data['participante_id'], (int)$jogo->id, null, $payload, 'criar');
        rsb_log('criar','palpite',$id,null,$payload);
        return $id;
    }
}
