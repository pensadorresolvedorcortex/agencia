=== Bold Page Builder ===
Contributors: boldthemes
Tags: wordpress page builder, drag and drop, editor, page builder, site builder
Requires at least: 5.0
Tested up to: 7.0
Stable tag: 5.9.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Free Page Builder and Visual Composer - Build stunning responsive post and page layouts with easy to use drag and drop builder - no coding required.

== Description ==

= Forever 100% Free page builder = 

Bold Page Builder for WordPress is 100% free - there is no premium version and you can use it freely in your commercial and noncommercial projects. Even in your Premium WordPress themes.

= FRONT-END EDITOR | NEW FROM 2022! = 

From Bold Builder version 4.0.0. you can easily manage your content both backend and frontend with newly added functionality. Our drag and drop Bold Page Builder just got better with adding easy to use front end editing options. Now you can view your website pages as you edit them.

[youtube https://www.youtube.com/watch?v=8ftwyKO_3ok]

> **Create your premium looking website using only default Twenty Seventeen or Twenty Sixteen theme and Bold Page Builder**
>
> See Bold Page Builder in action! 
> Check out our demo pages built with [Twenty Seventeen theme](https://wordpress.org/themes/twentyseventeen/):
>
> * [Wedding 2017 Demo](http://demos.bold-themes.com/demo-wedding-2017/ "Wedding WordPress Website Demo")
> * [Accommodation 2017 Demo](http://demos.bold-themes.com/demo-accomodation-2017/ "Accomodation WordPress Website Demo")
> * [Construction 2017 Demo](http://demos.bold-themes.com/demo-construction-2017/ "Construction company WordPress Website Demo")
>
> Check out our demo pages built with [Twenty Sixteen theme](https://wordpress.org/themes/twentysixteen/):
>
> * [Restaurant 2016 Demo](http://demos.bold-themes.com/demo-restaurant-2016/ "Restaurant WordPress Website Demo")
> * [Handyman 2016 Demo](http://demos.bold-themes.com/demo-handyman-2016/ "Small Business WordPress Website Demo")
> * [Wedding 2016 Demo](http://demos.bold-themes.com/demo-wedding-2016/ "Celebration WordPress Website Demo")
>
> Our demos use the following free plugins:
>
> * [Customize Twenty Seventeen](https://wordpress.org/plugins/customize-twenty-seventeen/ "Customize Twenty Seventeen WordPress Plugin")
> * [Customize Twenty Sixteen](https://wordpress.org/plugins/customize-twenty-sixteen/ "Customize Twenty Sixteen WordPress Plugin")
>
> When you are ready for the next step, we also offer a selection of premium themes which are using Bold Page Builder: [BoldThemes Portfolio](https://themeforest.net/user/boldthemes/portfolio?ref=bold-page-builder "BoldThemes Portfolio").

= Comes with 30+ Content Elements =

Bold Builder - WordPress Page builder comes packed with loads of content elements - you can start building your layouts in minutes with drag and drop features and with no coding experience. And it is very easy to extend.

* Accordion
* Button
* Cost calculator
* Headline
* Icon
* Image
* Latest posts
* Masonry image grid
* Masonry post grid
* Price list
* Raw HTML/JS content
* Separator
* Service
* Slider
* Tabs
* Text
* Video

= Ideal for theme and WordPress developers =

If you are a WordPress developer, feel free to extend it with your components - it features simple and intuitive API as well as a detailed developer's documentation and examples to get you started right away. 

= Lightning fast Visual Builder =

It is a speed champion and only WordPress drag and drop page builder with the instant user interface response - no more waiting and nail biting. Beats popular Visual Composer by a mile.

= 100% Compatible with most WordPress themes =

Bold Builder should work with most of the themes - free or premium. In fact, all demos are developed using free themes and plugins from WordPress.org. You can import these pages and choose from a selection of carefully crafted design elements. For detailed instructions on how to install demos please read [Online Documentation ](http://documentation.bold-themes.com/bold-builder/getting-started/#installing-demo-content).

= Full Clipboard functionality unlike any other WordPress Page Builder plugin =

Do not restrict yourself to duplicating your content elements within one page like others do. Now, you can copy any content element them from one page to another and even from one site to another. Unlike with any other page builder plugin. Finally, unleash the full power of content element clipboard and make your life do much easier.

= Actively developed and supported =

Bold Page Builder is actively developed by [BoldThemes](http://www.bold-themes.com/ "Premium WordPress Themes") , authors of a number of free and premium WordPress themes and plugins. We are committed to making it the greatest free WordPress page builder plugin ever and expect constant flow of new and exciting features.    

Bold Builder is supported through our [support forum](https://wordpress.org/support/plugin/bold-page-builder "Support Forum").

For detailed online documentation go to [Bold Builder Online Documentation](http://documentation.bold-themes.com/bold-builder/getting-started/).

To read more about Bold Builder visit our [website](https://bold-builder.bold-themes.com/).

Important: Please note that our premium themes launched before June 1, 2017 will not have all the options described in this article.

== Installation ==

= Method 1 =

Use WordPress Add New Plugin feature and search Bold Page Builder 

[youtube https://www.youtube.com/watch?v=FYFGEE5LFvg]

= Method 2 =

Download the archive [here](https://downloads.wordpress.org/plugin/bold-page-builder.zip) and:

1. Unzip the archive on your computer
2. Upload bold-page-builder directory to the /wp-content/plugins/ directory
3. Activate the plugin through the Plugins menu in WordPress

== Frequently Asked Questions ==

= How does this compare to front end builders? =
 
While front end builders are nice and easy to use with simple content, there is no substitute for robustness of good back end builder in case you want to build complex layouts. Once you get to know it, Bold Builder, with its advanced capabilities (like stacked clipboard and non-AJAX instant editing), is the fastest way to build your pages.
 
= Is there a premium version? =
 
No. Actually this is premium version, only difference is that it's free. :)

= Which themes are supported? =
 
It is not possible to test Bold Builder with all themes - it should work fine with most but we recommend Twenty Sixteen and Twenty Seventeen themes. Also, in case you want to use our premium themes, you can find them here: [BoldThemes Portfolio](https://themeforest.net/user/boldthemes/portfolio?ref=bold-page-builder "BoldThemes Portfolio"). Please note that BoldThemes premium themes launched before June 1, 2017 will not have all the options described in this article.

= Where do I report security bugs found in this plugin? =

Please report security bugs found in the source code of the Bold Page Builder plugin through the [Patchstack Vulnerability Disclosure  Program](https://patchstack.com/database/vdp/ae9893db-5fd0-4046-9906-46baaaf68839). The Patchstack team will assist you with verification, CVE assignment, and notify the developers of this plugin.

== Screenshots ==

1. Bold Page Builder - Interface
2. Bold Page Builder - Elements
3. Bold Page Builder - Element properties
4. Bold Page Builder - Preview mode
5. Bold Page Builder - Drag and Drop interface
6. Bold Page Builder - Icon element
7. Bold Page Builder - Column layouts
8. Bold Page Builder - Settings

== Changelog ==

= 5.9.6 =
* Security: the Post Grid and Image Grid elements now build their lazy-loaded images through DOM attributes instead of HTML string concatenation, preventing a stored XSS via a crafted attachment ALT text or title (authenticated, media-uploading users).
* Security: the Service element now validates its title HTML tag against an allow list, preventing a stored XSS via a crafted tag name (authenticated, content-editing users).

= 5.9.5 =
* Security: escaped the shortcode `bb_version` attribute before it is written into the rendered output, preventing a stored XSS via a crafted attribute value (authenticated, content-editing users).
* Security: added a capability check and nonce verification to the builder link-search AJAX endpoint, so it can no longer be used to enumerate posts, pages, and media URLs/metadata by low-privileged or cross-site requests.

= 5.9.4 =
* Fixed colored-icon SVGs being stripped in the front-end editor preview (added inline SVG to the editor re-render kses allowlist).

= 5.9.3 =
* Redesigned the Row "Columns layout" control: row width and column structure are now selected separately, with the column structure shown as layout preview thumbnails.
* Fixed horizontal page overflow on rows configured with large gaps.

= 5.9.2 =
* Security: hardened the Raw Content save filter against a null-byte / control-character bypass that could allow Contributor-level users to store executable scripts (CVE-2026-5920).

= 5.9.1 =
* Fixed CSS Post Grid not rendering the excerpt, share, date, and super/subheadline when those options were enabled.
* Fixed category filtering on the CSS Post Grid and Masonry Post Grid for categories with encoded (non-ASCII) slugs.

= 5.9.0 =
* Added 1300, 1500, and 1600 pixel boxed row widths to the Section and Row "Columns layout" / "Row width" dropdowns (alongside the existing 1200 and 1400 options).
* Fixed an unwanted border that appeared around colored headlines on recent WordPress versions.
* Fixed Latest Posts author meta rendering as literal HTML markup instead of a clickable author link.

= 5.8.2 =
* Minor bug fixes and improvements.

= 5.8.1 =
* Fixed JavaScript errors triggered by clicks on SVG elements from third-party plugins (cookie banners, social widgets, etc.).
* Fixed unresponsive Front-end editor clicks on macOS / Safari — the edit drawer now opens reliably on the first click.
* `Publish until` / `Hide until` scheduling now uses the site timezone with minute precision; leaving the field blank correctly means "no limit".
* Hardened AJAX input handling, output escaping, and external HTTP calls.
* Replaced legacy database lookups and cURL calls with WordPress core APIs (`wp_remote_*`, `get_page_by_path`) for better compatibility and caching.
* Improved security.

= 5.8.0 =
* Hardened all plugin PHP files against direct file access.
* Reduced scroll jitter on parallax background sections in Chrome.
* Improved security.
* Renamed text domain from `bold-builder` to `bold-page-builder` to match the WordPress.org plugin slug. **Existing translations using the old text domain will need to be re-imported under the new domain.**

= 5.7.3 =
* Improved security.

= 5.7.2 =
* Minor bug fixes.

= 5.7.1 =
* Improved security.

= 5.7.0 =
* Improved security.

= 5.6.9 =
* Improved security.

= 5.6.8 =
* Improved security.

= 5.6.7 =
* Fixed Icon editing in FE editor.

= 5.6.6 =
* Fixed Text editing in FE editor.

= 5.6.5 =
* Fixed Text editing in FE editor.

= 5.6.4 =
* Improved security.

= 5.6.3 =
* Minor bug fixes.

= 5.6.2 =
* Minor bug fixes.

= 5.6.1 =
* Fixed scroll in FE editor.

= 5.6.0 =
* Minor bug fixes.

= 5.5.9 =
* Minor bug fixes.

= 5.5.8 =
* Minor bug fixes.

= 5.5.7 =
* Fixed color schemes & custom CSS.

= 5.5.6 =
* Fixed FE editing.

= 5.5.5 =
* Improved security.

= 5.5.4 =
* Improved security.

= 5.5.3 =
* Improved security.

= 5.5.2 =
* Minor bug fixes and improvements.

= 5.5.1 =
* Minor bug fixes and improvements.

= 5.5.0 =
* Minor bug fixes and improvements.

= 5.4.9 =
* Minor bug fixes and improvements.

= 5.4.8 =
* Minor bug fixes and improvements.

= 5.4.7 =
* Minor bug fixes and improvements.

= 5.4.6 =
* Improved security.

= 5.4.5 =
* Minor bug fixes.

= 5.4.4 =
* Minor bug fixes.

= 5.4.3 =
* Minor bug fixes.

= 5.4.2 =
* Minor bug fixes.

= 5.4.1 =
* Minor bug fixes.

= 5.4.0 =
* Minor bug fixes.

= 5.3.9 =
* Minor bug fixes.

= 5.3.8 =
* New responsive breakpoint added to elements.
* Minor bug fixes and improvements.

= 5.3.7 =
* Improved security.
* Improved UI.

= 5.3.6 =
* Improved security.

= 5.3.5 =
* Improved WPML support.

= 5.3.4 =
* Fixed BE editing.

= 5.3.3 =
* Improved security.

= 5.3.2 =
* Fixed parallax.
* Fixed text indentation.

= 5.3.1 =
* Improved security.

= 5.3.0 =
* Minor bug fixes.

= 5.2.9 =
* Minor bug fixes.

= 5.2.8 =
* Minor bug fixes.

= 5.2.7 =
* Minor bug fixes.

= 5.2.6 =
* Fixed Slider Item Background overlay option in FE editor.

= 5.2.5 =
* Fixed option to disable lazy loading.

= 5.2.4 =
* Minor bug fixes and improvements.

= 5.2.3 =
* Minor bug fixes and improvements.

= 5.2.2 =
* Minor bug fixes and security improvements.

= 5.2.1 =
* Minor bug fixes and improvements.

= 5.2.0 =
* Improved performance.
* Minor bug fixes and improvements.

= 5.1.6 =
* Improved security.

= 5.1.5 =
* Minor bug fixes.

= 5.1.4 =
* Added more options to FE editor.
* Improved security.

= 5.1.3 =
* Minor bug fixes.
* Improved security.

= 5.1.2 =
* Minor bug fixes.
* Improved security.

= 5.1.1 =
* Minor bug fixes.

= 5.1.0 =
* Improved security.

= 5.0.9 =
* Minor bug fixes.

= 5.0.8 =
* Minor bug fixes.

= 5.0.7 =
* Minor bug fixes.

= 5.0.6 =
* Minor bug fixes.

= 5.0.5 =
* Minor bug fixes.
* Improved security.

= 5.0.4 =
* Minor bug fixes.

= 5.0.3 =
* Minor bug fixes.

= 5.0.2 =
* Added undo/redo on FE.
* Minor bug fixes and improvements.

= 5.0.1 =
* Minor bug fixes and improvements.

= 5.0.0 =
* Fixed Text saving.

= 4.9.9 =
* Fixed Text editing after copy-paste.
* Added template cache.

= 4.9.8 =
* Minor bug fixes.

= 4.9.7 =
* Minor bug fixes.

= 4.9.6 =
* Minor bug fixes.

= 4.9.5 =
* Minor bug fixes.

= 4.9.4 =
* Minor bug fixes.

= 4.9.3 =
* Minor bug fixes.

= 4.9.2 =
* Now possible to add elements on FE.
* Minor bug fixes and improvements.

= 4.9.1 =
* Minor bug fixes.

= 4.9.0 =
* Minor bug fixes.

= 4.8.9 =
* Added drag and drop on FE.
* Minor bug fixes and improvements.

= 4.8.8 =
* Minor bug fixes.

= 4.8.7 =
* Minor bug fixes.

= 4.8.6 =
* Fixed Text editing.
* Added HTML tag option to Service and Headline

= 4.8.5 =
* Fixed Text editing.
* Fixed FE editor toggle button.
* Improved Yoast compatibility.

= 4.8.4 =
* Fixed Raw Content.

= 4.8.3 =
* Fixed URLs.

= 4.8.2 =
* Fixed Image Slider.

= 4.8.1 =
* Added new AI options.
* Improved security.

= 4.8.0 =
* Added Shortcode content element.

= 4.7.9 =
* Minor bug fixes.

= 4.7.8 =
* Fixed font loading.

= 4.7.7 =
* Fixed background image editing on FE.
* Added Column background color editing on FE.
* Other minor bug fixes and improvements.

= 4.7.6 =
* Added tab navigation in FE editor.

= 4.7.5 =
* Fixed icon adding issue on BE.

= 4.7.4 =
* Fixed icon preview on BE.

= 4.7.3 =
* Minor bug fixes.

= 4.7.2 =
* Minor bug fixes.

= 4.7.1 =
* Minor bug fixes.
* Removed some deprecated elements.

= 4.7.0 =
* Added OpenAI API support.

= 4.6.1 =
* Fixed Google indexing issue.

= 4.6.0 =
* Minor bug fixes.

= 4.5.9 =
* Minor bug fixes.

= 4.5.8 =
* Minor bug fixes.

= 4.5.7 =
* Fixed Section cloning on front end.
* Improved UI.

= 4.5.6 =
* Minor bug fixes.

= 4.5.5 =
* Minor bug fixes.

= 4.5.4 =
* Minor bug fixes.

= 4.5.3 =
* Minor bug fixes.

= 4.5.2 =
* Added 1400px breakpoint.

= 4.5.1 =
* Minor bug fixes.

= 4.5.0 =
* Minor bug fixes.

= 4.4.9 =
* Fixed Countdown.

= 4.4.8 =
* Added alt attribute to CSS Image Grid.

= 4.4.7 =
* Added Esc key shortcut for closing a dialog.

= 4.4.6 =
* Fixed Section video.

= 4.4.5 =
* Minor bug fixes.

= 4.4.4 =
* Added Clone option on front end.

= 4.4.3 =
* Added Delete option on front end.

= 4.4.2 =
* Added CSS Image Grid.

= 4.4.1 =
* Fixed Section video.

= 4.4.0 =
* Fixed lightbox.

= 4.3.9 =
* Minor bug fixes.

= 4.3.8 =
* Fixed PHP warning in bt_bb_row.

= 4.3.7 =
* Minor bug fixes.

= 4.3.6 =
* Minor bug fixes.

= 4.3.5 =
* Minor bug fixes.

= 4.3.4 =
* Fixed overflow issue.

= 4.3.3 =
* Improved security.

= 4.3.2 =
* Fixed Masonry Image Grid.

= 4.3.1 =
* Added missing files.

= 4.3.0 =
* Improved interface.
* Fixed lightbox.

= 4.2.5 =
* Minor bug fixes.

= 4.2.4 =
* Minor bug fixes.

= 4.2.3 =
* Slider extra options, lightbox video.

= 4.2.2 =
* Fixed HTML validation issue.

= 4.2.1 =
* Fixed parallax.

= 4.2.0 =
* Fixed parallax.

= 4.1.9 =
* Fixed parallax.

= 4.1.8 =
* Minor bug fixes.

= 4.1.7 =
* Minor bug fixes.

= 4.1.6 =
* Improved Separator compatibility.

= 4.1.5 =
* Improved Separator.

= 4.1.4 =
* New Separator options.
* Enabled FE saving with Raw Content element.

= 4.1.3 =
* Minor bug fixes.

= 4.1.2 =
* Minor bug fixes.

= 4.1.1 =
* Improved compatibility with some themes.

= 4.1.0 =
* Improved compatibility with some themes.

= 4.0.9 =
* Minor bug fixes.

= 4.0.8 =
* Fixed broken menu (widgets related issue).

= 4.0.7 =
* Improved compatibility with some server configurations.

= 4.0.6 =
* Improved compatibility with some themes.

= 4.0.5 =
* Minor bug fixes.

= 4.0.4 =
* Minor bug fixes.

= 4.0.3 =
* Minor bug fixes.

= 4.0.2 =
* Improved compatibility with some themes.

= 4.0.1 =
* Improved compatibility with Yoast SEO plugin.

= 4.0.0 =
* Added front-end editor.

= 3.2.5 =
* Fixed Google Maps.

= 3.2.4 =
* Improved RTL support.

= 3.2.3 =
* Improved WPML support.

= 3.2.2 =
* Minor bug fixes.

= 3.2.1 =
* Updated Google Fonts list.

= 3.2.0 =
* Fixed background position. 

= 3.1.9 =
* Fixed full screen text editing.

= 3.1.8 =
* Fixed animation delay.

= 3.1.7 =
* Fixed grid CSS.

= 3.1.6 =
* Fixed potential security issue in Masonry Post Grid element.

= 3.1.5 =
* Fixed grid CSS.
* Fixed pasting.

= 3.1.4 =
* Fixed content element animation.

= 3.1.3 =
* Added content element animation.
* Fixed Custom CSS.

= 3.1.2 =
* Fixed Portfolio filtering.

= 3.1.1 =
* Added missing JS file.

= 3.1.0 =
* Added opacity in color control.

= 3.0.9 =
* Minor bug fixes.

= 3.0.8 =
* Improved BB Text Image widget interface.

= 3.0.7 =
* Fixed alignment.

= 3.0.6 =
* Minor bug fixes.

= 3.0.5 =
* Fixed dropdown selected value.

= 3.0.4 =
* Minor bug fixes.

= 3.0.3 =
* Minor bug fixes.

= 3.0.2 =
* Minor bug fixes.

= 3.0.1 =
* Improved backward compatibility.

= 3.0.0 =
* Added responsive layout.
* Added responsive override options.
* Added native lazy loading for Image.

= 2.8.1 =
* Improved Accordion.

= 2.8.0 =
* Added scroll nav offset JS interface.

= 2.7.9 =
* Added sticky header offset JS interface.

= 2.7.8 =
* Minor bug fixes.

= 2.7.7 =
* Minor bug fixes.

= 2.7.6 =
* Minor bug fixes.

= 2.7.5 =
* Minor bug fixes.

= 2.7.4 =
* Google Fonts list update.

= 2.7.3 =
* Minor bug fixes.

= 2.7.2 =
* Minor bug fixes.

= 2.7.1 =
* Improved WordPress 5.5 compatibility

= 2.7.0 =
* Improved WordPress 5.5 compatibility

= 2.6.9 =
* Minor bug fixes.

= 2.6.8 =
* Minor bug fixes.

= 2.6.7 =
* Minor bug fixes.

= 2.6.6 =
* Minor bug fixes and improvements.

= 2.6.5 =
* Allowed ul, ol, li in textarea.

= 2.6.4 =
* Lazy load fix.

= 2.6.3 =
* Fixed Firefox regex bug.

= 2.6.2 =
* Minor bug fixes.

= 2.6.1 =
* Minor bug fixes.

= 2.6.0 =
* Minor bug fixes.

= 2.5.9 =
* Fixed lightbox.

= 2.5.8 =
* Minor bug fixes.

= 2.5.7 =
* Minor bug fixes.

= 2.5.6 =
* Added WhatsApp sharing.

= 2.5.5 =
* Fixed Custom Menu.

= 2.5.4 =
* Minor bug fixes.

= 2.5.3 =
* Fixed OpenStreetMap.

= 2.5.2 =
* Fixed BB Instagram widget PHP notice.

= 2.5.1 =
* Fixed BB Instagram widget PHP notice.

= 2.5.0 =
* BB Instagram widget update.

= 2.4.9 =
* Improved PHP 7.4 compatibility.

= 2.4.8 =
* Minor bug fixes.

= 2.4.7 =
* Improved PHP 7.4 compatibility.

= 2.4.6 =
* Improved PHP 7.4 compatibility.

= 2.4.5 =
* Added option to insert HTML in Price List.

= 2.4.4 =
* Minor bug fixes.

= 2.4.3 =
* Google Fonts list update.
* Minor bug fixes and improvements.

= 2.4.2 =
* Minor bug fixes.

= 2.4.1 =
* Minor bug fixes.

= 2.4.0 =
* Fixed Icon URL.

= 2.3.9 =
* Fixed Countdown content element.

= 2.3.8 =
* Minor bug fixes and improvements.

= 2.3.7 =
* Fixed Instagram error.

= 2.3.6 =
* Minor bug fixes and improvements.

= 2.3.5 =
* Fixed repeated saving of Custom CSS.

= 2.3.4 =
* Minor bug fixes and improvements.

= 2.3.3 =
* Improved security.

= 2.3.2 =
* Improved security.

= 2.3.1 =
* Minor bug fixes and improvements.

= 2.3.0 =
* Minor bug fixes and improvements.

= 2.2.9 =
* Minor bug fixes and improvements.

= 2.2.8 =
* Fixed parallax.

= 2.2.7 =
* Minor bug fixes and improvements.

= 2.2.6 =
* Added OpenStreetMap content element.
* Added Contact Form 7 content element.
* Minor bug fixes and improvements.

= 2.2.5 =
* Fixed Service link target.

= 2.2.4 =
* Lazy load fix.

= 2.2.3 =
* Minor bug fixes.

= 2.2.2 =
* Minor bug fixes.

= 2.2.1 =
* Added image lazy loading for some content elements.

= 2.2.0 =
* Fixed button URL.

= 2.1.9 =
* Fixed heading URL.

= 2.1.8 =
* Minor bug fixes.

= 2.1.7 =
* Added placeholder image to Image Slider.

= 2.1.6 =
* Minor bug fixes.

= 2.1.5 =
* Weather widget update.

= 2.1.4 =
* Improved compatibility with some 3rd party plugins.

= 2.1.3 =
* Minor bug fixes.

= 2.1.2 =
* Improved WordPress 5.x compatibility.

= 2.1.1 =
* Fixed BB Icon widget.

= 2.1.0 =
* Improved WordPress 5.x compatibility.

= 2.0.9 =
* Improved drag and drop.

= 2.0.8 =
* Fixed back-end JS error.

= 2.0.7 =
* Improved compatibility with Yoast SEO plugin.

= 2.0.6 =
* Improved CSS editor.

= 2.0.5 =
* Fixed Headline URL.

= 2.0.4 =
* Fixed Button URL.

= 2.0.3 =
* Added Instagram image alt attribute.

= 2.0.2 =
* Fixed dialog height.

= 2.0.1 =
* Improved WordPress 5.x compatibility.

= 2.0.0 =
* Improved Instagram widget and content element.

= 1.9.9 =
* Fixed number of posts in Latest Posts content element.

= 1.9.8 =
* Fixed Image alt attribute.

= 1.9.7 =
* Removed Google Maps scroll prevent script.

= 1.9.6 =
* Fixed Recent Posts widget PHP notice.

= 1.9.5 =
* Fixed Inner Row layout.

= 1.9.4 =
* Fixed Post Grid hover bug.

= 1.9.3 =
* Fixed JS error when adding some content elements.

= 1.9.2 =
* Improved Gutenberg compatibility.

= 1.9.1 =
* Fixed Recent Comments widget.

= 1.9.0 =
* Fixed responsive lightbox and parallax.

= 1.8.9 =
* Fixed parallax on Chrome.

= 1.8.8 =
* Fixed Google Maps CSS.

= 1.8.7 =
* BB is now default editor for pages.

= 1.8.6 =
* Fixed Google Maps in Tabs.

= 1.8.5 =
* Added text domain to header.

= 1.8.4 =
* Fixed Post Grid and Latest Posts.

= 1.8.3 =
* Fixed back end CSS.

= 1.8.2 =
* Added bt_bb_content_elements filter.

= 1.8.1 =
* Improved PHP 7.x compatibility.

= 1.8.0 =
* Fixed Icon content element.

= 1.7.9 =
* Fixed Latest Posts content element.

= 1.7.8 =
* Fixed lightbox CSS.

= 1.7.7 =
* Fixed lightbox.

= 1.7.6 =
* Added option to close all Accordion items initially.

= 1.7.5 =
* Fixed Service title and target.

= 1.7.4 =
* Improved Image hover.

= 1.7.3 =
* Fixed lightbox.

= 1.7.2 =
* Fixed front end script enqueue issue.

= 1.7.1 =
* Improved speed.

= 1.7.0 =
* Fixed PHP notice.

= 1.6.9 =
* Improved speed.

= 1.6.8 =
* Fixed wpautop filter issue.

= 1.6.7 =
* Improved compatibility with dsIDXpress IDX Plugin.

= 1.6.6 =
* Fixed Google Maps JS error.

= 1.6.5 =
* Fixed PHP notice in BB Icon widget.

= 1.6.4 =
* Added option to disable auto loading in Post Grid.

= 1.6.3 =
* Fixed PHP notice.

= 1.6.2 =
* Fixed AJAX loading in Post Grid.

= 1.6.1 =
* Added AJAX loading in Post Grid.

= 1.6.0 =
* Fixed Column background image.

= 1.5.9 =
* Improved compatibility with some themes.

= 1.5.8 =
* Fixed Twitter widget.

= 1.5.7 =
* Fixed Slider height.

= 1.5.6 =
* Fixed Masonry Post Grid.

= 1.5.5 =
* Fixed PHP warning.

= 1.5.4 =
* Improved Instagram widget.

= 1.5.3 =
* Fixed BB Icon widget saving.

= 1.5.2 =
* Improved Cost Calculator plugin compatibility.

= 1.5.1 =
* Improved IE compatibility.

= 1.5.0 =
* Improved backwards compatibility.

= 1.4.9 =
* Added new animations.

= 1.4.8 =
* Fixed IE/Edge Counter CSS.

= 1.4.7 =
* Added icon picker in BB Icon widget.

= 1.4.6 =
* Fixed slider in tabs.

= 1.4.5 =
* Fixed iOS resize bug.

= 1.4.4 =
* Fixed IE animations.

= 1.4.3 =
* Fixed animations.

= 1.4.2 =
* Added content elements CSS filters.

= 1.4.1 =
* Fixed color schemes.

= 1.4.0 =
* Fixed PHP notice.

= 1.3.9 =
* Fixed animations.

= 1.3.8 =
* Added responsive options.

= 1.3.7 =
* Added slider fade animation.

= 1.3.6 =
* Fixed post content if BB is disabled for post type.

= 1.3.5 =
* Fixed Counter content element.

= 1.3.4 =
* Fixed text editor dropdowns.

= 1.3.3 =
* Improved unit test compatibility.

= 1.3.2 =
* Fixed OAuth namespace.

= 1.3.1 =
* Fixed IE layout bug.

= 1.3.0 =
* Fixed Image content element.

= 1.2.9 =
* Added class filter in Section.

= 1.2.8 =
* Fixed Instagram widget.

= 1.2.7 =
* Added Countdown content element.

= 1.2.6 =
* Fixed Heading link target.

= 1.2.5 =
* Additional Image options.

= 1.2.4 =
* Improved Masonry layout.

= 1.2.3 =
* Added some widgets - Instagram, Twitter, Weather, Time, etc.
* Improved Masonry Image Grid layout.

= 1.2.2 =
* Added Google Maps icon.

= 1.2.1 =
* Added Counter content element.

= 1.2.0 =
* Fixed Section navigation.

= 1.1.9 =
* Improved WP 4.7.4 compatibility.

= 1.1.8 =
* Improved Custom CSS compatibility.

= 1.1.7 =
* Added Slider content element.

= 1.1.6 =
* Fixed front end script enqueue issue.

= 1.1.5 =
* Added color scheme filter.

= 1.1.4 =
* Added Section background color.

= 1.1.3 =
* Fixed default layout in Section.

= 1.1.2 =
* Fixed preview of images in edit dialog.

= 1.1.1 =
* Improved wpautop filter handling.

= 1.1.0 =
* Fixed theme config file path.

= 1.0.9 =
* Fixed image preview caching.

= 1.0.8 =
* Improved image preview.

= 1.0.7 =
* Improved image preview.

= 1.0.6 =
* Fixed color scheme preview.

= 1.0.5 =
* Minor bug fixes.
* Removed import files (can be downloaded separately).

= 1.0.4 =
* Improved image preview.

= 1.0.3 =
* Improved image preview.

= 1.0.2 =
* Minor bug fixes.

= 1.0.1 =
* Minor bug fixes.

= 1.0.0 =
* Initial release.