<?php
$buro_mikado_sidebar = buro_mikado_get_sidebar();
?>
<div class="mkd-column-inner">
    <aside class="mkd-sidebar">
        <?php
            if (is_active_sidebar($buro_mikado_sidebar)) {
                dynamic_sidebar($buro_mikado_sidebar);
            }
        ?>
    </aside>
</div>
