<?php
do_action('buro_mikado_style_dynamic');