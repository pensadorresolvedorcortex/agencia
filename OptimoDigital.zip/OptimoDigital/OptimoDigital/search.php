<?php $buro_mikado_sidebar = buro_mikado_sidebar_layout(); ?>
<?php get_header(); ?>
<?php 

$buro_mikado_blog_page_range = buro_mikado_get_blog_page_range();
$buro_mikado_max_number_of_pages = buro_mikado_get_max_number_of_pages();

if ( get_query_var('paged') ) { $buro_mikado_paged = get_query_var('paged'); }
elseif ( get_query_var('page') ) { $buro_mikado_paged = get_query_var('page'); }
else { $buro_mikado_paged = 1; }
?>
<?php buro_mikado_get_title(); ?>
	<div class="mkd-container">
		<?php do_action('buro_mikado_after_container_open'); ?>
		<div class="mkd-container-inner clearfix">
			<div class="mkd-container">
				<?php do_action('buro_mikado_after_container_open'); ?>
				<div class="mkd-container-inner" >
					<div class="mkd-blog-holder mkd-blog-type-standard mkd-search-page">
				<?php if(have_posts()) : while ( have_posts() ) : the_post(); ?>
					<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						<div class="mkd-post-content">
							<div class="mkd-post-text">
								<div class="mkd-post-text-inner">
									<h3>
										<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
									</h3>
									<?php
										echo buro_mikado_get_button_html(array(
											'size' => 'medium',
											'link'         => get_the_permalink(),
											'text'         => esc_html__('Leia Mais', 'buro'),
										));
									?>
								</div>
							</div>
						</div>
					</article>
					<?php endwhile; ?>
					<?php
						if(buro_mikado_options()->getOptionValue('pagination') == 'yes') {
							buro_mikado_pagination($buro_mikado_max_number_of_pages, $buro_mikado_blog_page_range, $buro_mikado_paged);
						}
					?>
					<?php else: ?>
					<div class="entry">
						<p><?php esc_html_e('No posts were found.', 'buro'); ?></p>
					</div>
					<?php endif; ?>
				</div>
				<?php do_action('buro_mikado_before_container_close'); ?>
			</div>
			</div>
		</div>
		<?php do_action('buro_mikado_before_container_close'); ?>
	</div>
	<?php do_action('buro_mikado_after_container_close'); ?>
<?php get_footer(); ?>