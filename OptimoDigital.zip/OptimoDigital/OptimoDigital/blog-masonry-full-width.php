<?php
	/*
	Template Name: Blog: Masonry Full Width
	*/
?>
<?php get_header(); ?>

<?php buro_mikado_get_title(); ?>
<?php get_template_part('slider'); ?>

	<div class="mkd-full-width">
		<div class="mkd-full-width-inner clearfix">
			<?php buro_mikado_get_blog('masonry-full-width'); ?>
		</div>
	</div>
	<?php do_action('buro_mikado_after_full_width_container_close') ?>
<?php get_footer(); ?>