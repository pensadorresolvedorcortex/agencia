<?php
buro_mikado_get_footer();
?>