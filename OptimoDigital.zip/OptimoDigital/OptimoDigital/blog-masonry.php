<?php
/*
Template Name: Blog: Masonry
*/
?>
<?php get_header(); ?>
<?php buro_mikado_get_title(); ?>
<?php get_template_part('slider'); ?>
	<div class="mkd-container">
		<?php do_action('buro_mikado_after_container_open'); ?>
		<div class="mkd-container-inner">
			<?php buro_mikado_get_blog('masonry'); ?>
		</div>
		<?php do_action('buro_mikado_before_container_close'); ?>
	</div>
<?php do_action('buro_mikado_after_container_close'); ?>
<?php get_footer(); ?>