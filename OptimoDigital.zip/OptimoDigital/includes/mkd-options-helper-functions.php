<?php

if(!function_exists('buro_mikado_is_responsive_on')) {
    /**
     * Checks whether responsive mode is enabled in theme options
     * @return bool
     */
    function buro_mikado_is_responsive_on() {
        return buro_mikado_options()->getOptionValue('responsiveness') !== 'no';
    }
}