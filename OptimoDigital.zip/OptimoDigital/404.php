<?php get_header(); ?>
	<div class="mkd-container">
	<?php do_action('buro_mikado_after_container_open'); ?>
		<div class="mkd-container-inner mkd-404-page">

			<div class="mkd-page-not-found-part">
				<div class="mkd-404-text"><?php esc_html_e('404', 'buro'); ?></div>
			</div>

			<div class="mkd-page-not-found">
				<h1>
					<?php if(buro_mikado_options()->getOptionValue('404_title')){
						echo esc_html(buro_mikado_options()->getOptionValue('404_title'));
					}
					else{
						esc_html_e('Page cannot be found.', 'buro');
					} ?>
				</h1>
				<p>
					<?php if(buro_mikado_options()->getOptionValue('404_text')){
						echo esc_html(buro_mikado_options()->getOptionValue('404_text'));
					}
					else{
						esc_html_e('The page you are looking for does not exist. It may have been moved, or removed altogether. Perhaps you can return back to the site\'s homepage and see if you can find what you are looking for.', 'buro');
					} ?>
				</p>
				<?php
					$params = array();
					if (buro_mikado_options()->getOptionValue('404_back_to_home')){
						$params['text'] = buro_mikado_options()->getOptionValue('404_back_to_home');
					}
					else{
						$params['text'] = "Back to Home";
					}
					$params['link'] = esc_url(home_url('/'));
					$params['target'] = '_self';
				echo buro_mikado_execute_shortcode('mkd_button',$params);?>
			</div>
		</div>
		<?php do_action('buro_mikado_before_container_close'); ?>
	</div>
<?php get_footer(); ?>