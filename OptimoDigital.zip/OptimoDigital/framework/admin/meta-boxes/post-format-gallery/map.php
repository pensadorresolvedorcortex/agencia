<?php

/*** Gallery Post Format ***/

if(!function_exists('buro_mikado_map_post_gallery_meta_fields')) {

	function buro_mikado_map_post_gallery_meta_fields() {
		$gallery_post_format_meta_box = buro_mikado_add_meta_box(
			array(
				'scope' =>	array('post'),
				'title' => esc_html__('Gallery Post Format', 'buro'),
				'name' 	=> 'post_format_gallery_meta',
			)
		);

		buro_mikado_add_multiple_images_field(
			array(
				'name'        => 'mkd_post_gallery_images_meta',
				'label'       => esc_html__('Gallery Images', 'buro'),
				'description' => esc_html__('Choose your gallery images', 'buro'),
				'parent'      => $gallery_post_format_meta_box,
			)
		);

	}
	
	add_action('buro_mikado_meta_boxes_map', 'buro_mikado_map_post_gallery_meta_fields');
}