<?php

/*** Quote Post Format ***/

if(!function_exists('buro_mikado_map_post_quote_meta_fields')) {

	function buro_mikado_map_post_quote_meta_fields() {
		$quote_post_format_meta_box = buro_mikado_add_meta_box(
			array(
				'scope' =>	array('post'),
				'title' => esc_html__('Quote Post Format', 'buro'),
				'name' 	=> 'post_format_quote_meta',
			)
		);

		buro_mikado_add_meta_box_field(
			array(
				'name'        => 'mkd_post_quote_text_meta',
				'type'        => 'text',
				'label'       => esc_html__('Quote Text', 'buro'),
				'description' => esc_html__('Enter Quote text', 'buro'),
				'parent'      => $quote_post_format_meta_box,

			)
		);

	}
	
	add_action('buro_mikado_meta_boxes_map', 'buro_mikado_map_post_quote_meta_fields');
}