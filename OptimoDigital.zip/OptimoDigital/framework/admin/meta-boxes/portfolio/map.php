<?php

if(!function_exists('buro_mikado_map_portfolio_meta_fields')) {

	function buro_mikado_map_portfolio_meta_fields() {
		global $buro_mikado_Framework;

		$mkd_pages = array();
		$pages = get_pages(); 
		foreach($pages as $page) {
			$mkd_pages[$page->ID] = $page->post_title;
		}

		//Portfolio Images

		$mkdPortfolioImages = new BuroMikadoMetaBox("portfolio-item", esc_html__("Portfolio Images (multiple upload)",'buro'), '', '', 'portfolio_images');
		$buro_mikado_Framework->mkdMetaBoxes->addMetaBox("portfolio_images",$mkdPortfolioImages);

			$mkd_portfolio_image_gallery = new BuroMikadoMultipleImages("mkd_portfolio-image-gallery", esc_html__("Portfolio Images",'buro'), esc_html__("Choose your portfolio images",'buro'));
			$mkdPortfolioImages->addChild("mkd_portfolio-image-gallery",$mkd_portfolio_image_gallery);

		//Portfolio Images/Videos 2

		$mkdPortfolioImagesVideos2 = new BuroMikadoMetaBox("portfolio-item", esc_html__("Portfolio Images/Videos (single upload)",'buro'));
		$buro_mikado_Framework->mkdMetaBoxes->addMetaBox("portfolio_images_videos2",$mkdPortfolioImagesVideos2);

			$mkd_portfolio_images_videos2 = new BuroMikadoImagesVideosFramework(esc_html__("Portfolio Images/Videos 2",'buro'),esc_html__("ThisIsDescription",'buro'));
			$mkdPortfolioImagesVideos2->addChild("mkd_portfolio_images_videos2",$mkd_portfolio_images_videos2);

		//Portfolio Additional Sidebar Items

		$mkdAdditionalSidebarItems = buro_mikado_add_meta_box(
		    array(
		        'scope' => array('portfolio-item'),
		        'title' => esc_html__('Additional Portfolio Sidebar Items', 'buro'),
		        'name' => 'portfolio_properties'
		    )
		);

		$mkd_portfolio_properties = buro_mikado_add_options_framework(
		    array(
		        'label' => esc_html__('Portfolio Properties', 'buro'),
		        'name' => 'mkd_portfolio_properties',
		        'parent' => $mkdAdditionalSidebarItems
		    )
		);

	}
	
	add_action('buro_mikado_meta_boxes_map', 'buro_mikado_map_portfolio_meta_fields');
}