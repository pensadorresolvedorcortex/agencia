<?php

if(!function_exists('buro_mikado_map_content_bottom_meta_fields')) {

	function buro_mikado_map_content_bottom_meta_fields() {
		$content_bottom_meta_box = buro_mikado_add_meta_box(
			array(
				'scope' => array('page', 'portfolio-item', 'post'),
				'title' => esc_html__('Content Bottom', 'buro'),
				'name' => 'content_bottom_meta',
			)
		);

		buro_mikado_add_meta_box_field(
			array(
				'name' => 'mkd_enable_content_bottom_area_meta',
				'type' => 'selectblank',
				'default_value' => '',
				'label' => esc_html__('Enable Content Bottom Area', 'buro'),
				'description' => esc_html__('This option will enable Content Bottom area on pages', 'buro'),
				'parent' => $content_bottom_meta_box,
				'options' => array(
					'no' => 'No',
					'yes' => 'Yes'
				),
				'args' => array(
					'dependence' => true,
					'hide' => array(
						'' => '#mkd_mkd_show_content_bottom_meta_container',
						'no' => '#mkd_mkd_show_content_bottom_meta_container'
					),
					'show' => array(
						'yes' => '#mkd_mkd_show_content_bottom_meta_container'
					)
				)
			)
		);

		$show_content_bottom_meta_container = buro_mikado_add_admin_container(
			array(
				'parent' => $content_bottom_meta_box,
				'name' => 'mkd_show_content_bottom_meta_container',
				'hidden_property' => 'mkd_enable_content_bottom_area_meta',
				'hidden_value' => '',
				'hidden_values' => array('','no')
			)
		);

		buro_mikado_add_meta_box_field(
			array(
				'name' => 'mkd_content_bottom_sidebar_custom_display_meta',
				'type' => 'selectblank',
				'default_value' => '',
				'label' => esc_html__('Sidebar to Display', 'buro'),
				'description' => esc_html__('Choose a Content Bottom sidebar to display', 'buro'),
				'options' => buro_mikado_get_custom_sidebars(),
				'parent' => $show_content_bottom_meta_container
			)
		);

		buro_mikado_add_meta_box_field(
			array(
				'type' => 'selectblank',
				'name' => 'mkd_content_bottom_in_grid_meta',
				'default_value' => '',
				'label' => esc_html__('Display in Grid', 'buro'),
				'description' => esc_html__('Enabling this option will place Content Bottom in grid', 'buro'),
				'options' => array(
					'no' => 'No',
					'yes' => 'Yes'
				),
				'parent' => $show_content_bottom_meta_container
			)
		);

		buro_mikado_add_meta_box_field(
			array(
				'type' => 'color',
				'name' => 'mkd_content_bottom_background_color_meta',
				'default_value' => '',
				'label' => esc_html__('Background Color', 'buro'),
				'description' => esc_html__('Choose a background color for Content Bottom area', 'buro'),
				'parent' => $show_content_bottom_meta_container
			)
		);

	}
	
	add_action('buro_mikado_meta_boxes_map', 'buro_mikado_map_content_bottom_meta_fields');
}