<?php

/*** Link Post Format ***/

if(!function_exists('buro_mikado_map_post_link_meta_fields')) {

	function buro_mikado_map_post_link_meta_fields() {
		$link_post_format_meta_box = buro_mikado_add_meta_box(
			array(
				'scope' => array('post'),
				'title' => esc_html__('Link Post Format', 'buro'),
				'name' => 'post_format_link_meta',
			)
		);

		buro_mikado_add_meta_box_field(
			array(
				'name'        => 'mkd_post_link_link_meta',
				'type'        => 'text',
				'label'       => esc_html__('Link', 'buro'),
				'description' => esc_html__('Enter link', 'buro'),
				'parent'      => $link_post_format_meta_box,

			)
		);

		buro_mikado_add_meta_box_field(
			array(
				'name'        => 'mkd_post_link_link_text_meta',
				'type'        => 'text',
				'label'       => esc_html__('Link Text', 'buro'),
				'description' => esc_html__('Enter link text', 'buro'),
				'parent'      => $link_post_format_meta_box,

			)
		);

	}
	
	add_action('buro_mikado_meta_boxes_map', 'buro_mikado_map_post_link_meta_fields');
}