<?php

if(!function_exists('buro_mikado_map_logo_meta_fields')) {

	function buro_mikado_map_logo_meta_fields() {
		$general_meta_box = buro_mikado_add_meta_box(
		    array(
		        'scope' => array('page', 'portfolio-item', 'post'),
		        'title' => esc_html__('Logo','buro'),
		        'name' => 'logo_meta'
		    )
		);

		buro_mikado_add_meta_box_field(
			array(
				'name' => 'mkd_logo_image_meta',
				'type' => 'image',
				'label' => esc_html__('Logo Image - Default','buro'),
				'description' => esc_html__('Choose a default logo image to display','buro'),
				'parent' => $general_meta_box
			)
		);

		buro_mikado_add_meta_box_field(
			array(
				'name' => 'mkd_logo_image_dark_meta',
				'type' => 'image',
				'label' => esc_html__('Logo Image - Dark','buro'),
				'description' => esc_html__('Choose a dark logo image to display','buro'),
				'parent' => $general_meta_box
			)
		);

		buro_mikado_add_meta_box_field(
			array(
				'name' => 'mkd_logo_image_light_meta',
				'type' => 'image',
				'label' => esc_html__('Logo Image - Light','buro'),
				'description' => esc_html__('Choose a light logo image to display','buro'),
				'parent' => $general_meta_box
			)
		);

		buro_mikado_add_meta_box_field(
			array(
				'name' => 'mkd_logo_image_sticky_meta',
				'type' => 'image',
				'label' => esc_html__('Logo Image - Sticky','buro'),
				'description' => esc_html__('Choose a sticky logo image to display','buro'),
				'parent' => $general_meta_box
			)
		);

		buro_mikado_add_meta_box_field(
			array(
				'name' => 'mkd_logo_image_mobile_meta',
				'type' => 'image',
				'label' => esc_html__('Logo Image - Mobile','buro'),
				'description' => esc_html__('Choose a mobile logo image to display','buro'),
				'parent' => $general_meta_box
			)
		);
	}
	
	add_action('buro_mikado_meta_boxes_map', 'buro_mikado_map_logo_meta_fields');
}
