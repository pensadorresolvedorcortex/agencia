<?php

//Testimonials

if(!function_exists('buro_mikado_map_testimonials_meta_fields')) {

	function buro_mikado_map_testimonials_meta_fields() {
		$testimonial_meta_box = buro_mikado_add_meta_box(
		    array(
		        'scope' => array('testimonials'),
		        'title' => esc_html__('Testimonial', 'buro'),
		        'name' => 'testimonial_meta',
		    )
		);

	    buro_mikado_add_meta_box_field(
	        array(
	            'name'        	=> 'mkd_testimonial_title',
	            'type'        	=> 'text',
	            'label'       	=> esc_html__('Title', 'buro'),
	            'description' 	=> esc_html__('Enter testimonial title', 'buro'),
	            'parent'      	=> $testimonial_meta_box,
	        )
	    );


	    buro_mikado_add_meta_box_field(
	        array(
	            'name'        	=> 'mkd_testimonial_author',
	            'type'        	=> 'text',
	            'label'       	=> esc_html__('Author', 'buro'),
	            'description' 	=> esc_html__('Enter author name', 'buro'),
	            'parent'      	=> $testimonial_meta_box,
	        )
	    );

	    buro_mikado_add_meta_box_field(
	        array(
	            'name'        	=> 'mkd_testimonial_author_position',
	            'type'        	=> 'text',
	            'label'       	=> esc_html__('Job Position', 'buro'),
	            'description' 	=> esc_html__('Enter job position', 'buro'),
	            'parent'      	=> $testimonial_meta_box,
	        )
	    );

	    buro_mikado_add_meta_box_field(
	        array(
	            'name'        	=> 'mkd_testimonial_text',
	            'type'        	=> 'text',
	            'label'       	=> esc_html__('Text', 'buro'),
	            'description' 	=> esc_html__('Enter testimonial text', 'buro'),
	            'parent'      	=> $testimonial_meta_box,
	        )
	    );
	}
	
	add_action('buro_mikado_meta_boxes_map', 'buro_mikado_map_testimonials_meta_fields');
}