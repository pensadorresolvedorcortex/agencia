<?php

/*** Audio Post Format ***/

if(!function_exists('buro_mikado_map_post_audio_meta_fields')) {

	function buro_mikado_map_post_audio_meta_fields() {
		$audio_post_format_meta_box = buro_mikado_add_meta_box(
			array(
				'scope' =>	array('post'),
				'title' => esc_html__('Audio Post Format', 'buro'),
				'name' 	=> 'post_format_audio_meta',
			)
		);

		buro_mikado_add_meta_box_field(
			array(
				'name'        => 'mkd_post_audio_link_meta',
				'type'        => 'text',
				'label'       => esc_html__('Link', 'buro'),
				'description' => esc_html__('Enter audion link', 'buro'),
				'parent'      => $audio_post_format_meta_box,

			)
		);

	}
	
	add_action('buro_mikado_meta_boxes_map', 'buro_mikado_map_post_audio_meta_fields');
}