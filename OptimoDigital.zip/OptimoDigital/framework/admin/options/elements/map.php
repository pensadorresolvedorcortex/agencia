<?php

if ( ! function_exists('buro_mikado_load_elements_map') ) {
	/**
	 * Add Elements option page for shortcodes
	 */
	function buro_mikado_load_elements_map() {

		buro_mikado_add_admin_page(
			array(
				'slug' => '_elements_page',
				'title' => esc_html__('Elements', 'buro'),
				'icon' => 'fa fa-flag-o'
			)
		);

		do_action( 'buro_mikado_options_elements_map' );

	}

	add_action('buro_mikado_options_map', 'buro_mikado_load_elements_map', 11);

}