<div <?php buro_mikado_class_attribute($item_classes); ?>>
	<div class="mkd-pi-holder-inner">
		<?php if(!empty($number)) : ?>
			<div class="mkd-pi-number-holder">
				<span class="mkd-pi-arrow"><span class="arrow_right"></span></span>
				<span class="mkd-pi-number"><?php echo esc_html($number); ?></span>
			</div>
		<?php endif; ?>
		<?php if(!empty($title) || !empty($text)) : ?>
			<div class="mkd-pi-content-holder">
				<?php if(!empty($title)) : ?>
					<div class="mkd-pi-title-holder">
						<h5 class="mkd-pi-title"><?php echo esc_html($title); ?></h5>
					</div>
				<?php endif; ?>

				<?php if(!empty($text)) : ?>
					<div class="mkd-pi-text-holder">
						<p><?php echo esc_html($text); ?></p>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</div>
</div>