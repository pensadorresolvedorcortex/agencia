<div <?php buro_mikado_class_attribute($holder_classes); ?>>
	<div class="mkd-process-inner clearfix">
		<?php echo do_shortcode($content); ?>
	</div>
</div>