<div <?php buro_mikado_class_attribute($pricing_table_classes)?>>
	<div class="mkd-price-table-inner">
		<ul>
			<li class="mkd-table-title">
				<h5 class="mkd-title-content"><?php echo esc_html($title) ?></h5>
			</li>
			<li class="mkd-table-prices">
				<div class="mkd-price-in-table">
					<span class="mkd-price-holder">
						<sup class="mkd-value"><?php echo esc_attr($currency) ?></sup>
						<span class="mkd-price"><?php echo esc_attr($price)?></span>
					</span>
					<span class="mkd-mark"><?php echo esc_attr($price_period)?></span>
				</div>	
			</li>
			<li class="mkd-table-content">
				<?php
					echo do_shortcode($content);
				?>
			</li>
			<?php 
			if($show_button == "yes" && $button_text !== ''){ ?>
				<li class="mkd-price-button">
					<?php echo buro_mikado_get_button_html(array(
						'link' => $link,
						'text' => $button_text,
						'custom_class' => 'mkd-btn-frst-clr'
					)); ?>
				</li>				
			<?php } ?>
		</ul>
	</div>
</div>