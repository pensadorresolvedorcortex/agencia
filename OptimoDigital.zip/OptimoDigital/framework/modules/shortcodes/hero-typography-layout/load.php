<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/hero-typography-layout/hero-typography-layout.php';