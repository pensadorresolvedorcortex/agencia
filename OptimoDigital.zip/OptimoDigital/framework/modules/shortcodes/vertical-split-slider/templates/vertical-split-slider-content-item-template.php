<div class="mkd-vss-ms-section" <?php buro_mikado_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>