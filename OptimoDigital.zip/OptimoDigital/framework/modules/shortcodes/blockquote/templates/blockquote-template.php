<?php
/**
 * Blockquote shortcode template
 */
?>

<blockquote class="mkd-blockquote-shortcode" <?php buro_mikado_inline_style($blockquote_style); ?> >
<!--	<span class="mkd-icon-quotations-holder">-->
<!--		--><?php //echo buro_mikado_icon_collections()->getQuoteIcon("font_elegant", true); ?>
<!--	</span>-->
	<h5 class="mkd-blockquote-text">
		<?php echo esc_attr($text); ?>
	</h5>
</blockquote>