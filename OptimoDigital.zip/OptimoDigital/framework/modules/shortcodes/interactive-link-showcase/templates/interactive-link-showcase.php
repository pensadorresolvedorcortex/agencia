<div class="<?php echo esc_attr($holder_classes); ?>">
    <div class="mkd-ils-holder">
        <?php if (!empty($link_items)) { ?>
            <div class="mkd-ils-image-holder">
                <?php foreach ($link_items as $link_item): ?>
                    <?php if (isset($link_item['image'])) {
                        $image_url = wp_get_attachment_url($link_item['image']);
                        ?>
                        <div class="mkd-ils-item-image" style="background-image: url(<?php print $image_url; ?>">
                            <?php echo wp_get_attachment_image($link_item['image'], 'full'); ?>
                            <div class="mkd-ils-item-content-copy">
                                <a class="mkd-ils-item-link" itemprop="url" target="<?php echo esc_attr($target); ?>"
                                   href="<?php echo esc_url($link_item['link']) ?>">
                                    <?php echo esc_html($link_item['title']); ?>
                                </a>
                            </div>
                        </div>
                    <?php } ?>
                <?php endforeach; ?>
            </div>
            <div class="mkd-ils-content-holder">
                <div class="mkd-ils-content-table">
                    <div class="mkd-ils-content-table-cell">
                        <?php foreach ($link_items as $link_item): ?>
                            <?php if (isset($link_item['title'])) { ?>
                                <div class="mkd-ils-item-content">
                                    <a class="mkd-ils-item-link" itemprop="url"
                                       target="<?php echo esc_attr($target); ?>"
                                       href="<?php echo esc_url($link_item['link']) ?>">
                                        <?php echo esc_html($link_item['title']); ?>
                                    </a>
                                </div>
                            <?php } ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>