<div <?php buro_mikado_class_attribute($progress_bar_classes);?>>
	<<?php echo esc_attr($title_tag);?> class="mkd-progress-title-holder clearfix">
		<span class="mkd-progress-title"><?php echo esc_attr($title)?></span>
		<span class="mkd-progress-number-wrapper <?php echo esc_attr($percentage_classes)?> " >
			<span class="mkd-progress-number">
				<span class="mkd-percent">0</span>
			</span>
		</span>
	</<?php echo esc_attr($title_tag)?>>
	<div class="mkd-progress-content-outer ">
		<div data-percentage=<?php echo esc_attr($percent)?> class="mkd-progress-content" ></div>
	</div>
</div>	