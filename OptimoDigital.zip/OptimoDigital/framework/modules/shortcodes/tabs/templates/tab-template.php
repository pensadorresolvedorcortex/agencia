<div <?php buro_mikado_class_attribute($tab_class)?>>
	<ul class="mkd-tabs-nav">
		<?php foreach ($tabs_titles as $tab_title) { ?>
			<li>
				<a href="#tab-<?php echo sanitize_title($tab_title)?>">
					<?php if(in_array('mkd-vertical-tab', $tab_class) && (in_array('mkd-tab-with-icon', $tab_class) || in_array('mkd-tab-only-icon', $tab_class))) { ?>
						<span class="mkd-icon-frame"></span>
					<?php } ?>

					<?php if($tab_title !== '' && !in_array('mkd-tab-only-icon', $tab_class)) { ?>
						<span class="mkd-tab-text-after-icon">
							<?php echo esc_attr($tab_title)?>
						</span>
					<?php } ?>
						
					<?php if(!in_array('mkd-vertical-tab', $tab_class) && (in_array('mkd-tab-with-icon', $tab_class) || in_array('mkd-tab-only-icon', $tab_class))) { ?>
						<span class="mkd-icon-frame"></span>
					<?php } ?>
				</a>
			 </li>
		<?php } ?>
	</ul> 
	<?php echo do_shortcode($content); ?>
</div>