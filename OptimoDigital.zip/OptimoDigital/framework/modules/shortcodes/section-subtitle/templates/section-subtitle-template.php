<?php
/**
 * Section Subtitle shortcode template
 */
?>

<span class="mkd-section-subtitle" <?php buro_mikado_inline_style($subtitle_style); ?>>
	<?php echo esc_html($subtitle_text);?>
</span>