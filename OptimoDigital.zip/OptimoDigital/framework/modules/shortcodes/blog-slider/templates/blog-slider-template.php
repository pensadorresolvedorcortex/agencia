<div class="mkd-blog-carousel-item">
	<?php if($show_image == 'yes' && has_post_thumbnail()) { ?>
		<div class="mkd-blog-slide-image">
			<a href="<?php the_permalink(); ?>">
				<?php
					if ($image_size != 'custom') {
						the_post_thumbnail($image_size);
					} else {
						print buro_mikado_generate_thumbnail(get_post_thumbnail_id(get_the_ID()), null, $image_width, $image_height);
					}
                ?>
			</a>
		</div>
	<?php } ?>
	<div class="mkd-blog-slide-info-holder clearfix">
		<div class="mkd-item-info-section">
			<?php buro_mikado_post_info(array(
				'category' => 'yes'
			)) ?>
			<?php buro_mikado_post_info(array(
				'date' => 'yes',
			)) ?>
		</div>

		<h3 class="mkd-blog-slide-title">
			<a href="<?php the_permalink(); ?>">
				<?php the_title(); ?>
			</a>
		</h3>

		<?php if ($text_length != '0') {
			$excerpt = ($text_length > 0) ? substr(get_the_excerpt(), 0, intval($text_length)) : get_the_excerpt(); ?>
			<p class="mkd-blog-slide-excerpt"><?php echo esc_html($excerpt)?>...</p>
		<?php } ?>

		<div class="mkd-item-read-more">
			<?php echo buro_mikado_get_button_html(array(
				'type' => 'transparent',
				'size' => 'large',
				'link' => get_the_permalink(),
				'text' => esc_html__('Leia Mais', 'buro'),
				'icon_pack' => 'font_elegant',
				'fe_icon' => 'arrow_right'
			)); ?>
		</div>
	</div>
</div>