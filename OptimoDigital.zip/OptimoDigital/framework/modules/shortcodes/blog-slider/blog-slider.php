<?php
namespace BuroMikado\Modules\Shortcodes\BlogSlider;

use BuroMikado\Modules\Shortcodes\Lib\ShortcodeInterface;
/**
 * Class Blog Slider
 */
class BlogSlider implements ShortcodeInterface {

	/**
	 * @var string
	 */
	private $base;

	public function __construct() {
		$this->base = 'mkd_blog_slider';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	/**
	 * Returns base for shortcode
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}

	/**
	 * Maps shortcode to Visual Composer. Hooked on vc_before_init
	 *
	 * @see mkd_core_get_carousel_slider_array_vc()
	 */
	public function vcMap() {

		$categories_array = array();

		vc_map( array(
			'name' => esc_html__('Blog Slider', 'buro'),
			'base' => $this->getBase(),
			'icon'  => 'icon-wpb-blog-slider extended-custom-icon',
			'category' => esc_html__('by MIKADO', 'buro'),
			'allowed_container_element' => 'vc_row',
			'params' => array(
                array(
                    'type'			=> 'dropdown',
                    'heading'		=> esc_html__('Slider Type', 'buro'),
                    'param_name'	=> 'slider_type',
                    'value'			=> array(
						esc_html__('Carousel', 'buro') => 'carousel',
						esc_html__('Slider', 'buro') => 'slider',
                    ),
                    'admin_label'	=> true,
                ),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Number of Posts', 'buro'),
					'param_name' => 'number_of_posts',
					'description' => esc_html__('Leave empty for all posts', 'buro'),
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Selected Posts', 'buro'),
					'param_name'	=> 'selected_posts',
					'description'	=> esc_html__('Selected Posts (leave empty for all, delimit by comma)', 'buro'),
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__('Order by', 'buro'),
					'param_name'	=> 'order_by',
					'value'			=> array(
						esc_html__('Date', 'buro') => 'date',
						esc_html__('Title', 'buro') => 'title'
					),
					'admin_label'	=> true,
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__('Order', 'buro'),
					'param_name'	=> 'order',
					'value'			=> array(
						esc_html__('DESC','buro') => 'desc',
						esc_html__('ASC', 'buro') => 'asc'
					),
					'admin_label'	=> true,
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Category', 'buro'),
					'param_name' => 'category',
					'value' => '',
					'description' => esc_html__('Leave empty for all or use comma for list', 'buro'),
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__('Show Image', 'buro'),
					'param_name'	=> 'show_image',
					'value'			=> array(
						esc_html__('No', 'buro')	=> 'no',
						esc_html__('Yes','buro')	=> 'yes',
					),
					"dependency" => array("element" => "slider_type", "value" => array("carousel"))
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__('Image Size', 'buro'),
					'param_name'	=> 'image_size',
					'value'			=> array(
						esc_html__('Default','buro') => 'default',
						esc_html__('Square','buro') => 'square',
					),
                    "dependency" => array("element" => "show_image", "value" => array("yes"))
				),
                array(
                    'type'			=> 'dropdown',
                    'heading'		=> esc_html__('Image Size', 'buro'),
                    'param_name'	=> 'image_size_slider',
                    'value'			=> array(
						esc_html__('Default', 'buro') => 'default',
						esc_html__('Square', 'buro')	=> 'square',
						esc_html__('Custom',	'buro')	=> 'custom',
                    ),
                    "dependency" => array("element" => "slider_type", "value" => array("slider"))
                ),
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("Image Width", 'buro'),
                    "param_name" => "image_width",
                    "value" => "",
                    "description" => esc_html__("Set custom image width", 'buro'),
                    "dependency" => array("element" => "image_size_slider", "value" => array("custom"))
                ),
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("Image Height", 'buro'),
                    "param_name" => "image_height",
                    "value" => "",
                    "description" => esc_html__("Set custom image height", 'buro'),
                    "dependency" => array("element" => "image_size_slider", "value" => array("custom"))
                ),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Text length', 'buro'),
					'param_name' => 'text_length',
					'description' => esc_html__('Number of characters', 'buro'),
				),
			)
		) );

	}

	/**
	 * Renders shortcodes HTML
	 *
	 * @param $atts array of shortcode params
	 * @return string
	 */
	public function render($atts, $content = null) {

		$args = array(
			'number_of_posts'	=> -1,
			'order_by'		 	=> 'date',
			'order'				=> 'DESC',
			'category'			=> '',
			'image_size'		=> 'full',
			'image_size_slider'	=> 'full',
			'slider_type'	 	=> 'carousel',
			'show_image'	 	=> 'no',
			'image_height'	 	=> '',
            'image_width'	 	=> '',
            'selected_posts' 	=> '',
            'text_length' 		=> '90'
		);

		$params = shortcode_atts($args, $atts);

		extract($params);
		
		
		$args = array(
			'post_type'			=> 'post',
			'posts_per_page'	=> $number_of_posts,
			'orderby'			=> $order_by,
			'order'				=> $order
		);
		if($category != '' && $category !== 0){
			$args['category_name'] = $category;
		}

		$slider_class = 'mkd-blog-slider-type-'.$slider_type;
		$post_ids = null;
		
		if($selected_posts != ''){
			$post_ids = explode(',', $selected_posts);
			$args['post__in'] = $post_ids;
		}

        if($slider_type == 'slider'){
           if($image_size_slider == 'custom' && $image_width != '' && $image_height != ''){
                $params['image_size'] = 'custom';
                $params['image_width'] = $image_width;
                $params['image_height'] = $image_height;
            }elseif($image_size_slider == 'square') {
               $params['image_size'] = 'buro_mikado_square';
           }
           $params['show_image'] = 'yes'; //for slider image is always shown

        }elseif($image_size == 'square') {
            $params['image_size'] = 'buro_mikado_square';
        }

		$query = new \WP_Query($args);

		if ( $query->have_posts() ) {

			$html = '';

			$html .= '<div class="mkd-blog-slider-outer">';
			

			$html .= '<div class="mkd-blog-slider mkd-slick-slider-navigation-style '. $slider_class .'" data-type="'.$slider_type.'">';

			while ( $query->have_posts() ) {

				$query->the_post();

				//Get slide HTML from template
				$html .= buro_mikado_get_shortcode_module_template_part('templates/blog-slider-template', 'blog-slider', '', $params);

			}

			$html .= '</div></div>';


		} else {

			$html = esc_html__('There is no posts!', 'buro');

		}

		wp_reset_postdata();

		return $html;

	}
}