<div class="mkd-clients clearfix mkd-clients-<?php echo esc_attr($columns); ?>">
	<?php echo do_shortcode($content); ?>
</div>