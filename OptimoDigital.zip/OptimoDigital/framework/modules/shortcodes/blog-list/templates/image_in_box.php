<li class="mkd-blog-list-item clearfix">
	<div class="mkd-blog-list-item-inner">
		<?php if (has_post_thumbnail()) { ?>
			<div class="mkd-item-image clearfix">
				<a href="<?php echo esc_url(get_permalink()) ?>">
					<?php
						echo get_the_post_thumbnail(get_the_ID(), $thumb_image_size);
					?>
				</a>
			</div>
		<?php } ?>
		<div class="mkd-item-text-holder">
			<div class="mkd-item-info-section">
				<?php buro_mikado_post_info(array(
					'category' => 'yes'
				)) ?>
				<?php buro_mikado_post_info(array(
					'date' => 'yes',
				)) ?>
			</div>
					
			<<?php echo esc_html( $title_tag)?> class="mkd-item-title ">
				<a href="<?php echo esc_url(get_permalink()) ?>" >
					<?php echo esc_attr(get_the_title()) ?>
				</a>
			</<?php echo esc_html($title_tag) ?>>

			<?php if ($text_length != '0') {
				$excerpt = ($text_length > 0) ? substr(get_the_excerpt(), 0, intval($text_length)) : get_the_excerpt(); ?>
				<p class="mkd-excerpt"><?php echo esc_html($excerpt)?>...</p>
			<?php } ?>

		</div>
	</div>	
</li>
