<li class="mkd-blog-list-item clearfix mkd-blog-list-title">
	<div class="mkd-blog-list-item-table">
		<div class="mkd-blog-list-item-table-cell">
			<?php if ($list_title !== '') {
				echo buro_mikado_execute_shortcode('mkd_section_title', array('title_text' => $list_title,'highlighted_text' => $list_highlighted));
			} ?>
		</div>
	</div>
</li>