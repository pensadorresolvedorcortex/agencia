<?php
/**
 * Custom Font shortcode template
 */
?>

<<?php echo esc_attr($custom_font_tag);?> class="mkd-custom-font-holder" <?php buro_mikado_inline_style($custom_font_style); echo ' '.esc_attr($custom_font_data);?>>
	<?php echo wp_kses_post($content_custom_font);?><?php if ($highlighted_text !== ''){ ?><span class="mkd-highlighted" <?php buro_mikado_inline_style($highlighted_style)?>><?php echo esc_html($highlighted_text);?></span><?php } ?>
	<?php if($type_out_effect == 'yes') { ?>
		<span class="mkd-typed-wrap" <?php buro_mikado_inline_style($type_out_style);?>>
			<span class="mkd-typed">
				<?php if($typed_ending_1 != '') { ?>
					<span class="mkd-typed-1"><?php echo esc_html($typed_ending_1); ?></span>
				<?php } if($typed_ending_2 != '') { ?>
					<span class="mkd-typed-2"><?php echo esc_html($typed_ending_2); ?></span>
				<?php } if($typed_ending_3 != '') { ?>
					<span class="mkd-typed-3"><?php echo esc_html($typed_ending_3); ?></span>
				<?php } ?>
			</span>
		</span>
	<?php } ?>
</<?php echo esc_attr($custom_font_tag);?>>