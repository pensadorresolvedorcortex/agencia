<<?php echo esc_attr($title_tag)?> class="clearfix mkd-title-holder">
	<span class="mkd-tab-title">
		<span class="mkd-tab-title-inner">
			<?php echo esc_attr($title)?>
		</span>
	</span>
	<span class="mkd-accordion-mark">
		<span class="mkd-accordion-mark-icon">
			<span class="icon_plus"></span>
			<span class="icon_minus-06"></span>
		</span>
	</span>
</<?php echo esc_attr($title_tag)?>>
<div class="mkd-accordion-content">
	<div class="mkd-accordion-content-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>