<div class="mkd-image-with-text">
    <?php if ($link !== ''){ ?>
        <a class="mkd-iwt-link" href="<?php echo esc_url($link)?>" target="<?php echo esc_attr($target);?>">
        </a>
    <?php } ?>
    <div class="mkd-iwt-text">
        <?php if ($title !== '') { ?>
            <span class="mkd-iwt-title" <?php buro_mikado_inline_style($title_style);?>>
                <?php echo esc_html($title);?>
            </span>
        <?php } ?>
    </div>

	<div class="mkd-iwt-image">
		<?php if(is_array($image_size) && count($image_size)) : ?>
			<?php echo buro_mikado_generate_thumbnail($image, null, $image_size[0], $image_size[1]); ?>
		<?php else: ?>
			<?php echo wp_get_attachment_image($image, $image_size); ?>
		<?php endif; ?>
	</div>
</div>