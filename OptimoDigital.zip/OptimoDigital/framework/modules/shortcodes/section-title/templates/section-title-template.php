<?php
/**
 * Section Title shortcode template
 */
?>

<div <?php buro_mikado_class_attribute($classes); ?> <?php buro_mikado_inline_style($title_style)?>>
	<?php echo esc_html($title_text);?><?php if ($highlighted_text !== ''){ ?><span class="mkd-section-highlighted" <?php buro_mikado_inline_style($highlighted_style)?>><?php echo esc_html($highlighted_text);?></span><?php } ?>
</div>