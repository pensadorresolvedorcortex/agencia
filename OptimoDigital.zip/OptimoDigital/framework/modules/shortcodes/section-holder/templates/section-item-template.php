<div class="mkd-section-item <?php echo esc_attr($section_item_class); ?>" <?php echo buro_mikado_get_inline_style($section_item_style); ?>>
	<div class="mkd-section-item-inner">
		<div class="mkd-section-item-content">
			<?php echo do_shortcode($content); ?>
		</div>
	</div>
</div>