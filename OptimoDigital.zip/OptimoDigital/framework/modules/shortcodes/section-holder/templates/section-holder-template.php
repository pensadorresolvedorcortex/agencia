<div <?php buro_mikado_class_attribute($section_classes)?>>
	<div class="mkd-sh-title-area" <?php buro_mikado_inline_style($title_area_style);?>>
		<div class="mkd-sh-title-area-inner">
			<?php 
			if ($title_text !== '' || $highlighted_text !== '') {
				echo buro_mikado_execute_shortcode('mkd_section_title', $title_params);
			}
			if ($show_separator == 'yes'){
				echo buro_mikado_execute_shortcode('mkd_separator', array('position' => 'left'));
			}
			if ($subtitle_text !== ''){
				echo buro_mikado_execute_shortcode('mkd_section_subtitle', $subtitle_params);
			}
			?>
		</div>
	</div>
	<div class="mkd-sh-content-area">
		<?php echo do_shortcode($content);?>
	</div>
</div>