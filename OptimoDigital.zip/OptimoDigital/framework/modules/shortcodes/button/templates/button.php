<button type="submit" <?php buro_mikado_inline_style($button_styles); ?> <?php buro_mikado_class_attribute($button_classes); ?> <?php echo buro_mikado_get_inline_attrs($button_data); ?> <?php echo buro_mikado_get_inline_attrs($button_custom_attrs); ?>>
    <?php if ($text !== '') { ?>
		<span class="mkd-btn-text"><?php echo esc_html($text); ?></span>
	<?php } ?>
    <?php if ($icon !== '' && $icon_pack !== '') { ?>
		<span class="mkd-btn-icon-holder" <?php buro_mikado_inline_style($icon_styles);?>>
			<?php echo buro_mikado_icon_collections()->renderIcon($icon, $icon_pack); ?>
		</span>
	<?php } ?>
</button>