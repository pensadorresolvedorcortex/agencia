<div class="mkd-social-share-holder mkd-list">
	<span class="mkd-social-share-title"><?php esc_html_e('Share', 'buro'); ?></span>
	<ul>
		<?php foreach ($networks as $net) {
			print $net;
		} ?>
	</ul>
</div>