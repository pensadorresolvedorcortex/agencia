<div class="mkd-underliner-holder">

    <<?php print $title_tag; ?> class="mkd-underliner" <?php echo buro_mikado_get_inline_style($underliner_size);?>>

    <?php foreach ($items as $item) {
        if (!empty($item['text'])) {
            $class = $item['underlined'] == 'yes' ? 'mkd-underlined' : '';
            $color = $item['color'] !== '' ? 'color: ' . $item['color'] : '';

            if (!empty($item['link'])) { ?>

                <a href="<?php print $item['link']; ?>" target="<?php print $item['target']; ?>" <?php buro_mikado_class_attribute($class); ?> <?php echo buro_mikado_get_inline_style($color);?>>
                    <?php print $item['text']; ?>
                </a>

            <?php } else { ?>

                <span <?php buro_mikado_class_attribute($class); ?> <?php echo buro_mikado_get_inline_style($color);?>>
                    <?php print $item['text']; ?>
                </span>

            <?php }
        }
    } ?>
</<?php print $title_tag; ?>>
</div>