<?php

require_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/banner/banner.php';
