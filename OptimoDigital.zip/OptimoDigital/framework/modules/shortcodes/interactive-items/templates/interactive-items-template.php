<div <?php buro_mikado_class_attribute($interactive_classes)?>>
	<div class="mkd-int-item" <?php buro_mikado_inline_style($title_area_style);?>>
		<div class="mkd-int-item-table">
			<div class="mkd-int-item-cell">
				<?php 
				if ($title_text !== '' || $highlighted_text !== '') {
					echo buro_mikado_execute_shortcode('mkd_section_title', $title_params);
				}
				?>
			</div>
		</div>
	</div>
	<?php echo do_shortcode($content);?>
</div>