<div class="mkd-int-item">
	<?php if ($link != '') { ?>
		<a href="<?php echo esc_url($link) ?>" target="<?php echo esc_attr($target) ?>"></a>
	<?php } ?>
	<div class="mkd-int-front-holder" <?php buro_mikado_inline_style($interactive_item_holder_styles); ?>>
		<div class="mkd-int-item-table">
			<div class="mkd-int-item-cell">
				<?php if (is_array($icon_parameters) && count($icon_parameters)) {
					echo buro_mikado_execute_shortcode('mkd_icon', $icon_parameters);
				} ?>
				<?php if ($title !== '') { ?>
					<<?php echo esc_attr($title_tag);?> class="mkd-int-title">
						<?php echo esc_attr($title); ?>
					</<?php echo esc_attr($title_tag);?>>
				<?php } ?>
				<?php if ($text !== '') { ?>
					<p class="mkd-int-text"><?php echo esc_html($text); ?></p>
				<?php } ?>
			</div>
		</div>
	</div>
	<div class="mkd-int-back-holder" <?php buro_mikado_inline_style($interactive_back_styles);?>></div>
</div>