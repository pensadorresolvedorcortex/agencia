<div class="mkd-image-gallery">
	<div class="mkd-image-gallery-sliding <?php echo esc_attr($slider_classes);?>" <?php echo buro_mikado_get_inline_attrs($slider_data); ?>>
		<?php foreach ($images as $image) { ?>
		<div>
			<?php if ($pretty_photo) { ?>
				<a href="<?php echo esc_url($image['url'])?>" data-rel="prettyPhoto[single_pretty_photo]" title="<?php echo esc_attr($image['title']); ?>">
			<?php } 
			elseif ($image['link'] !== '') { ?>
				<a class="mkd-ig-link" href="<?php echo esc_url($image['link'])?>" target="<?php echo esc_attr($image['link_target']);?>">
					<div class="mkd-ig-overlay">
						<?php if ($image['title'] !== ''){ ?>
							<div class="mkd-ig-overlay-table">
								<div class="mkd-ig-overlay-table-cell">
									<h3 class="mkd-ig-overlay-title"><?php echo esc_html($image['title']); ?></h3>
								</div>
							</div>
						<?php } ?>
					</div>
			<?php } ?>
				<div class="mkd-ig-image-holder">
					<?php if(is_array($image_size) && count($image_size)) : ?>
						<?php echo buro_mikado_generate_thumbnail($image['image_id'], null, $image_size[0], $image_size[1]); ?>
					<?php else: ?>
						<?php echo wp_get_attachment_image($image['image_id'], $image_size); ?>
					<?php endif; ?>
				</div>
			<?php if ($pretty_photo || $image['link'] !== '') {?>
				</a>
			<?php } ?>
		</div>
		<?php } ?>
	</div>
</div>