<div class="mkd-text-slider-item">
	<?php if ($item_title !== '') { ?>
		<<?php echo esc_attr($title_tag);?> class="mkd-ts-item-title">
			<?php echo esc_html($item_title); ?>
		</<?php echo esc_attr($title_tag);?>>
	<?php } ?>
	<?php if ($show_separator == 'yes'){
		echo buro_mikado_execute_shortcode('mkd_separator', array('position' => 'left'));
	} ?>
	<?php if ($item_text !== '') { ?>
		<p class="mkd-ts-item-text"> <?php echo esc_html($item_text); ?> </p>
	<?php } ?>
</div>