<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/text-slider/text-slider.php';
require_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/text-slider/text-slider-item.php';
