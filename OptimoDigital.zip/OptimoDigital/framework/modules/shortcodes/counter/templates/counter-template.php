<?php
/**
 * Counter shortcode template
 */
?>
<div class="mkd-counter-holder <?php echo esc_attr($position); ?>" <?php echo buro_mikado_get_inline_style($counter_holder_styles); ?>>
	<?php
	if (is_array($icon_parameters) && count($icon_parameters)) { ?>
		<span class="mkd-counter-icon">
			<?php echo buro_mikado_execute_shortcode('mkd_icon', $icon_parameters); ?>
		</span>
	<?php }	?>
	<span class="mkd-counter <?php echo esc_attr($type) ?>" <?php echo buro_mikado_get_inline_style($counter_styles); ?>>
		<?php echo esc_attr($digit); ?>
	</span>
	<?php if($title != '') { ?>
		<<?php echo esc_html($title_tag); ?> class="mkd-counter-title" <?php echo buro_mikado_get_inline_style($title_styles); ?>>
			<?php echo esc_attr($title); ?>
		</<?php echo esc_html($title_tag);; ?>>
	<?php } ?>
	<?php if ($text != "") { ?>
		<p class="mkd-counter-text" <?php echo buro_mikado_get_inline_style($text_styles); ?>><?php echo esc_html($text); ?></p>
	<?php } ?>

</div>