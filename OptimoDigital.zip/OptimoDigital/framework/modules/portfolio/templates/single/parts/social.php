<?php if(buro_mikado_options()->getOptionValue('enable_social_share') == 'yes'
    && buro_mikado_options()->getOptionValue('enable_social_share_on_portfolio-item') == 'yes') : ?>
    <div class="mkd-portfolio-social">
        <?php echo buro_mikado_get_social_share_html() ?>
    </div>
<?php endif; ?>