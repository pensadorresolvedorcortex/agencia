<?php $title_tag = 'h3';

?>
<div class="mkd-portfolio-info-item mkd-content-item">
    <<?php echo esc_attr($title_tag); ?> class="mkd-portfolio-title"><?php the_title(); ?></<?php echo esc_attr($title_tag); ?>>
    <div class="mkd-portfolio-content">
        <?php the_content(); ?>
    </div>
</div>