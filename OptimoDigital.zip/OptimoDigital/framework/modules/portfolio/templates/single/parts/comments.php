<?php
    if(buro_mikado_options()->getOptionValue('portfolio_single_comments') == 'yes'){
        comments_template('', true);
    }
?>
