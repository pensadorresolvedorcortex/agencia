<?php if(buro_mikado_options()->getOptionValue('portfolio_single_hide_date') !== 'yes') : ?>

    <div class="mkd-portfolio-info-item mkd-portfolio-date">
        <h6 class="mkd-portfolio-info-item-title"><?php esc_html_e('Date:', 'buro'); ?></h6>

        <p><?php the_time(get_option('date_format')); ?></p>
    </div>

<?php endif; ?>