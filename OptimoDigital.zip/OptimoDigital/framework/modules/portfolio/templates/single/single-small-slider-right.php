<div class="mkd-two-columns-25-75 clearfix">
	<div class="mkd-column1">
		<div class="mkd-column-inner">
			<div class="mkd-portfolio-info-holder">
				<?php
				//get portfolio content section
				buro_mikado_portfolio_get_info_part('content');

                //get portfolio info title
                buro_mikado_portfolio_get_info_part('info-title');
                
				//get portfolio custom fields section
				buro_mikado_portfolio_get_info_part('custom-fields');

                //get portfolio categories section
                buro_mikado_portfolio_get_info_part('categories');

				//get portfolio date section
                buro_mikado_portfolio_get_info_part('date');

				//get portfolio tags section
				buro_mikado_portfolio_get_info_part('tags');

				//get portfolio share section
				buro_mikado_portfolio_get_info_part('social');
				?>
			</div>
		</div>
	</div>
	<div class="mkd-column2">
		<div class="mkd-column-inner">
			<?php
			$media = buro_mikado_get_portfolio_single_media();

			if(is_array($media) && count($media)) : ?>
				<div class="mkd-portfolio-media mkd-slick-slider mkd-slick-slider-navigation-style">
					<?php foreach($media as $single_media) : ?>
						<div class="mkd-portfolio-single-media">
							<?php buro_mikado_portfolio_get_media_html($single_media); ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>