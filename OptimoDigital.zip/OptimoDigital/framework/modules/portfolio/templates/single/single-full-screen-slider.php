<?php $date_format = 'F d, Y';?>
<div class="mkd-portfolio-slider-content">
	<span class="mkd-control mkd-open arrow_carrot-up"></span>

	<div class="mkd-description">
		<div class="mkd-ptf-table">
			<div class="mkd-ptf-table-cell">
				<h5><?php the_title(); ?></h5>
				<span class="mkd-ptf-date"><?php the_time($date_format); ?></span>
			</div>
		</div>
	</div>

	<div class="mkd-portfolio-slider-content-info">
		<div class="mkd-ptf-table">
			<div class="mkd-ptf-table-cell">
				<div class="egtf-ptf-content-holder">
					<?php buro_mikado_portfolio_get_info_part('content'); ?>
					<span class="mkd-control mkd-close arrow_carrot-down"></span>
				</div>
				<div class="mkd-portfolio-info-holder">
					<?php
						//get portfolio info title
						buro_mikado_portfolio_get_info_part('info-title');

						//get portfolio custom fields section
						buro_mikado_portfolio_get_info_part('custom-fields');

                        //get portfolio categories section
                        buro_mikado_portfolio_get_info_part('categories');

						//get portfolio date section
                        buro_mikado_portfolio_get_info_part('date');

						//get portfolio tags section
						buro_mikado_portfolio_get_info_part('tags');

						//get portfolio share section
						buro_mikado_portfolio_get_info_part('social');
					?>
				</div>
			</div>
		</div>
	</div>

</div>
<div class="mkd-full-screen-slider-holder">
	<?php
	$media = buro_mikado_get_portfolio_single_media();

	if(is_array($media) && count($media)) : ?>
		<div class="mkd-portfolio-full-screen-slider">
			<?php foreach($media as $single_media) : ?>
				<div class="mkd-portfolio-single-media">
					<?php buro_mikado_portfolio_get_media_html($single_media); ?>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</div>