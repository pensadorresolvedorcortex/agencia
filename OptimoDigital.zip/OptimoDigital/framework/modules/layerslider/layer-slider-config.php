<?php
	if(!function_exists('buro_mikado_layerslider_overrides')) {
		/**
		 * Disables Layer Slider auto update box
		 */
		function buro_mikado_layerslider_overrides() {
			$GLOBALS['lsAutoUpdateBox'] = false;
		}

		add_action('layerslider_ready', 'buro_mikado_layerslider_overrides');
	}
?>