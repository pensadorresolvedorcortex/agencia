<?php if(buro_mikado_options()->getOptionValue('blog_single_navigation') == 'yes'){ ?>
	<?php $navigation_blog_through_category = buro_mikado_options()->getOptionValue('blog_navigation_through_same_category') ?>
	<div class="mkd-blog-single-navigation">
		<div class="mkd-blog-single-navigation-inner">
			<?php if(get_previous_post() != ""){
				if($navigation_blog_through_category == 'yes'){
					if(get_previous_post(true) != ""){
						$prev_post = get_previous_post(true);
					}
				} else {
					if(get_previous_post() != ""){
						$prev_post = get_previous_post();
					}
				}

				$prev_post_ID = $prev_post->ID;
				$prev_background_image_src = wp_get_attachment_image_src(get_post_thumbnail_id($prev_post_ID),'buro_mikado_square');
				$prev_post_thumbnail = $prev_background_image_src[0];
				$prev_classes = '';

				if ($prev_post_thumbnail == ''){
					$prev_classes = 'mkd-nav-no-img';
				}

				$prev_post_title = '';

				if($prev_post->post_title != '') {
					$prev_post_title = $prev_post->post_title;
				}

				$prev_html = '<div class="mkd-nav-holder '.esc_attr($prev_classes).'">';
				$prev_html .= '<div class="mkd-nav-image" style="background-image:url('.esc_url($prev_post_thumbnail).');">';
				$prev_html .= '</div>';
				$prev_html .= '<div class="mkd-nav-title">';
				$prev_html .= '<h5 class="mkd-nav-title-inner">'.esc_html($prev_post_title).'</h5>';
				$prev_html .= '<span class="mkd-nav-text">';
				$prev_html .= '<span class="mkd-nav-arrows arrow_left"></span>';
				$prev_html .= esc_html__('Previous','buro');
				$prev_html .= '</span>';
				$prev_html .= '</div>';
				$prev_html .= '</div>';

				?>
				<div class="mkd-blog-single-prev">
					<?php
					if($navigation_blog_through_category == 'yes'){
						previous_post_link('%link', $prev_html, true,'','category');
						
					} else {
						previous_post_link('%link',$prev_html);
					}
					?>
				</div><!-- close div.blog_prev -->
			<?php } else { ?>
				<div class="mkd-blog-single-prev"></div>
			<?php } ?>

			<?php if(get_next_post() != ""){
				if($navigation_blog_through_category == 'yes'){
					if(get_next_post(true) != ""){
						$next_post = get_next_post(true);
					}
				} else {
					if(get_next_post() != ""){
						$next_post = get_next_post();
					}
				}

				$next_post_ID = $next_post->ID;
				$next_background_image_src = wp_get_attachment_image_src(get_post_thumbnail_id($next_post_ID),'buro_mikado_square');
				$next_post_thumbnail = $next_background_image_src[0];
				$next_classes = '';

				if ($next_post_thumbnail == ''){
					$next_classes = 'mkd-nav-no-img';
				}

				$next_post_title = '';

				if($next_post->post_title != '') {
					$next_post_title = $next_post->post_title;
				}

				$next_html = '<div class="mkd-nav-holder '.esc_attr($next_classes).'">';
				$next_html .= '<div class="mkd-nav-title">';
				$next_html .= '<h5 class="mkd-nav-title-inner">'.esc_html($next_post_title).'</h5>';
				$next_html .= '<span class="mkd-nav-text">';
				$next_html .= esc_html__('Next','buro');
				$next_html .= '<span class="mkd-nav-arrows arrow_right"></span>';
				$next_html .= '</span>';
				$next_html .= '</div>';
				$next_html .= '<div class="mkd-nav-image" style="background-image:url('.esc_url($next_post_thumbnail).');">';
				$next_html .= '</div>';
				$next_html .= '</div>';

				?>
				<div class="mkd-blog-single-next">
					<?php
					if($navigation_blog_through_category == 'yes'){
						next_post_link('%link', $next_html, true,'','category');
					} else {
						next_post_link('%link',$next_html);
					}
					?>
				</div>
			<?php } else { ?>
				<div class="mkd-blog-single-next"></div>
			<?php } ?>
		</div>
	</div>
<?php } ?>