<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="mkd-post-content">
		<div class="mkd-post-text">
			<div class="mkd-post-text-inner clearfix">
				<h5 class="mkd-post-title">
					<span><?php echo esc_html(get_post_meta(get_the_ID(), "mkd_post_quote_text_meta", true)); ?></span>
				</h5>
				<span class="mkd-quote-author"><?php the_title(); ?></span>
			</div>
		</div>

        <div class="mkd-post-info-top">
            <div class="mkd-post-info-top-left">
                <?php buro_mikado_post_info(array(
                    'date' => 'yes',
                    'author' => 'yes',
                    'category' => 'yes',
                )) ?>
            </div>
            <div class="mkd-post-info-top-right">
                <?php buro_mikado_post_info(array(
                    'comments' => 'yes',
                    'like' => 'yes',
                ), 'single') ?>
            </div>
        </div>

		<?php the_content(); ?>

        <div class="mkd-blog-single-share"><?php echo buro_mikado_get_social_share_html();?></div>

		<?php buro_mikado_get_module_template_part('templates/lists/parts/pages-navigation', 'blog');  ?>

	</div>
</article>