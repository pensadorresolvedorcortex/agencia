<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

    <div class="mkd-post-content">
        <div class="mkd-post-text">
            <a class="mkd-post-whole-link" href="<?php echo esc_url(get_post_meta(get_the_ID(), "mkd_post_link_link_meta", true)); ?>" title="<?php the_title_attribute(); ?>"></a>
            <div class="mkd-post-text-inner clearfix">
                <div class="mkd-post-mark mkd-link-mark">
                    <span class="icon_paperclip"></span>
                </div>
                <?php buro_mikado_get_module_template_part('templates/single/parts/link', 'blog'); ?>
                <span class="mkd-post-link-title">
					<a href="<?php echo esc_url(get_post_meta(get_the_ID(), "mkd_post_link_link_meta", true)); ?>"
                       title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
				</span>
            </div>
        </div>

        <div class="mkd-post-info-top">
            <div class="mkd-post-info-top-left">
                <?php buro_mikado_post_info(array(
                    'date' => 'yes',
                    'author' => 'yes',
                    'category' => 'yes',
                )) ?>
            </div>
            <div class="mkd-post-info-top-right">
                <?php buro_mikado_post_info(array(
                    'comments' => 'yes',
                    'like' => 'yes',
                ), 'single') ?>
            </div>
        </div>

        <?php the_content(); ?>

        <div class="mkd-blog-single-share"><?php echo buro_mikado_get_social_share_html();?></div>

        <?php buro_mikado_get_module_template_part('templates/lists/parts/pages-navigation', 'blog'); ?>

    </div>
</article>