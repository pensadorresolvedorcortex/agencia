<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="mkd-post-content">
		<?php buro_mikado_get_module_template_part('templates/single/parts/image', 'blog'); ?>
		<?php buro_mikado_get_module_template_part('templates/parts/audio', 'blog'); ?>
		<div class="mkd-post-text">
			<div class="mkd-post-text-inner clearfix">
				<?php buro_mikado_get_module_template_part('templates/single/parts/title', 'blog'); ?>

                <div class="mkd-post-info-top">
                    <div class="mkd-post-info-top-left">
                        <?php buro_mikado_post_info(array(
                            'date' => 'yes',
                            'author' => 'yes',
                            'category' => 'yes',
                        )) ?>
                    </div>
                    <div class="mkd-post-info-top-right">
                        <?php buro_mikado_post_info(array(
                            'comments' => 'yes',
                            'like' => 'yes',
                        ), 'single') ?>
                    </div>
                </div>

				<?php the_content(); ?>

                <div class="mkd-blog-single-share"><?php echo buro_mikado_get_social_share_html();?></div>

				<?php buro_mikado_get_module_template_part('templates/lists/parts/pages-navigation', 'blog');  ?>

			</div>
		</div>
	</div>
	<?php do_action('buro_mikado_before_blog_article_closed_tag'); ?>
</article>