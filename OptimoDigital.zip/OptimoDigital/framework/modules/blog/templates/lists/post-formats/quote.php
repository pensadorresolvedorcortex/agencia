<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="mkd-post-content">
		<div class="mkd-post-text">
            <a class="mkd-post-whole-link" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"></a>
			<div class="mkd-post-text-inner">
				<h5 class="mkd-post-title">
					<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php echo esc_html(get_post_meta(get_the_ID(), "mkd_post_quote_text_meta", true)); ?></a>
				</h5>
				<span class="mkd-quote-author"><?php the_title(); ?></span>
			</div>
		</div>
	</div>
</article>