<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="mkd-post-content">
		<?php buro_mikado_get_module_template_part('templates/lists/parts/gallery', 'blog'); ?>
		<div class="mkd-post-text">
			<div class="mkd-post-text-inner">
				<?php buro_mikado_get_module_template_part('templates/lists/parts/title', 'blog'); ?>

                <div class="mkd-post-info-top">
                    <div class="mkd-post-info-top-left">
                        <?php buro_mikado_post_info(array(
                            'date' => 'yes',
                            'author' => $show_author,
                            'category' => $show_category,
                            'comments' => 'no',
                            'like' => 'no'
                        )) ?>
                    </div>
                </div>

				<?php  if ($type == 'standard-whole-post') {
					the_content();
				}
				else{
					buro_mikado_excerpt($excerpt_length);
				}
				?>
				<?php buro_mikado_get_module_template_part('templates/lists/parts/pages-navigation', 'blog');  ?>

                <div class="mkd-post-info-bottom">
                    <div class="mkd-post-info-bottom-left">
                        <?php buro_mikado_post_info(array(
                            'date' => 'no',
                            'author' => 'no',
                            'category' => 'no',
                            'comments' => 'yes',
                            'like' => 'yes'
                        )) ?>
                    </div>
                    <div class="mkd-post-info-bottom-right">
                        <?php echo buro_mikado_get_button_html(array(
                            'type' => 'transparent',
                            'size' => 'medium',
                            'link' => get_the_permalink(),
                            'text' => esc_html__('Leia Mais', 'buro'),
                            'icon_pack' => 'font_elegant',
                            'fe_icon' => 'arrow_right',
                            'custom_class' => 'mkd-blog-btn-read-more'
                        )); ?>
                    </div>
                </div>
			</div>
		</div>
	</div>
</article>