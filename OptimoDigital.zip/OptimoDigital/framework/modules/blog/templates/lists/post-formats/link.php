<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="mkd-post-content">
		<div class="mkd-post-text">
            <a class="mkd-post-whole-link" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"></a>
			<div class="mkd-post-text-inner">
				<div class="mkd-post-mark mkd-link-mark">
					<span class="icon_paperclip"></span>
				</div>
				<?php buro_mikado_get_module_template_part('templates/lists/parts/link', 'blog'); ?>
				<span class="mkd-post-link-title">
					<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
				</span>
			</div>
		</div>
	</div>
</article>