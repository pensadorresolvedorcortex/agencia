<div class="mkd-blog-like">
	<?php if( function_exists('buro_mikado_like_blog_single') ) echo buro_mikado_like_blog_single(); ?>
</div>