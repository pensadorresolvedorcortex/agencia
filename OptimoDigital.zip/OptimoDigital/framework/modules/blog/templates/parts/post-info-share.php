<div class ="mkd-blog-share">
	<?php echo buro_mikado_get_social_share_html(); ?>
</div>