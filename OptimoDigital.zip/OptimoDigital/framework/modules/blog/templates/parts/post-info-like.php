<div class="mkd-blog-like">
	<?php if( function_exists('buro_mikado_get_like') ) buro_mikado_get_like(); ?>
</div>