<div class="mkd-post-info-comments-holder">
    <a class="mkd-post-info-comments" href="<?php comments_link(); ?>" target="_self">
        <span class="icon_comment_alt"></span><?php comments_number(esc_html__('Sem Comentários','buro'), '1 '.esc_html__('Comentário','buro'), '% '.esc_html__('Comentários','buro')); ?></a></div>