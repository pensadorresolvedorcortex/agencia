<?php
/**
 * Custom styles for Counter shortcode
 * Hooks to buro_mikado_style_dynamic hook
 */

//if (!function_exists('buro_mikado_counter_style')) {
//
//	function buro_mikado_counter_style()
//	{
//
//		if (buro_mikado_options()->getOptionValue('option_value') !== '') {
//			echo buro_mikado_dynamic_css('.css-class', array(
//				//Css rules, etc
//				'height' => buro_mikado_filter_px(buro_mikado_options()->getOptionValue('option_value')) . 'px'
//			));
//		}
//
//	}
//
//	add_action('buro_mikado_style_dynamic', 'buro_mikado_counter_style');
//
//}

?>