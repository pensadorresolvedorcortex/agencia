<?php
use BuroMikado\Modules\Header\Lib;

if(!function_exists('buro_mikado_set_header_object')) {
    function buro_mikado_set_header_object() {
        $header_type = buro_mikado_get_meta_field_intersect('header_type', buro_mikado_get_page_id());

        $object = Lib\HeaderFactory::getInstance()->build($header_type);

        if(Lib\HeaderFactory::getInstance()->validHeaderObject()) {
            $header_connector = new Lib\HeaderConnector($object);
            $header_connector->connect($object->getConnectConfig());
        }
    }

    add_action('wp', 'buro_mikado_set_header_object', 1);
}