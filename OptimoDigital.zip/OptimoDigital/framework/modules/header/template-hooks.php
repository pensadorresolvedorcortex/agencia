<?php

//top header bar
add_action('buro_mikado_before_page_header', 'buro_mikado_get_header_top');

//mobile header
add_action('buro_mikado_after_page_header', 'buro_mikado_get_mobile_header');