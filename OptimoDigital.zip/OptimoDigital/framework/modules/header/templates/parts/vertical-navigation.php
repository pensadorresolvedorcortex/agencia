<?php do_action('buro_mikado_before_top_navigation'); ?>

    <nav data-navigation-type='float' class="mkd-vertical-menu mkd-vertical-dropdown-float">
        <?php
        wp_nav_menu(array(
            'theme_location'  => 'vertical-navigation',
            'container'       => '',
            'container_class' => '',
            'menu_class'      => '',
            'menu_id'         => '',
            'fallback_cb'     => 'top_navigation_fallback',
            'link_before'     => '<span>',
            'link_after'      => '</span>',
            'walker'          => new BuroMikadoTopNavigationWalker()
        ));
        ?>
    </nav>

<?php do_action('buro_mikado_after_top_navigation'); ?>