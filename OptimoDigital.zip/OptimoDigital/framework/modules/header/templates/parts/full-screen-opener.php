<?php do_action('buro_mikado_before_top_navigation'); ?>
<a href="javascript:void(0)" class="mkd-fullscreen-menu-opener <?php echo esc_attr($icon_size)?>">
	<span class="mkd-fullscreen-menu-opener-inner">
		<span class="mkd-sai mkd-sai-one"></span><span class="mkd-sai mkd-sai-two"></span><span class="mkd-sai mkd-sai-three"></span>
	</span>
</a>
<?php do_action('buro_mikado_after_top_navigation'); ?>