<?php if (is_active_sidebar($widget_area)) { ?>
    <div class="header-widget-area">
        <?php dynamic_sidebar($widget_area); ?>
    </div>
<?php } ?>