<?php do_action('buro_mikado_before_page_header'); ?>
<aside class="mkd-vertical-menu-area">
    <div class="mkd-vertical-menu-area-inner">
        <div class="mkd-vertical-area-background" <?php buro_mikado_inline_style(array($vertical_header_background_color,$vertical_header_opacity,$vertical_background_image)); ?>></div>
        <?php if(!$hide_logo) {
            buro_mikado_get_logo();
        } ?>
        <?php buro_mikado_get_vertical_main_menu(); ?>
        <div class="mkd-vertical-area-widget-holder">
           <?php buro_mikado_get_header_widget(); ?>
        </div>
    </div>
</aside>

<?php do_action('buro_mikado_after_page_header'); ?>