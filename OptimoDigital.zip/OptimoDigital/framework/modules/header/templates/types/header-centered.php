<?php do_action('buro_mikado_before_page_header'); ?>

<header class="mkd-page-header">
    <?php if($show_fixed_wrapper) : ?>
        <div class="mkd-fixed-wrapper">
    <?php endif; ?>
    <div class="mkd-menu-area" <?php buro_mikado_inline_style(array($menu_area_background_color, $menu_area_border_bottom_color)); ?>>
        <?php if($menu_area_in_grid) : ?>
            <div class="mkd-grid">
        <?php endif; ?>
			<?php do_action( 'buro_mikado_after_header_menu_area_html_open' )?>
            <div class="mkd-vertical-align-containers">
                <div class="mkd-position-left">
                    <div class="mkd-position-left-inner">
                        <?php if(!$hide_logo) {
                            buro_mikado_get_logo();
                        } ?>
                    </div>
                </div>
				<div class="mkd-position-center">
					<div class="mkd-position-center-inner">
						<?php buro_mikado_get_main_menu(); ?>
					</div>
				</div>
                <div class="mkd-position-right">
                    <div class="mkd-position-right-inner">
                        <?php buro_mikado_get_header_widget(); ?>
                    </div>
                </div>
            </div>
        <?php if($menu_area_in_grid) : ?>
        </div>
        <?php endif; ?>
    </div>
    <?php if($show_fixed_wrapper) : ?>
        </div>
    <?php endif; ?>
    <?php if($show_sticky) {
        buro_mikado_get_sticky_header('centered');
    } ?>
</header>

<?php do_action('buro_mikado_after_page_header'); ?>

