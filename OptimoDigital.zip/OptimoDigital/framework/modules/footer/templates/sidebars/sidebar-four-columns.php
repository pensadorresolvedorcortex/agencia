<?php
$mkd_footer_top_column_1 = buro_mikado_get_footer_1_widget();
$mkd_footer_top_column_2 = buro_mikado_get_footer_2_widget();
$mkd_footer_top_column_3 = buro_mikado_get_footer_3_widget();
$mkd_footer_top_column_4 = buro_mikado_get_footer_4_widget();
?>
<div class="mkd-four-columns clearfix">
	<div class="mkd-four-columns-inner">
		<div class="mkd-column">
			<div class="mkd-column-inner">
				<?php if(is_active_sidebar($mkd_footer_top_column_1)) {
					dynamic_sidebar( $mkd_footer_top_column_1);
				} ?>
			</div>
		</div>
		<div class="mkd-column">
			<div class="mkd-column-inner">
				<?php if(is_active_sidebar($mkd_footer_top_column_2)) {
					dynamic_sidebar($mkd_footer_top_column_2);
				} ?>
			</div>
		</div>
		<div class="mkd-column">
			<div class="mkd-column-inner">
				<?php if(is_active_sidebar($mkd_footer_top_column_3)) {
					dynamic_sidebar($mkd_footer_top_column_3);
				} ?>
			</div>
		</div>
		<div class="mkd-column">
			<div class="mkd-column-inner">
				<?php if(is_active_sidebar($mkd_footer_top_column_4)) {
					dynamic_sidebar($mkd_footer_top_column_4);
				} ?>
			</div>
		</div>
	</div>
</div>