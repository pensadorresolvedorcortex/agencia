<?php

//Get search HTML
add_action('buro_mikado_before_page_header', 'buro_mikado_get_search', 9);