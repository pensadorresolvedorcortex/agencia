<?php
if ( ! function_exists('buro_mikado_contact_form_map') ) {
	/**
	 * Map Contact Form 7 shortcode
	 * Hooks on vc_after_init action
	 */
	function buro_mikado_contact_form_map()
	{

		vc_add_param('contact-form-7', array(
			'type' => 'dropdown',
			'heading' => esc_html__('Style','buro'),
			'param_name' => 'html_class',
			'value' => array(
				esc_html__('Default','buro') => 'default',
				esc_html__('Custom Style 1','buro') => 'cf7_custom_style_1',
				esc_html__('Custom Style 2','buro') => 'cf7_custom_style_2',
				esc_html__('Custom Style 3','buro') => 'cf7_custom_style_3',
				esc_html__('Custom Style 4','buro') => 'cf7_custom_style_4',
			),
			'description' => esc_html__('You can style each form element individually in Mikado Options > Contact Form 7','buro')
		));

	}
	add_action('vc_after_init', 'buro_mikado_contact_form_map');
}
?>