<?php

if (!function_exists('buro_mikado_register_widgets')) {

	function buro_mikado_register_widgets() {

		$widgets = array(
			'BuroMikadoLatestPosts',
			'BuroMikadoSearchOpener',
			'BuroMikadoSideAreaOpener',
			'BuroMikadoStickySidebar',
			'BuroMikadoSocialIconWidget',
			'BuroMikadoSeparatorWidget'
		);

		foreach ($widgets as $widget) {
			register_widget($widget);
		}
	}
}

add_action('widgets_init', 'buro_mikado_register_widgets');