<?php

/**
 * Widget that adds separator boxes type
 *
 * Class Separator_Widget
 */
class BuroMikadoSeparatorWidget extends BuroMikadoWidget {
    /**
     * Set basic widget options and call parent class construct
     */
    public function __construct() {
        parent::__construct(
            'mkd_separator_widget', // Base ID
            esc_html__('Mikado Separator Widget','buro') // Name
        );

        $this->setParams();
    }

    /**
     * Sets widget options
     */
    protected function setParams() {
        $this->params = array(
            array(
                'type' => 'dropdown',
                'title' => esc_html__('Type', 'buro'),
                'name' => 'type',
                'options' => array(
                    'normal' => esc_html__('Normal', 'buro'),
                    'full-width' => esc_html__('Full Width', 'buro'),
                )
            ),
            array(
                'type' => 'dropdown',
                'title' => esc_html__('Position', 'buro'),
                'name' => 'position',
                'options' => array(
                    'center' => esc_html__('Center', 'buro'),
                    'left' => esc_html__('Left', 'buro'),
                    'right' => esc_html__('Right', 'buro'),
                )
            ),
            array(
                'type' => 'dropdown',
                'title' => esc_html__('Style', 'buro'),
                'name' => 'border_style',
                'options' => array(
                    'solid' => esc_html__('Solid', 'buro'),
                    'dashed' => esc_html__('Dashed', 'buro'),
                    'dotted' => esc_html__('Dotted','buro'),
                )
            ),
            array(
                'type' => 'textfield',
                'title' => esc_html__('Color', 'buro'),
                'name' => 'color'
            ),
            array(
                'type' => 'textfield',
                'title' => esc_html__('Width', 'buro'),
                'name' => 'width',
            ),
            array(
                'type' => 'textfield',
                'title' => esc_html__('Thickness (px)', 'buro'),
                'name' => 'thickness',
            ),
            array(
                'type' => 'textfield',
                'title' => esc_html__('Top Margin', 'buro'),
                'name' => 'top_margin',
            ),
            array(
                'type' => 'textfield',
                'title' => esc_html__('Bottom Margin', 'buro'),
                'name' => 'bottom_margin',
            )
        );
    }

    /**
     * Generates widget's HTML
     *
     * @param array $args args from widget area
     * @param array $instance widget's options
     */
    public function widget($args, $instance) {

        extract($args);

        //prepare variables
        $params = '';

        //is instance empty?
        if(is_array($instance) && count($instance)) {
            //generate shortcode params
            foreach($instance as $key => $value) {
                $params .= " $key='$value' ";
            }
        }

        echo '<div class="widget mkd-separator-widget">';

        //finally call the shortcode
        echo do_shortcode("[mkd_separator $params]"); // XSS OK

        echo '</div>'; //close div.mkd-separator-widget
    }
}