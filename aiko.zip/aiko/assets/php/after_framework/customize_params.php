<?php


// HEADER LINES SEPARATOR
if ( ! function_exists( 'boldthemes_customize_separator_header_lines' ) ) {
	function boldthemes_customize_separator_header_lines( $wp_customize ) {
		$wp_customize->add_setting( BoldThemesFramework::$pfx . '_separator_header_lines', array(
			'sanitize_callback' => 'boldthemes_sanitize',
		) );
		$wp_customize->add_control( new BoldThemes_Customize_Separator_Control( $wp_customize, BoldThemesFramework::$pfx . '_separator_header_lines',
			array(
				'label' => esc_html__( 'Header details', 'aiko' ),
				'section'  => BoldThemesFramework::$pfx . '_header_section',
				'priority' => 361
		)));	
	}
}

add_action( 'customize_register', 'boldthemes_customize_separator_header_lines' );


// HEADER LINES
if ( ! function_exists( 'boldthemes_customize_header_lines' ) ) {
	function boldthemes_customize_header_lines( $wp_customize ) {
		
		$wp_customize->add_setting( BoldThemesFramework::$pfx . '_theme_options[header_lines]', array(
			'default'           => BoldThemes_Customize_Default::$data['header_lines'],
			'type'              => 'option',
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field'
		));
		$wp_customize->add_control( 'header_lines', array(
			'label'     		=> esc_html__( 'Show line below Header', 'aiko' ),
			'section'   		=> BoldThemesFramework::$pfx . '_header_section',
			'settings'  		=> BoldThemesFramework::$pfx . '_theme_options[header_lines]',
			'priority'  		=> 362,
			'type'      		=> 'select',
			'choices'   => array(
				''			=> esc_html__( 'No', 'aiko' ),
				'show' 		=> esc_html__( 'Yes', 'aiko' )
				
			)
		));
	}
}
add_action( 'customize_register', 'boldthemes_customize_header_lines' );
add_action( 'boldthemes_customize_register', 'boldthemes_customize_header_lines' );

BoldThemesFramework::$customize_body_class[] = 'header_lines';


// OPACITY HEADER LINES
if ( ! function_exists( 'boldthemes_customize_lines_opacity' ) ) {
	function boldthemes_customize_lines_opacity( $wp_customize ) {
		
		$wp_customize->add_setting( BoldThemesFramework::$pfx . '_theme_options[lines_opacity]', array(
			'default'           => BoldThemes_Customize_Default::$data['lines_opacity'],
			'type'              => 'option',
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field'
		));
		$wp_customize->add_control( 'lines_opacity', array(
			'label'     		=> esc_html__( 'Lines opacity', 'aiko' ),
			'section'   		=> BoldThemesFramework::$pfx . '_header_section',
			'settings'  		=> BoldThemesFramework::$pfx . '_theme_options[lines_opacity]',
			'priority'  		=> 363,
			'type'      		=> 'select',
			'choices'   => array(
				''					=> esc_html__( 'Full', 'aiko' ),
				'extra-huge' 		=> esc_html__( '0.9', 'aiko' ),
				'huge' 				=> esc_html__( '0.8', 'aiko' ),
				'extra-large' 		=> esc_html__( '0.7', 'aiko' ),
				'large' 			=> esc_html__( '0.6', 'aiko' ),
				'medium' 			=> esc_html__( '0.5', 'aiko' ),
				'normal' 			=> esc_html__( '0.4', 'aiko' ),
				'small' 			=> esc_html__( '0.3', 'aiko' ),
				'extra-small' 		=> esc_html__( '0.2', 'aiko' ),
				'verysmall' 		=> esc_html__( '0.1', 'aiko' )
			)
		));
	}
}
add_action( 'customize_register', 'boldthemes_customize_lines_opacity' );
add_action( 'boldthemes_customize_register', 'boldthemes_customize_lines_opacity' );

BoldThemesFramework::$customize_body_class[] = 'lines_opacity';


// BLUR BACKGROUND HEADER
if ( ! function_exists( 'boldthemes_customize_blur' ) ) {
	function boldthemes_customize_blur( $wp_customize ) {
		
		$wp_customize->add_setting( BoldThemesFramework::$pfx . '_theme_options[blur]', array(
			'default'           => BoldThemes_Customize_Default::$data['blur'],
			'type'              => 'option',
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field'
		));
		$wp_customize->add_control( 'blur', array(
			'label'     		=> esc_html__( 'Blur', 'aiko' ),
			'section'   		=> BoldThemesFramework::$pfx . '_header_section',
			'settings'  		=> BoldThemesFramework::$pfx . '_theme_options[blur]',
			'priority'  		=> 364,
			'type'      		=> 'select',
			'choices'   => array(
				''					=> esc_html__( 'No', 'aiko' ),
				'show' 				=> esc_html__( 'Yes', 'aiko' )
			)
		));
	}
}
add_action( 'customize_register', 'boldthemes_customize_blur' );
add_action( 'boldthemes_customize_register', 'boldthemes_customize_blur' );

BoldThemesFramework::$customize_body_class[] = 'blur';


// CURRENT MENU LINE COLOR
if ( ! function_exists( 'boldthemes_customize_current_menu_line_color' ) ) {
	function boldthemes_customize_current_menu_line_color( $wp_customize ) {
		
		$wp_customize->add_setting( BoldThemesFramework::$pfx . '_theme_options[current_menu_line_color]', array(
			'default'           => BoldThemes_Customize_Default::$data['current_menu_line_color'],
			'type'              => 'option',
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field'
		));
		$wp_customize->add_control( 'current_menu_line_color', array(
			'label'     		=> esc_html__( 'Current menu line color', 'aiko' ),
			'section'   		=> BoldThemesFramework::$pfx . '_header_section',
			'settings'  		=> BoldThemesFramework::$pfx . '_theme_options[current_menu_line_color]',
			'priority'  		=> 366,
			'type'      		=> 'select',
			'choices'   => array(
				''			=> esc_html__( 'Inherit', 'aiko' ),
				'light' 		=> esc_html__( 'Light', 'aiko' ),
				'dark' 			=> esc_html__( 'Dark', 'aiko' ),
				'accent' 		=> esc_html__( 'Accent', 'aiko' ),
				'alternate' 	=> esc_html__( 'Alternate', 'aiko' )
			)
		));
	}
}
add_action( 'customize_register', 'boldthemes_customize_current_menu_line_color' );
add_action( 'boldthemes_customize_register', 'boldthemes_customize_current_menu_line_color' );

BoldThemesFramework::$customize_body_class[] = 'current_menu_line_color';


// STICKY BLUR BACKGROUND HEADER
if ( ! function_exists( 'boldthemes_customize_sticky_blur' ) ) {
	function boldthemes_customize_sticky_blur( $wp_customize ) {
		
		$wp_customize->add_setting( BoldThemesFramework::$pfx . '_theme_options[sticky_blur]', array(
			'default'           => BoldThemes_Customize_Default::$data['sticky_blur'],
			'type'              => 'option',
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field'
		));
		$wp_customize->add_control( 'sticky_blur', array(
			'label'     		=> esc_html__( 'Blur', 'aiko' ),
			'section'   		=> BoldThemesFramework::$pfx . '_sticky_header_section',
			'settings'  		=> BoldThemesFramework::$pfx . '_theme_options[sticky_blur]',
			'priority'  		=> 365,
			'type'      		=> 'select',
			'choices'   => array(
				''					=> esc_html__( 'No', 'aiko' ),
				'show' 				=> esc_html__( 'Yes', 'aiko' )
			)
		));
	}
}
add_action( 'customize_register', 'boldthemes_customize_sticky_blur' );
add_action( 'boldthemes_customize_register', 'boldthemes_customize_sticky_blur' );

BoldThemesFramework::$customize_body_class[] = 'sticky_blur';


// CURRENT MENU LINE COLOR
if ( ! function_exists( 'boldthemes_customize_sticky_current_menu_line_color' ) ) {
	function boldthemes_customize_sticky_current_menu_line_color( $wp_customize ) {
		
		$wp_customize->add_setting( BoldThemesFramework::$pfx . '_theme_options[sticky_current_menu_line_color]', array(
			'default'           => BoldThemes_Customize_Default::$data['sticky_current_menu_line_color'],
			'type'              => 'option',
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field'
		));
		$wp_customize->add_control( 'sticky_current_menu_line_color', array(
			'label'     		=> esc_html__( 'Current menu line color', 'aiko' ),
			'section'   		=> BoldThemesFramework::$pfx . '_sticky_header_section',
			'settings'  		=> BoldThemesFramework::$pfx . '_theme_options[sticky_current_menu_line_color]',
			'priority'  		=> 366,
			'type'      		=> 'select',
			'choices'   => array(
				''			=> esc_html__( 'Inherit', 'aiko' ),
				'light' 		=> esc_html__( 'Light', 'aiko' ),
				'dark' 			=> esc_html__( 'Dark', 'aiko' ),
				'accent' 		=> esc_html__( 'Accent', 'aiko' ),
				'alternate' 	=> esc_html__( 'Alternate', 'aiko' )
			)
		));
	}
}
add_action( 'customize_register', 'boldthemes_customize_sticky_current_menu_line_color' );
add_action( 'boldthemes_customize_register', 'boldthemes_customize_sticky_current_menu_line_color' );

BoldThemesFramework::$customize_body_class[] = 'sticky_current_menu_line_color';


// BLOG IMAGE SHAPE
if ( ! function_exists( 'boldthemes_customize_blog_image_shape' ) ) {
	function boldthemes_customize_blog_image_shape( $wp_customize ) {
		
		$wp_customize->add_setting( BoldThemesFramework::$pfx . '_theme_options[blog_image_shape]', array(
			'default'           => BoldThemes_Customize_Default::$data['blog_image_shape'],
			'type'              => 'option',
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field'
		));
		$wp_customize->add_control( 'blog_image_shape', array(
			'label'     		=> esc_html__( 'Images shape', 'aiko' ),
			'section'   		=> BoldThemesFramework::$pfx . '_blog_list_section',
			'settings'  		=> BoldThemesFramework::$pfx . '_theme_options[blog_image_shape]',
			'priority'  		=> 100,
			'type'      		=> 'select',
			'choices'   => array(
				''					=> esc_html__( 'Inherit', 'aiko' ),
				'square' 			=> esc_html__( 'Square', 'aiko' ),
				'soft-rounded' 		=> esc_html__( 'Soft rounded', 'aiko' ),
				'hard-rounded' 		=> esc_html__( 'Hard rounded', 'aiko' )
			)
		));
	}
}
add_action( 'customize_register', 'boldthemes_customize_blog_image_shape' );
add_action( 'boldthemes_customize_register', 'boldthemes_customize_blog_image_shape' );

BoldThemesFramework::$customize_body_class[] = 'blog_image_shape';



// PORTFOLIO IMAGE SHAPE
if ( ! function_exists( 'boldthemes_customize_pf_image_shape' ) ) {
	function boldthemes_customize_pf_image_shape( $wp_customize ) {
		
		$wp_customize->add_setting( BoldThemesFramework::$pfx . '_theme_options[pf_image_shape]', array(
			'default'           => BoldThemes_Customize_Default::$data['pf_image_shape'],
			'type'              => 'option',
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field'
		));
		$wp_customize->add_control( 'pf_image_shape', array(
			'label'     		=> esc_html__( 'Images shape', 'aiko' ),
			'section'   		=> BoldThemesFramework::$pfx . '_pf_list_section',
			'settings'  		=> BoldThemesFramework::$pfx . '_theme_options[pf_image_shape]',
			'priority'  		=> 100,
			'type'      		=> 'select',
			'choices'   => array(
				''					=> esc_html__( 'Inherit', 'aiko' ),
				'square' 			=> esc_html__( 'Square', 'aiko' ),
				'soft-rounded' 		=> esc_html__( 'Soft rounded', 'aiko' ),
				'hard-rounded' 		=> esc_html__( 'Hard rounded', 'aiko' )
			)
		));
	}
}
add_action( 'customize_register', 'boldthemes_customize_pf_image_shape' );
add_action( 'boldthemes_customize_register', 'boldthemes_customize_pf_image_shape' );

BoldThemesFramework::$customize_body_class[] = 'pf_image_shape';



// SHOP IMAGE SHAPE
if ( ! function_exists( 'boldthemes_customize_shop_image_shape' ) ) {
	function boldthemes_customize_shop_image_shape( $wp_customize ) {
		
		$wp_customize->add_setting( BoldThemesFramework::$pfx . '_theme_options[shop_image_shape]', array(
			'default'           => BoldThemes_Customize_Default::$data['shop_image_shape'],
			'type'              => 'option',
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field'
		));
		$wp_customize->add_control( 'shop_image_shape', array(
			'label'     		=> esc_html__( 'Images shape', 'aiko' ),
			'section'   		=> BoldThemesFramework::$pfx . '_shop_list_section',
			'settings'  		=> BoldThemesFramework::$pfx . '_theme_options[shop_image_shape]',
			'priority'  		=> 100,
			'type'      		=> 'select',
			'choices'   => array(
				''					=> esc_html__( 'Inherit', 'aiko' ),
				'square' 			=> esc_html__( 'Square', 'aiko' ),
				'soft-rounded' 		=> esc_html__( 'Soft rounded', 'aiko' ),
				'hard-rounded' 		=> esc_html__( 'Hard rounded', 'aiko' )
			)
		));
	}
}
add_action( 'customize_register', 'boldthemes_customize_shop_image_shape' );
add_action( 'boldthemes_customize_register', 'boldthemes_customize_shop_image_shape' );

BoldThemesFramework::$customize_body_class[] = 'shop_image_shape';


// SHOP HOVER PRODUCTS COLOR
BoldThemes_Customize_Default::$data['shop_hover_color'] = '';

if ( ! function_exists( 'boldthemes_customize_shop_hover_color' ) ) {
	function boldthemes_customize_shop_hover_color( $wp_customize ) {
		
		$wp_customize->add_setting( BoldThemesFramework::$pfx . '_theme_options[shop_hover_color]', array(
			'default'           => BoldThemes_Customize_Default::$data['shop_hover_color'],
			'type'              => 'option',
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage'
		));
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'shop_hover_color', array(
			'label'     		=> esc_html__( 'Hover color on Single product', 'aiko' ),
			'section'   		=> BoldThemesFramework::$pfx . '_shop_general_section',
			'settings'  		=> BoldThemesFramework::$pfx . '_theme_options[shop_hover_color]',
			'priority'  		=> 101
		)));
	}
}
add_action( 'customize_register', 'boldthemes_customize_shop_hover_color' );
add_action( 'boldthemes_customize_register', 'boldthemes_customize_shop_hover_color' );

BoldThemesFramework::$customize_css_vars[] = 'shop_hover_color';