<?php


// COLOR SCHEME
if ( is_file( dirname(__FILE__) . '/../../../../../plugins/bold-page-builder/content_elements_misc/misc.php' ) ) {
	require_once( dirname(__FILE__) . '/../../../../../plugins/bold-page-builder/content_elements_misc/misc.php' );
}


if ( function_exists('bt_bb_get_color_scheme_param_array') ) {
	$color_scheme_arr = bt_bb_get_color_scheme_param_array();
} else {
	$color_scheme_arr = array();
}

// ANIMATED HEADLINE - REMOVE ANIMATION
if ( function_exists( 'bt_bb_remove_params' ) ) {
	bt_bb_remove_params( 'bt_bb_animated_headline', 'animation' );
}


// SECTION - NEGATIVE MARGIN, OVERLAY, ALLOW CONTENT OUTSIDE, SHAPE
if ( function_exists( 'bt_bb_remove_params' ) ) {
	bt_bb_remove_params( 'bt_bb_section', 'background_overlay' );
}

if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_section', array(
		array( 'param_name' => 'negative_margin', 'type' => 'dropdown', 'default' => '', 'weight' => 3, 'heading' => esc_html__( 'Top negative margin', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No margin', 'aiko' ) 		=> 'none',
				esc_html__( 'Extra small', 'aiko' ) 		=> 'extra_small',
				esc_html__( 'Small', 'aiko' ) 			=> 'small',
				esc_html__( 'Normal', 'aiko' ) 			=> 'normal',
				esc_html__( 'Medium', 'aiko' ) 			=> 'medium',
				esc_html__( 'Large', 'aiko' ) 			=> 'large',
				esc_html__( 'Extra large', 'aiko' ) 		=> 'extra_large',
				esc_html__( 'Huge', 'aiko' ) 			=> 'huge',
				esc_html__( '5px', 'aiko' ) 				=> '5px',
				esc_html__( '10px', 'aiko' ) 			=> '10px',
				esc_html__( '15px', 'aiko' ) 			=> '15px',
				esc_html__( '20px', 'aiko' ) 			=> '20px',
				esc_html__( '25px', 'aiko' ) 			=> '25px',
				esc_html__( '30px', 'aiko' ) 			=> '30px',
				esc_html__( '35px', 'aiko' ) 			=> '35px',
				esc_html__( '40px', 'aiko' ) 			=> '40px',
				esc_html__( '45px', 'aiko' ) 			=> '45px',
				esc_html__( '50px', 'aiko' ) 			=> '50px',
				esc_html__( '55px', 'aiko' ) 			=> '55px',
				esc_html__( '60px', 'aiko' ) 			=> '60px',
				esc_html__( '65px', 'aiko' ) 			=> '65px',
				esc_html__( '70px', 'aiko' ) 			=> '70px',
				esc_html__( '75px', 'aiko' ) 			=> '75px',
				esc_html__( '80px', 'aiko' ) 			=> '80px',
				esc_html__( '85px', 'aiko' ) 			=> '85px',
				esc_html__( '90px', 'aiko' ) 			=> '90px',
				esc_html__( '95px', 'aiko' ) 			=> '95px',
				esc_html__( '100px', 'aiko' ) 			=> '100px',
				esc_html__( '105px', 'aiko' ) 			=> '105px',
				esc_html__( '110px', 'aiko' ) 			=> '110px',
				esc_html__( '115px', 'aiko' ) 			=> '115px',
				esc_html__( '120px', 'aiko' ) 			=> '120px'
			)
		),
		array( 'param_name' => 'background_overlay', 'type' => 'dropdown', 'heading' => esc_html__( 'Background overlay', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ), 
			'value' => array(
				esc_html__( 'No overlay', 'aiko' )    					=> '',
				esc_html__( 'Light stripes', 'aiko' ) 					=> 'light_stripes',
				esc_html__( 'Dark stripes', 'aiko' )  					=> 'dark_stripes',
				esc_html__( 'Light solid', 'aiko' )	  					=> 'light_solid',
				esc_html__( 'Dark solid', 'aiko' )	  					=> 'dark_solid',
				esc_html__( 'Light top & bottom gradient', 'aiko' )	  	=> 'light_gradient',
				esc_html__( 'Light top gradient', 'aiko' )	  			=> 'light_top_gradient',
				esc_html__( 'Light bottom gradient', 'aiko' )	  		=> 'light_bottom_gradient',
				esc_html__( 'Dark top & bottom gradient', 'aiko' )	  	=> 'dark_gradient',
				esc_html__( 'Dark top gradient', 'aiko' )	  			=> 'dark_top_gradient',
				esc_html__( 'Dark bottom gradient', 'aiko' )	  			=> 'dark_bottom_gradient',
				esc_html__( 'Accent top gradient', 'aiko' )	 			=> 'accent_top_gradient',
				esc_html__( 'Accent bottom gradient', 'aiko' )	 		=> 'accent_bottom_gradient',
				esc_html__( 'Alternate top gradient', 'aiko' )	 		=> 'alternate_top_gradient',
				esc_html__( 'Alternate bottom gradient', 'aiko' )	 	=> 'alternate_bottom_gradient'
			)
		),
		array( 'param_name' => 'allow_content_outside', 'type' => 'dropdown', 'heading' => esc_html__( 'Top & bottom coverage images position', 'aiko' ), 'weight' => 20, 'group' => esc_html__( 'Design', 'aiko' ),
			'value' => array(
				esc_html__( 'Top & Bottom Coverage Image above content', 'aiko' ) 			=> '',
				esc_html__( 'Top & Bottom Coverage Image under content', 'aiko' ) 			=> 'under'
			)
		),

		array( 'param_name' => 'shape', 'type' => 'dropdown',  'preview' => true,  'heading' => esc_html__( 'Shape', 'aiko' ), 'group' => esc_html__( 'Shape', 'aiko' ),
			'value' => array(
				esc_html__( 'Square', 'aiko' ) 			=> '',
				esc_html__( 'Soft Rounded', 'aiko' ) 	=> 'soft-rounded',
				esc_html__( 'Hard Rounded', 'aiko' ) 	=> 'hard-rounded'
			)
		),
		array( 'param_name' => 'top_left_shape', 'type' => 'checkbox', 'value' => array( esc_html__( 'Yes', 'aiko' ) => 'top_left_shape' ), 'group' => esc_html__( 'Shape', 'aiko' ), 'heading' => esc_html__( 'Top Left', 'aiko' )
		),
		array( 'param_name' => 'top_right_shape', 'type' => 'checkbox', 'group' => esc_html__( 'Shape', 'aiko' ), 'value' => array( esc_html__( 'Yes', 'aiko' ) => 'top_right_shape' ), 'heading' => esc_html__( 'Top Right', 'aiko' )
		),
		array( 'param_name' => 'bottom_left_shape', 'type' => 'checkbox', 'group' => esc_html__( 'Shape', 'aiko' ), 'value' => array( esc_html__( 'Yes', 'aiko' ) => 'bottom_left_shape' ), 'heading' => esc_html__( 'Bottom Left', 'aiko' )
		),
		array( 'param_name' => 'bottom_right_shape', 'type' => 'checkbox', 'group' => esc_html__( 'Shape', 'aiko' ), 'value' => array( esc_html__( 'Yes', 'aiko' ) => 'bottom_right_shape' ), 'heading' => esc_html__( 'Bottom Right', 'aiko' )
		),
	));
}

add_filter( 'bt_bb_section_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'negative_margin';
	return $params;
});

function aiko_bt_bb_section_class( $class, $atts ) {
	if ( isset( $atts['allow_content_outside'] ) && $atts['allow_content_outside'] != '' ) {
		$class[] = 'bt_bb_allow_content_outside' . '_' . $atts['allow_content_outside'];
	}
	if ( isset( $atts['shape'] ) && $atts['shape'] != '' ) {
		$class[] = 'bt_bb_shape' . '_' . $atts['shape'];
	}
	if ( isset( $atts['top_left_shape'] ) && $atts['top_left_shape'] != '' ) {
		$class[] = 'bt_bb_top_left_shape';
	}
	if ( isset( $atts['top_right_shape'] ) && $atts['top_right_shape'] != '' ) {
		$class[] = 'bt_bb_top_right_shape';
	}
	if ( isset( $atts['bottom_left_shape'] ) && $atts['bottom_left_shape'] != '' ) {
		$class[] = 'bt_bb_bottom_left_shape';
	}
	if ( isset( $atts['bottom_right_shape'] ) && $atts['bottom_right_shape'] != '' ) {
		$class[] = 'bt_bb_bottom_right_shape';
	}
	return $class;
}

add_filter( 'bt_bb_section_class', 'aiko_bt_bb_section_class', 10, 2 );


// ROW - NEGATIVE MARGIN, BACKGROUND IMAGE, SHAPE, BLUR, BORDER

if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_row', array(
		array( 'param_name' => 'background_image', 'type' => 'attach_image',  'preview' => true, 'heading' => esc_html__( 'Background image', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ) ),
		array( 'param_name' => 'negative_margin', 'type' => 'dropdown', 'default' => '', 'heading' => esc_html__( 'Negative margin', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No margin', 'aiko' ) 		=> 'none',
				esc_html__( 'Extra small', 'aiko' ) 		=> 'extra_small',
				esc_html__( 'Small', 'aiko' ) 			=> 'small',
				esc_html__( 'Normal', 'aiko' ) 			=> 'normal',
				esc_html__( 'Medium', 'aiko' ) 			=> 'medium',
				esc_html__( 'Large', 'aiko' ) 			=> 'large',
				esc_html__( 'Extra large', 'aiko' ) 		=> 'extra_large',
				esc_html__( 'Huge', 'aiko' ) 			=> 'huge',
				esc_html__( '5px', 'aiko' ) 				=> '5px',
				esc_html__( '10px', 'aiko' ) 			=> '10px',
				esc_html__( '15px', 'aiko' ) 			=> '15px',
				esc_html__( '20px', 'aiko' ) 			=> '20px',
				esc_html__( '25px', 'aiko' ) 			=> '25px',
				esc_html__( '30px', 'aiko' ) 			=> '30px',
				esc_html__( '35px', 'aiko' ) 			=> '35px',
				esc_html__( '40px', 'aiko' ) 			=> '40px',
				esc_html__( '45px', 'aiko' ) 			=> '45px',
				esc_html__( '50px', 'aiko' ) 			=> '50px',
				esc_html__( '55px', 'aiko' ) 			=> '55px',
				esc_html__( '60px', 'aiko' ) 			=> '60px',
				esc_html__( '65px', 'aiko' ) 			=> '65px',
				esc_html__( '70px', 'aiko' ) 			=> '70px',
				esc_html__( '75px', 'aiko' ) 			=> '75px',
				esc_html__( '80px', 'aiko' ) 			=> '80px',
				esc_html__( '85px', 'aiko' ) 			=> '85px',
				esc_html__( '90px', 'aiko' ) 			=> '90px',
				esc_html__( '95px', 'aiko' ) 			=> '95px',
				esc_html__( '100px', 'aiko' ) 			=> '100px',
				esc_html__( '105px', 'aiko' ) 			=> '105px',
				esc_html__( '110px', 'aiko' ) 			=> '110px',
				esc_html__( '115px', 'aiko' ) 			=> '115px',
				esc_html__( '120px', 'aiko' ) 			=> '120px'
			)
		),
		array( 'param_name' => 'shape', 'type' => 'dropdown', 'preview' => true, 'heading' => esc_html__( 'Shape', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
			'value' => array(
				esc_html__( 'Square', 'aiko' ) 			=> '',
				esc_html__( 'Soft Rounded', 'aiko' ) 	=> 'soft-rounded',
				esc_html__( 'Hard Rounded', 'aiko' ) 	=> 'hard-rounded'
			)
		),
		array( 'param_name' => 'blur', 'type' => 'dropdown', 'heading' => esc_html__( 'Blur', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
			'value' => array(
				esc_html__( 'No', 'aiko' ) 				=> '',
				esc_html__( 'Yes', 'aiko' ) 				=> 'show'
			)
		),
		array( 'param_name' => 'border', 'type' => 'dropdown', 'heading' => esc_html__( 'Border', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
			'value' => array(
				esc_html__( 'No', 'aiko' ) 						=> '',
				esc_html__( 'Light border', 'aiko' ) 			=> 'light'
			)
		),
	));
}

add_filter( 'bt_bb_row_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'negative_margin';
	return $params;
});


function aiko_bt_bb_row_class( $class, $atts ) {
	if ( isset( $atts['background_image'] ) && $atts['background_image'] != '' ) {
		$class[] = 'bt_bb_row_with_bg_image';
	}
	if ( isset( $atts['shape'] ) && $atts['shape'] != '' ) {
		$class[] = 'bt_bb_shape' . '_' . $atts['shape'];
	}
	if ( isset( $atts['blur'] ) && $atts['blur'] != '' ) {
		$class[] = 'bt_bb_blur' . '_' . $atts['blur'];
	}
	if ( isset( $atts['border'] ) && $atts['border'] != '' ) {
		$class[] = 'bt_bb_border' . '_' . $atts['border'];
	}
	return $class;
}

function aiko_bt_bb_row_inner_style( $style_attr, $atts ) {
	if ( isset( $atts['background_image'] ) && $atts['background_image'] != '' ) {
		$background_image = wp_get_attachment_image_src( $atts['background_image'], 'full' );
		$background_image_url = $background_image[0];
		$background_image_style = 'background-image:url("' . $background_image_url . '");';
		$style_attr .= $background_image_style;
	}
	return $style_attr;
}

add_filter( 'bt_bb_row_class', 'aiko_bt_bb_row_class', 10, 2 );
add_filter( 'bt_bb_row_inner_style', 'aiko_bt_bb_row_inner_style', 10, 2 );



// INNER ROW - NEGATIVE MARGIN, BACKGROUND IMAGE, BACKGROUND COLOR, SHAPE, BORDER

if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_row_inner', array(
		array( 'param_name' => 'background_image', 'type' => 'attach_image',  'preview' => true, 'heading' => esc_html__( 'Background image', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ) ),
		array( 'param_name' => 'background_color', 'preview' => true, 'type' => 'colorpicker', 'group' => esc_html__( 'Design', 'aiko' ), 'heading' => esc_html__( 'Background color', 'aiko' ) ),
		array( 'param_name' => 'negative_margin', 'type' => 'dropdown', 'default' => '', 'heading' => esc_html__( 'Negative margin', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No margin', 'aiko' ) 		=> 'none',
				esc_html__( 'Extra small', 'aiko' ) 		=> 'extra_small',
				esc_html__( 'Small', 'aiko' ) 			=> 'small',
				esc_html__( 'Normal', 'aiko' ) 			=> 'normal',
				esc_html__( 'Medium', 'aiko' ) 			=> 'medium',
				esc_html__( 'Large', 'aiko' ) 			=> 'large',
				esc_html__( 'Extra large', 'aiko' ) 		=> 'extra_large',
				esc_html__( 'Huge', 'aiko' ) 			=> 'huge',
				esc_html__( '5px', 'aiko' ) 				=> '5px',
				esc_html__( '10px', 'aiko' ) 			=> '10px',
				esc_html__( '15px', 'aiko' ) 			=> '15px',
				esc_html__( '20px', 'aiko' ) 			=> '20px',
				esc_html__( '25px', 'aiko' ) 			=> '25px',
				esc_html__( '30px', 'aiko' ) 			=> '30px',
				esc_html__( '35px', 'aiko' ) 			=> '35px',
				esc_html__( '40px', 'aiko' ) 			=> '40px',
				esc_html__( '45px', 'aiko' ) 			=> '45px',
				esc_html__( '50px', 'aiko' ) 			=> '50px',
				esc_html__( '55px', 'aiko' ) 			=> '55px',
				esc_html__( '60px', 'aiko' ) 			=> '60px',
				esc_html__( '65px', 'aiko' ) 			=> '65px',
				esc_html__( '70px', 'aiko' ) 			=> '70px',
				esc_html__( '75px', 'aiko' ) 			=> '75px',
				esc_html__( '80px', 'aiko' ) 			=> '80px',
				esc_html__( '85px', 'aiko' ) 			=> '85px',
				esc_html__( '90px', 'aiko' ) 			=> '90px',
				esc_html__( '95px', 'aiko' ) 			=> '95px',
				esc_html__( '100px', 'aiko' ) 			=> '100px',
				esc_html__( '105px', 'aiko' ) 			=> '105px',
				esc_html__( '110px', 'aiko' ) 			=> '110px',
				esc_html__( '115px', 'aiko' ) 			=> '115px',
				esc_html__( '120px', 'aiko' ) 			=> '120px'
			)
		),
		array( 'param_name' => 'shape', 'type' => 'dropdown', 'preview' => true, 'heading' => esc_html__( 'Shape', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
			'value' => array(
				esc_html__( 'Square', 'aiko' ) 			=> '',
				esc_html__( 'Soft Rounded', 'aiko' ) 	=> 'soft-rounded',
				esc_html__( 'Hard Rounded', 'aiko' ) 	=> 'hard-rounded'
			)
		),
		array( 'param_name' => 'blur', 'type' => 'dropdown', 'heading' => esc_html__( 'Blur', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
			'value' => array(
				esc_html__( 'No', 'aiko' ) 				=> '',
				esc_html__( 'Yes', 'aiko' ) 				=> 'show'
			)
		),
		array( 'param_name' => 'border', 'type' => 'dropdown', 'heading' => esc_html__( 'Border', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
			'value' => array(
				esc_html__( 'No', 'aiko' ) 						=> '',
				esc_html__( 'Light border', 'aiko' ) 			=> 'light'
			)
		),
	));
}

add_filter( 'bt_bb_row_inner_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'negative_margin';
	return $params;
});


function aiko_bt_bb_row_inner_class( $class, $atts ) {
	// $class[] = 'FROM_AFTER_FRAMEWORK';
	if ( isset( $atts['background_image'] ) && $atts['background_image'] != '' ) {
		$class[] = 'bt_bb_row_inner_with_bg_image';
	}
	if ( isset( $atts['shape'] ) && $atts['shape'] != '' ) {
		$class[] = 'bt_bb_shape' . '_' . $atts['shape'];
	}
	if ( isset( $atts['blur'] ) && $atts['blur'] != '' ) {
		$class[] = 'bt_bb_blur' . '_' . $atts['blur'];
	}
	if ( isset( $atts['border'] ) && $atts['border'] != '' ) {
		$class[] = 'bt_bb_border' . '_' . $atts['border'];
	}
	return $class;
}

function aiko_bt_bb_row_inner_inner_style( $style_attr, $atts ) {
	if ( isset( $atts['background_image'] ) && $atts['background_image'] != '' ) {
		$background_image = wp_get_attachment_image_src( $atts['background_image'], 'full' );
		$background_image_url = $background_image[0];
		$background_image_style = 'background-image:url("' . $background_image_url . '");';
		$style_attr .= $background_image_style;
	}
	if ( isset( $atts['background_color'] ) && $atts['background_color'] != '' ) {
		$style_attr = $style_attr . 'background-color:' . $atts['background_color'] . ';';
	}
	return $style_attr;
}

add_filter( 'bt_bb_row_inner_class', 'aiko_bt_bb_row_inner_class', 10, 2 );
add_filter( 'bt_bb_row_inner_inner_style', 'aiko_bt_bb_row_inner_inner_style', 10, 2 );


// COLUMN - BORDER
if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_column', array(
		array( 'param_name' => 'border_position', 'type' => 'dropdown',  'preview' => true,  'heading' => esc_html__( 'Border position', 'aiko' ), 'group' => esc_html__( 'Border', 'aiko' ),
			'value' => array(
				esc_html__( 'Outer', 'aiko' ) 			=> '',
				esc_html__( 'Inner', 'aiko' ) 			=> 'inner'
			)
		),
		array( 'param_name' => 'border_top', 'type' => 'dropdown', 'heading' => esc_html__( 'Top border', 'aiko' ), 'default' => '', 'group' => esc_html__( 'Border', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No', 'aiko' ) 	=> 'none',
				esc_html__( 'Yes', 'aiko' ) 	=> 'yes'
			)
		),
		array( 'param_name' => 'border_bottom', 'type' => 'dropdown', 'heading' => esc_html__( 'Bottom border', 'aiko' ), 'default' => '', 'group' => esc_html__( 'Border', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No', 'aiko' ) 	=> 'none',
				esc_html__( 'Yes', 'aiko' ) 	=> 'yes'
			)
		),
		array( 'param_name' => 'border_right', 'type' => 'dropdown', 'heading' => esc_html__( 'Right border', 'aiko' ), 'default' => '', 'group' => esc_html__( 'Border', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No', 'aiko' ) 	=> 'none',
				esc_html__( 'Yes', 'aiko' ) 	=> 'yes'
			)
		),
		array( 'param_name' => 'border_left', 'type' => 'dropdown', 'heading' => esc_html__( 'Left border', 'aiko' ), 'default' => '', 'group' => esc_html__( 'Border', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No', 'aiko' ) 	=> 'none',
				esc_html__( 'Yes', 'aiko' ) 	=> 'yes'
			)
		),
		array( 'param_name' => 'border_color', 'type' => 'dropdown', 'heading' => esc_html__( 'Border color', 'aiko' ), 'group' => esc_html__( 'Border', 'aiko' ),
			'value' => array(
				esc_html__( 'Gray color', 'aiko' ) 			=> '',
				esc_html__( 'Accent color', 'aiko' ) 		=> 'accent',
				esc_html__( 'Alternate color', 'aiko' ) 		=> 'alternate',
				esc_html__( 'Light color', 'aiko' ) 			=> 'light',
				esc_html__( 'Lighter color', 'aiko' ) 		=> 'lighter',
				esc_html__( 'Dark color', 'aiko' ) 			=> 'dark'
			)
		),
		array( 'param_name' => 'border_thickness', 'type' => 'dropdown', 'heading' => esc_html__( 'Border tickness', 'aiko' ), 'group' => esc_html__( 'Border', 'aiko' ), 
			'value' => array(
				esc_html__( '1px', 'aiko' ) 	=> '1px',
				esc_html__( '2px', 'aiko' ) 	=> '2px',
				esc_html__( '3px', 'aiko' ) 	=> '3px',
				esc_html__( '4px', 'aiko' ) 	=> '4px',
				esc_html__( '5px', 'aiko' ) 	=> '5px'
			)
		),
	));
}

add_filter( 'bt_bb_column_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'border_top';
	return $params;
});
add_filter( 'bt_bb_column_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'border_bottom';
	return $params;
});

add_filter( 'bt_bb_column_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'border_right';
	return $params;
});
add_filter( 'bt_bb_column_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'border_left';
	return $params;
});

function aiko_bt_bb_column_class( $class, $atts ) {
	if ( isset( $atts['border_position'] ) && $atts['border_position'] != '' ) {
		$class[] = 'bt_bb_border_position' . '_' . $atts['border_position'];
	}
	if ( isset( $atts['border_thickness'] ) && $atts['border_thickness'] != '' ) {
		$class[] = 'bt_bb_border_thickness' . '_' . $atts['border_thickness'];
	}
	if ( isset( $atts['border_color'] ) && $atts['border_color'] != '' ) {
		$class[] = 'bt_bb_border_color' . '_' . $atts['border_color'];
	}
	return $class;
}

add_filter( 'bt_bb_column_class', 'aiko_bt_bb_column_class', 10, 2 );



// COLUMN INNER - BORDER
if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_column_inner', array(
		array( 'param_name' => 'border_position', 'type' => 'dropdown',  'preview' => true,  'heading' => esc_html__( 'Border position', 'aiko' ), 'group' => esc_html__( 'Border', 'aiko' ),
			'value' => array(
				esc_html__( 'Outer', 'aiko' ) 			=> '',
				esc_html__( 'Inner', 'aiko' ) 			=> 'inner'
			)
		),
		array( 'param_name' => 'border_top', 'type' => 'dropdown', 'heading' => esc_html__( 'Top border', 'aiko' ), 'default' => '', 'group' => esc_html__( 'Border', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No', 'aiko' ) 	=> 'none',
				esc_html__( 'Yes', 'aiko' ) 	=> 'yes'
			)
		),
		array( 'param_name' => 'border_bottom', 'type' => 'dropdown', 'heading' => esc_html__( 'Bottom border', 'aiko' ), 'default' => '', 'group' => esc_html__( 'Border', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No', 'aiko' ) 	=> 'none',
				esc_html__( 'Yes', 'aiko' ) 	=> 'yes'
			)
		),
		array( 'param_name' => 'border_right', 'type' => 'dropdown', 'heading' => esc_html__( 'Right border', 'aiko' ), 'default' => '', 'group' => esc_html__( 'Border', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No', 'aiko' ) 	=> 'none',
				esc_html__( 'Yes', 'aiko' ) 	=> 'yes'
			)
		),
		array( 'param_name' => 'border_left', 'type' => 'dropdown', 'heading' => esc_html__( 'Left border', 'aiko' ), 'default' => '', 'group' => esc_html__( 'Border', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No', 'aiko' ) 	=> 'none',
				esc_html__( 'Yes', 'aiko' ) 	=> 'yes'
			)
		),
		array( 'param_name' => 'border_color', 'type' => 'dropdown', 'heading' => esc_html__( 'Border color', 'aiko' ), 'group' => esc_html__( 'Border', 'aiko' ),
			'value' => array(
				esc_html__( 'Gray color', 'aiko' ) 			=> '',
				esc_html__( 'Accent color', 'aiko' ) 		=> 'accent',
				esc_html__( 'Alternate color', 'aiko' ) 		=> 'alternate',
				esc_html__( 'Light color', 'aiko' ) 			=> 'light',
				esc_html__( 'Lighter color', 'aiko' ) 		=> 'lighter',
				esc_html__( 'Dark color', 'aiko' ) 			=> 'dark'
			)
		),
		array( 'param_name' => 'border_thickness', 'type' => 'dropdown', 'heading' => esc_html__( 'Border tickness', 'aiko' ), 'group' => esc_html__( 'Border', 'aiko' ), 
			'value' => array(
				esc_html__( '1px', 'aiko' ) 	=> '1px',
				esc_html__( '2px', 'aiko' ) 	=> '2px',
				esc_html__( '3px', 'aiko' ) 	=> '3px',
				esc_html__( '4px', 'aiko' ) 	=> '4px',
				esc_html__( '5px', 'aiko' ) 	=> '5px'
			)
		),
	));
}


add_filter( 'bt_bb_column_inner_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'border_top';
	return $params;
});
add_filter( 'bt_bb_column_inner_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'border_bottom';
	return $params;
});

add_filter( 'bt_bb_column_inner_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'border_right';
	return $params;
});
add_filter( 'bt_bb_column_inner_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'border_left';
	return $params;
});

function aiko_bt_bb_column_inner_class( $class, $atts ) {
	if ( isset( $atts['border_position'] ) && $atts['border_position'] != '' ) {
		$class[] = 'bt_bb_border_position' . '_' . $atts['border_position'];
	}
	if ( isset( $atts['border_thickness'] ) && $atts['border_thickness'] != '' ) {
		$class[] = 'bt_bb_border_thickness' . '_' . $atts['border_thickness'];
	}
	if ( isset( $atts['border_color'] ) && $atts['border_color'] != '' ) {
		$class[] = 'bt_bb_border_color' . '_' . $atts['border_color'];
	}
	return $class;
}

add_filter( 'bt_bb_column_inner_class', 'aiko_bt_bb_column_inner_class', 10, 2 );



// HEADLINE - SUPERTITLE & HEADING LETTER SPACING, DASH, DASH COLOR, STYLE
if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_headline', array(
		array( 'param_name' => 'style', 'type' => 'dropdown', 'heading' => esc_html__( 'Headline style', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
			'value' => array(
				esc_html__( 'Solid color', 'aiko' ) 				=> '',
				esc_html__( 'Gradient color', 'aiko' ) 			=> 'gradient'
			)
		),
		array( 'param_name' => 'heading_letter_spacing', 'type' => 'dropdown', 'default' => '', 'heading' => esc_html__( 'Heading letter spacing', 'aiko' ), 'group' => esc_html__( 'Font', 'aiko' ),
			'value' => array(
				esc_html__( 'Default', 'aiko' ) 				=> '',
				esc_html__( '-3px', 'aiko' ) 				=> '-3px',
				esc_html__( '-2px', 'aiko' ) 				=> '-2px',
				esc_html__( '-1px', 'aiko' ) 				=> '-1px',
				esc_html__( '0px', 'aiko' ) 					=> '0px',
				esc_html__( '1px', 'aiko' ) 					=> '1px',
				esc_html__( '2px', 'aiko' ) 					=> '2px',
				esc_html__( '3px', 'aiko' ) 					=> '3px',
				esc_html__( '4px', 'aiko' ) 					=> '4px',
				esc_html__( '5px', 'aiko' ) 					=> '5px'
			)
		),
		array( 'param_name' => 'supertitle_letter_spacing', 'type' => 'dropdown', 'default' => '', 'heading' => esc_html__( 'Supertitle letter spacing', 'aiko' ), 'group' => esc_html__( 'Font', 'aiko' ),
			'value' => array(
				esc_html__( 'Default', 'aiko' ) 				=> '',
				esc_html__( '0px', 'aiko' ) 					=> '0px',
				esc_html__( '1px', 'aiko' ) 					=> '1px',
				esc_html__( '2px', 'aiko' ) 					=> '2px',
				esc_html__( '3px', 'aiko' ) 					=> '3px',
				esc_html__( '4px', 'aiko' ) 					=> '4px',
				esc_html__( '5px', 'aiko' ) 					=> '5px'
			)
		),
	));
}

function aiko_bt_bb_headline_class( $class, $atts ) {
	if ( isset( $atts['style'] ) && $atts['style'] != '' ) {
		$class[] = 'bt_bb_style' . '_' . $atts['style'];
	}
	if ( isset( $atts['heading_letter_spacing'] ) && $atts['heading_letter_spacing'] != '' ) {
		$class[] = 'bt_bb_heading_letter_spacing' . '_' . $atts['heading_letter_spacing'];
	}
	if ( isset( $atts['supertitle_letter_spacing'] ) && $atts['supertitle_letter_spacing'] != '' ) {
		$class[] = 'bt_bb_supertitle_letter_spacing' . '_' . $atts['supertitle_letter_spacing'];
	}
	if ( isset( $atts['headline'] ) && $atts['headline'] == '' ) {
		$class[] = 'btNoHeadline';
	}
	return $class;
}

add_filter( 'bt_bb_headline_class', 'aiko_bt_bb_headline_class', 10, 2 );


// BUTTON -  STYLE, ICON ANIMATION, ICON COLOR SCHEME
if ( function_exists( 'bt_bb_remove_params' ) ) {
	bt_bb_remove_params( 'bt_bb_button', 'style' );
}

if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_button', array(
		array( 'param_name' => 'style', 'type' => 'dropdown', 'heading' => esc_html__( 'Style', 'aiko' ), 'preview' => true, 'group' => esc_html__( 'Design', 'aiko' ),
			'value' => array(
				esc_html__( 'Outline', 'aiko' ) 					=> 'outline',
				esc_html__( 'Filled', 'aiko' ) 					=> 'filled',
				esc_html__( 'Filled (gradient)', 'aiko' ) 		=> 'filled_gradient',
				esc_html__( 'Filled (blur)', 'aiko' ) 			=> 'filled_blur',
				esc_html__( 'Underline', 'aiko' ) 				=> 'underline',
				esc_html__( 'Clean', 'aiko' ) 					=> 'clean'
			)
		),
		array( 'param_name' => 'icon_animation', 'type' => 'dropdown', 'heading' => esc_html__( 'Icon animation', 'aiko' ), 'description' => esc_html__( 'Select icon animation, visible on Button hover', 'aiko' ), 'default' => '', 'group' => esc_html__( 'Design', 'aiko' ),
			'value' => array(
				esc_html__( 'None', 'aiko' ) 					=> '',
				esc_html__( 'Shake', 'aiko' ) 					=> 'shake',
				esc_html__( 'Rotate', 'aiko' ) 					=> 'rotate',
				esc_html__( 'Move to right', 'aiko' ) 			=> 'move_right',
				esc_html__( 'Move to left', 'aiko' ) 			=> 'move_left',
				esc_html__( 'Move to top', 'aiko' ) 				=> 'move_top',
				esc_html__( 'Move to bottom', 'aiko' ) 			=> 'move_bottom'
			)
		),
		array( 'param_name' => 'icon_color_scheme', 'type' => 'dropdown', 'heading' => esc_html__( 'Icon color scheme', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ), 'value' => $color_scheme_arr ),
	));
}

function aiko_bt_bb_button_class( $class, $atts ) {
	if ( $atts['icon'] != '' ) {
		$class[] = 'btWithIcon';
	}
	if ( isset( $atts['icon_animation'] ) && $atts['icon_animation'] != '' ) {
		$class[] = 'bt_bb_icon_animation' . '_' . $atts['icon_animation'];
	}
	if ( isset( $atts['icon_color_scheme'] ) && $atts['icon_color_scheme'] != '' ) {
		$class[] = 'bt_bb_icon_color_scheme' . '_' . $atts['icon_color_scheme'];
	}
	return $class;
}

function aiko_bt_bb_button_style( $style, $atts ) {
	if ( isset( $atts['icon_color_scheme'] ) && $atts['icon_color_scheme'] != '' ) {
	
		$icon_color_scheme_id = NULL;
		if ( is_numeric ( $atts['icon_color_scheme'] ) ) {
			$icon_color_scheme_id = $atts['icon_color_scheme'];
		} else if ( $atts['icon_color_scheme'] != '' ) {
			$icon_color_scheme_id = bt_bb_get_color_scheme_id( $atts['icon_color_scheme'] );
		}
		$icon_color_scheme_colors = bt_bb_get_color_scheme_colors_by_id( $icon_color_scheme_id - 1 );
		if ( $icon_color_scheme_colors ) $style .= '; --icon-primary-color:' . $icon_color_scheme_colors[0] . '; --icon-secondary-color:' . $icon_color_scheme_colors[1] . ';';
	}
	return $style;
}

add_filter( 'bt_bb_button_class', 'aiko_bt_bb_button_class', 10, 2 );
add_filter( 'bt_bb_button_style', 'aiko_bt_bb_button_style', 10, 2 );


// IMAGE - SHAPE, NEGATIVE MARGIN
if ( function_exists( 'bt_bb_remove_params' ) ) {
	bt_bb_remove_params( 'bt_bb_image', 'shape' );
}

if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_image', array(
		array( 'param_name' => 'shape', 'type' => 'dropdown', 'heading' => esc_html__( 'Shape', 'aiko' ),
			'value' => array(
				esc_html__( 'Square', 'aiko' ) 					=> 'square',
				esc_html__( 'Small Rounded', 'aiko' ) 			=> 'small-rounded',
				esc_html__( 'Soft Rounded', 'aiko' ) 			=> 'soft-rounded',
				esc_html__( 'Medium Rounded', 'aiko' ) 			=> 'medium-rounded',
				esc_html__( 'Hard Rounded', 'aiko' ) 			=> 'softer-rounded',
				esc_html__( 'Very Rounded', 'aiko' ) 			=> 'very-rounded',
				esc_html__( 'Circle', 'aiko' ) 					=> 'hard-rounded'
			)
		),
		array( 'param_name' => 'top_negative_margin', 'type' => 'dropdown', 'group' => esc_html__( 'Margin', 'aiko' ), 'heading' => esc_html__( 'Top negative margin', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No margin', 'aiko' ) 		=> 'none',
				esc_html__( 'Extra small', 'aiko' ) 		=> 'extra_small',
				esc_html__( 'Small', 'aiko' ) 			=> 'small',		
				esc_html__( 'Normal', 'aiko' ) 			=> 'normal',
				esc_html__( 'Medium', 'aiko' ) 			=> 'medium',
				esc_html__( 'Large', 'aiko' ) 			=> 'large',
				esc_html__( 'Extra large', 'aiko' ) 		=> 'extra_large'
			)
		),
		array( 'param_name' => 'bottom_negative_margin', 'type' => 'dropdown', 'group' => esc_html__( 'Margin', 'aiko' ), 'heading' => esc_html__( 'Bottom negative margin', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No margin', 'aiko' ) 		=> 'none',
				esc_html__( 'Extra small', 'aiko' ) 		=> 'extra_small',
				esc_html__( 'Small', 'aiko' ) 			=> 'small',
				esc_html__( 'Normal', 'aiko' ) 			=> 'normal',
				esc_html__( 'Medium', 'aiko' ) 			=> 'medium',
				esc_html__( 'Large', 'aiko' ) 			=> 'large',
				esc_html__( 'Extra large', 'aiko' ) 		=> 'extra_large'
			)
		),
		array( 'param_name' => 'right_negative_margin', 'type' => 'dropdown', 'group' => esc_html__( 'Margin', 'aiko' ), 'heading' => esc_html__( 'Right negative margin', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No margin', 'aiko' ) 		=> 'none',
				esc_html__( 'Extra small', 'aiko' ) 		=> 'extra_small',
				esc_html__( 'Small', 'aiko' ) 			=> 'small',
				esc_html__( 'Normal', 'aiko' ) 			=> 'normal',
				esc_html__( 'Medium', 'aiko' ) 			=> 'medium',
				esc_html__( 'Large', 'aiko' ) 			=> 'large',
				esc_html__( 'Extra large', 'aiko' ) 		=> 'extra_large'
			)
		),
		array( 'param_name' => 'left_negative_margin', 'type' => 'dropdown', 'group' => esc_html__( 'Margin', 'aiko' ), 'heading' => esc_html__( 'Left negative margin', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'No margin', 'aiko' ) 		=> 'none',
				esc_html__( 'Extra small', 'aiko' ) 		=> 'extra_small',
				esc_html__( 'Small', 'aiko' ) 			=> 'small',
				esc_html__( 'Normal', 'aiko' ) 			=> 'normal',
				esc_html__( 'Medium', 'aiko' ) 			=> 'medium',
				esc_html__( 'Large', 'aiko' ) 			=> 'large',
				esc_html__( 'Extra large', 'aiko' ) 		=> 'extra_large'
			)
		),
	));
}

add_filter( 'bt_bb_image_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'top_negative_margin';
	return $params;
});

add_filter( 'bt_bb_image_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'bottom_negative_margin';
	return $params;
});

add_filter( 'bt_bb_image_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'right_negative_margin';
	return $params;
});

add_filter( 'bt_bb_image_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'left_negative_margin';
	return $params;
});



// ICON - SIZE, STYLE, SHAPE, ALIGN CONTENT, TEXT SIZE, TEXT COLOR
if ( function_exists( 'bt_bb_remove_params' ) ) {
	bt_bb_remove_params( 'bt_bb_icon', 'size' );
	bt_bb_remove_params( 'bt_bb_icon', 'style' );
	bt_bb_remove_params( 'bt_bb_icon', 'shape' );
}

if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_icon', array(
		array( 'param_name' => 'size', 'type' => 'dropdown', 'default' => 'small', 'heading' => esc_html__( 'Size', 'aiko' ), 'preview' => true, 'group' => esc_html__( 'Design', 'aiko' ), 'responsive_override' => true,
			'value' => array(
				esc_html__( 'Extra small', 'aiko' ) 		=> 'xsmall',
				esc_html__( 'Small', 'aiko' ) 			=> 'small',
				esc_html__( 'Medium', 'aiko' ) 			=> 'medium',
				esc_html__( 'Normal', 'aiko' ) 			=> 'normal',
				esc_html__( 'Large', 'aiko' ) 			=> 'large',
				esc_html__( 'Extra large', 'aiko' ) 		=> 'xlarge',
				esc_html__( 'Huge', 'aiko' ) 			=> 'huge'
			)
		),
		array( 'param_name' => 'align_content', 'type' => 'dropdown', 'default' => '', 'heading' => esc_html__( 'Content alignment', 'aiko' ), 
			'value' => array(
				esc_html__( 'Center', 'aiko' ) 			=> '',
				esc_html__( 'Top', 'aiko' ) 				=> 'top',
				esc_html__( 'Bottom', 'aiko' ) 			=> 'bottom'
			)
		),
		array( 'param_name' => 'style', 'type' => 'dropdown', 'heading' => esc_html__( 'Style', 'aiko' ), 'preview' => true, 'group' => esc_html__( 'Design', 'aiko' ),
			'value' => array(
				esc_html__( 'Outline', 'aiko' ) 				=> 'outline',
				esc_html__( 'Filled', 'aiko' ) 				=> 'filled',
				esc_html__( 'Filled gradient', 'aiko' ) 		=> 'filled_gradient',
				esc_html__( 'Borderless', 'aiko' ) 			=> 'borderless',
				esc_html__( 'Borderless gradient', 'aiko' ) 	=> 'borderless_gradient',
				esc_html__( 'Blur', 'aiko' ) 				=> 'blur'
			)
		),
		array( 'param_name' => 'shape', 'type' => 'dropdown', 'heading' => esc_html__( 'Shape', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
			'value' => array(
				esc_html__( 'Circle', 'aiko' ) 				=> 'circle',
				esc_html__( 'Square', 'aiko' ) 				=> 'square',
				esc_html__( 'Soft rounded square', 'aiko' ) 	=> 'round',
				esc_html__( 'Hard rounded square', 'aiko' ) 	=> 'hard-round'
			)
		),
		array( 'param_name' => 'text_size', 'type' => 'dropdown', 'heading' => esc_html__( 'Text size', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
			'value' => array(
				esc_html__( 'Default', 'aiko' ) 				=> '',
				esc_html__( '12px', 'aiko' ) 				=> '12px',
				esc_html__( '13px', 'aiko' ) 				=> '13px',
				esc_html__( '14px', 'aiko' ) 				=> '14px',
				esc_html__( '15px', 'aiko' ) 				=> '15px',
				esc_html__( '16px', 'aiko' ) 				=> '16px',
				esc_html__( '17px', 'aiko' ) 				=> '17px',
				esc_html__( '18px', 'aiko' ) 				=> '18px',
				esc_html__( '19px', 'aiko' ) 				=> '19px'
			)
		),
		array( 'param_name' => 'text_color', 'type' => 'dropdown', 'heading' => esc_html__( 'Text color', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ), 
			'value' => array(
				esc_html__( 'Inherit', 'aiko' ) 			=> '',		
				esc_html__( 'Dark color', 'aiko' ) 		=> 'dark',
				esc_html__( 'Light color', 'aiko' ) 		=> 'light',
				esc_html__( 'Accent color', 'aiko' ) 	=> 'accent',
				esc_html__( 'Alternate color', 'aiko' ) 	=> 'alternate',
				esc_html__( 'Gray color', 'aiko' ) 		=> 'gray'
			)
		),
	));
}

function aiko_bt_bb_icon_class( $class, $atts ) {
	if ( isset( $atts['text_size'] ) && $atts['text_size'] != '' ) {
		$class[] = 'bt_bb_text_size' . '_' . $atts['text_size'];
	}
	if ( isset( $atts['text_color'] ) && $atts['text_color'] != '' ) {
		$class[] = 'bt_bb_text_color' . '_' . $atts['text_color'];
	}
	if ( isset( $atts['align_content'] ) && $atts['align_content'] != '' ) {
		$class[] = 'bt_bb_align_content' . '_' . $atts['align_content'];
	}
	return $class;
}

add_filter( 'bt_bb_icon_class', 'aiko_bt_bb_icon_class', 10, 2 );



// SEPARATOR - OPACITY
if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_separator', array(
		array( 'param_name' => 'opacity', 'type' => 'dropdown', 'heading' => esc_html__( 'Opacity', 'aiko' ), 
			'value' => array(
				esc_html__( '0.1', 'aiko' ) 					=> 'verysmall',
				esc_html__( '0.2', 'aiko' ) 					=> 'extra_small',
				esc_html__( '0.3', 'aiko' ) 					=> '',
				esc_html__( '0.4', 'aiko' ) 					=> 'normal',
				esc_html__( '0.5', 'aiko' ) 					=> 'medium',
				esc_html__( '0.6', 'aiko' ) 					=> 'large',
				esc_html__( '0.7', 'aiko' ) 					=> 'extra_large',
				esc_html__( '0.8', 'aiko' ) 					=> 'huge',
				esc_html__( '0.9', 'aiko' ) 					=> 'extra_huge',
				esc_html__( 'Full visibility', 'aiko' ) 		=> 'full'
			)
		),
	));
}

function aiko_bt_bb_separator_class( $class, $atts ) {
	if ( isset( $atts['opacity'] ) && $atts['opacity'] != '' ) {
		$class[] = 'bt_bb_opacity' . '_' . $atts['opacity'];
	}
	return $class;
}

add_filter( 'bt_bb_separator_class', 'aiko_bt_bb_separator_class', 10, 2 );



// TEXT - FONT SIZE, WEIGHT
if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_text', array(
		array( 'param_name' => 'font_size', 'type' => 'dropdown', 'preview' => true, 'heading' => esc_html__( 'Font size', 'aiko' ),
			'value' => array(
				esc_html__( 'Default', 'aiko' ) 				=> '',
				esc_html__( '12px', 'aiko' ) 				=> '12px',
				esc_html__( '13px', 'aiko' ) 				=> '13px',
				esc_html__( '14px', 'aiko' ) 				=> '14px',
				esc_html__( '15px', 'aiko' ) 				=> '15px',
				esc_html__( '16px', 'aiko' ) 				=> '16px',
				esc_html__( '17px', 'aiko' ) 				=> '17px',
				esc_html__( '18px', 'aiko' ) 				=> '18px',
				esc_html__( '19px', 'aiko' ) 				=> '19px'
			)
		),
		array( 'param_name' => 'font_weight', 'type' => 'dropdown', 'default' => '', 'preview' => true, 'heading' => esc_html__( 'Font weight', 'aiko' ), 
			'value' => array(
				esc_html__( 'Default', 'aiko' ) 		=> '',
				esc_html__( 'Normal', 'aiko' ) 		=> 'normal',
				esc_html__( 'Bold', 'aiko' ) 		=> 'bold',
				esc_html__( 'Bolder', 'aiko' ) 		=> 'bolder',
				esc_html__( 'Lighter', 'aiko' ) 		=> 'lighter',
				esc_html__( 'Light', 'aiko' ) 		=> 'light',
				esc_html__( 'Thin', 'aiko' ) 		=> 'thin',
				esc_html__( '100', 'aiko' ) 			=> '100',
				esc_html__( '200', 'aiko' ) 			=> '200',
				esc_html__( '300', 'aiko' ) 			=> '300',
				esc_html__( '400', 'aiko' ) 			=> '400',
				esc_html__( '500', 'aiko' ) 			=> '500',
				esc_html__( '600', 'aiko' ) 			=> '600',
				esc_html__( '700', 'aiko' ) 			=> '700',
				esc_html__( '800', 'aiko' ) 			=> '800',
				esc_html__( '900', 'aiko' ) 			=> '900'
			)
		),
	));
}

function aiko_bt_bb_text_class( $class, $atts ) {
	if ( isset( $atts['font_size'] ) && $atts['font_size'] != '' ) {
		$class[] = 'bt_bb_font_size' . '_' . $atts['font_size'];
	}
	if ( isset( $atts['font_weight'] ) && $atts['font_weight'] != '' ) {
		$class[] = 'bt_bb_font_weight' . '_' . $atts['font_weight'];
	}
	return $class;
}

add_filter( 'bt_bb_text_class', 'aiko_bt_bb_text_class', 10, 2 );




// CUSTOM MENU - FONT SIZE, COLOR SCHEME, STYLE
if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_custom_menu', array(
		array( 'param_name' => 'font_size', 'type' => 'dropdown', 'default' => '', 'heading' => esc_html__( 'Font size', 'aiko' ),
			'value' => array(
				esc_html__( 'Default', 'aiko' ) 				=> '',
				esc_html__( '12px', 'aiko' ) 				=> '12px',
				esc_html__( '13px', 'aiko' ) 				=> '13px',
				esc_html__( '14px', 'aiko' ) 				=> '14px',
				esc_html__( '15px', 'aiko' ) 				=> '15px',
				esc_html__( '16px', 'aiko' ) 				=> '16px',
				esc_html__( '17px', 'aiko' ) 				=> '17px'
			)
		),
		array( 'param_name' => 'color_scheme', 'type' => 'dropdown', 'heading' => esc_html__( 'Color scheme', 'aiko' ), 'value' => $color_scheme_arr ),
		array( 'param_name' => 'style', 'type' => 'dropdown', 'default' => '', 'heading' => esc_html__( 'Style', 'aiko' ),
			'value' => array(
				esc_html__( 'Simple', 'aiko' ) 				=> '',
				esc_html__( 'Underline', 'aiko' ) 			=> 'underline'
			)
		),
	));
}

function aiko_bt_bb_custom_menu_class( $class, $atts ) {
	if ( isset( $atts['font_size'] ) && $atts['font_size'] != '' ) {
		$class[] = 'bt_bb_font_size' . '_' . $atts['font_size'];
	}
	if ( isset( $atts['style'] ) && $atts['style'] != '' ) {
		$class[] = 'bt_bb_style' . '_' . $atts['style'];
	}
	if ( isset( $atts['color_scheme'] ) && $atts['color_scheme'] != '' ) {
		$class[] = 'bt_bb_color_scheme' . '_' . bt_bb_get_color_scheme_id( $atts['color_scheme'] );
	}
	return $class;
}

function aiko_bt_bb_custom_menu_style( $style, $atts ) {
	if ( isset( $atts['color_scheme'] ) && $atts['color_scheme'] != '' ) {
	
		$color_scheme_id = NULL;
		if ( is_numeric ( $atts['color_scheme'] ) ) {
			$color_scheme_id = $atts['color_scheme'];
		} else if ( $atts['color_scheme'] != '' ) {
			$color_scheme_id = bt_bb_get_color_scheme_id( $atts['color_scheme'] );
		}
		$color_scheme_colors = bt_bb_get_color_scheme_colors_by_id( $color_scheme_id - 1 );
		if ( $color_scheme_colors ) $style .= '; --custom-menu-primary-color:' . $color_scheme_colors[0] . '; --custom-menu-secondary-color:' . $color_scheme_colors[1] . ';';
	}
	return $style;
}

add_filter( 'bt_bb_custom_menu_class', 'aiko_bt_bb_custom_menu_class', 10, 2 );
add_filter( 'bt_bb_custom_menu_style', 'aiko_bt_bb_custom_menu_style', 10, 2 );


// SLIDER - DOTS COLOR
if ( function_exists( 'bt_bb_remove_params' ) ) {
	bt_bb_remove_params( 'bt_bb_content_slider', 'show_dots' );
	bt_bb_remove_params( 'bt_bb_content_slider', 'arrows_size' );
}

if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_content_slider', array(
		array( 'param_name' => 'show_dots', 'type' => 'dropdown', 'heading' => esc_html__( 'Dots position', 'aiko' ), 'group' => esc_html__( 'Navigation', 'aiko' ),
			'value' => array(
				esc_html__( 'Bottom', 'aiko' ) 	=> 'bottom',
				esc_html__( 'Below', 'aiko' ) 	=> 'below',
				esc_html__( 'Hide', 'aiko' ) 	=> 'hide'
			)
		),
		array( 'param_name' => 'dots_alignment', 'type' => 'dropdown', 'heading' => esc_html__( 'Dots alignment', 'aiko' ), 'group' => esc_html__( 'Navigation', 'aiko' ),
			'value' => array(
				esc_html__( 'Center', 'aiko' ) 	=> '',
				esc_html__( 'Left', 'aiko' ) 	=> 'left',
				esc_html__( 'Right', 'aiko' ) 	=> 'right'
			)
		),
		array( 'param_name' => 'dots_color', 'type' => 'dropdown', 'heading' => esc_html__( 'Dots color', 'aiko' ), 'group' => esc_html__( 'Navigation', 'aiko' ),
			'value' => array(
				esc_html__( 'Dark color', 'aiko' ) 			=> '',
				esc_html__( 'Light color', 'aiko' ) 			=> 'light',
				esc_html__( 'Accent color', 'aiko' ) 		=> 'accent',
				esc_html__( 'Alternate color', 'aiko' ) 		=> 'alternate'
			)
		),
		array( 'param_name' => 'arrows_size', 'type' => 'dropdown', 'preview' => true, 'default' => 'normal', 'heading' => esc_html__( 'Arrows size', 'aiko' ), 'group' => esc_html__( 'Navigation', 'aiko' ),
			'value' => array(
				esc_html__( 'No arrows', 'aiko' ) 	=> 'no_arrows',
				esc_html__( 'Small', 'aiko' ) 		=> 'small',
				esc_html__( 'Normal', 'aiko' ) 		=> 'normal',
				esc_html__( 'Large', 'aiko' ) 		=> 'large'
			)
		),
		array( 'param_name' => 'arrows_position', 'type' => 'dropdown', 'responsive_override' => true, 'heading' => esc_html__( 'Arrows position', 'aiko' ), 'group' => esc_html__( 'Navigation', 'aiko' ), 
			'value' => array(
				esc_html__( 'On side', 'aiko' ) 									=> 'on_side',
				esc_html__( 'On side, visible on hover', 'aiko' ) 				=> 'hover',
				esc_html__( 'Outside the slider', 'aiko' ) 						=> 'outside',
				esc_html__( 'Outside the slider, visible on hover', 'aiko' ) 	=> 'outside_hover',
				esc_html__( 'Below center', 'aiko' ) 							=> 'below_center',
				esc_html__( 'Below left', 'aiko' ) 								=> 'below_left',
				esc_html__( 'Below right', 'aiko' ) 								=> 'below_right'
			)
		),
		array( 'param_name' => 'arrows_color_scheme', 'preview' => true, 'type' => 'dropdown', 'heading' => esc_html__( 'Arrows color scheme', 'aiko' ), 'group' => esc_html__( 'Navigation', 'aiko' ), 'value' => $color_scheme_arr ),
	));
}

add_filter( 'bt_bb_content_slider_extra_responsive_data_override_param', function( $params ) { 
	$params[] = 'arrows_position';
	return $params;
});

function aiko_bt_bb_content_slider_class( $class, $atts ) {
	if ( isset( $atts['dots_color'] ) && $atts['dots_color'] != '' ) {
		$class[] = 'bt_bb_dots_color' . '_' . $atts['dots_color'];
	}
	if ( isset( $atts['dots_alignment'] ) && $atts['dots_alignment'] != '' ) {
		$class[] = 'bt_bb_dots_alignment' . '_' . $atts['dots_alignment'];
	}
	return $class;
}

function aiko_bt_bb_content_slider_style( $style, $atts ) {
	if ( isset( $atts['arrows_color_scheme'] ) && $atts['arrows_color_scheme'] != '' ) {
		$arrows_color_scheme_id = NULL;
		if ( is_numeric ( $atts['arrows_color_scheme'] ) ) {
			$arrows_color_scheme_id = $atts['arrows_color_scheme'];
		} else if ( $atts['arrows_color_scheme'] != '' ) {
			$arrows_color_scheme_id = bt_bb_get_color_scheme_id( $atts['arrows_color_scheme'] );
		}
		$arrows_color_scheme_colors = bt_bb_get_color_scheme_colors_by_id( $arrows_color_scheme_id - 1 );
		if ( $arrows_color_scheme_colors ) $style .= '; --arrows-primary-color:' . $arrows_color_scheme_colors[0] . '; --arrows-secondary-color:' . $arrows_color_scheme_colors[1] . ';';
	}
	return $style;
}

add_filter( 'bt_bb_content_slider_class', 'aiko_bt_bb_content_slider_class', 10, 2 );
add_filter( 'bt_bb_content_slider_style', 'aiko_bt_bb_content_slider_style', 10, 2 );


// CONTACT FORM 7 - BUTTON COLOR SCHEME AND STYLE, INPUT STYLE, PLACEHOLDER STYLE
if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_contact_form_7', array(
		array( 'param_name' => 'input_size', 'type' => 'dropdown', 'heading' => esc_html__( 'Input size', 'aiko' ), 'group' => esc_html__( 'Input', 'aiko' ),
			'value' => array(
				esc_html__( 'Small', 'aiko' ) 					=> '',
				esc_html__( 'Normal', 'aiko' ) 					=> 'normal',
				esc_html__( 'Large', 'aiko' ) 					=> 'large'
			)
		),
		array( 'param_name' => 'input_style', 'type' => 'dropdown', 'heading' => esc_html__( 'Input style', 'aiko' ), 'group' => esc_html__( 'Input', 'aiko' ), 
			'value' => array(
				esc_html__( 'Outline', 'aiko' ) 					=> '',
				esc_html__( 'Filled', 'aiko' ) 					=> 'filled'
			)
		),
		array( 'param_name' => 'shape', 'type' => 'dropdown', 'heading' => esc_html__( 'Input shape', 'aiko' ), 'group' => esc_html__( 'Input', 'aiko' ),
			'value' => array(
				esc_html__( 'Inherit', 'aiko' ) 			=> '',
				esc_html__( 'Square', 'aiko' ) 			=> 'square',
				esc_html__( 'Soft Rounded', 'aiko' ) 	=> 'soft_rounded',
				esc_html__( 'Hard Rounded', 'aiko' ) 	=> 'hard_rounded'
			)
		),
		array( 'param_name' => 'input_color_scheme', 'preview' => true, 'type' => 'dropdown', 'heading' => esc_html__( 'Input color scheme', 'aiko' ), 'group' => esc_html__( 'Input', 'aiko' ), 'value' => $color_scheme_arr ),
		array( 'param_name' => 'placeholder_style', 'type' => 'dropdown',  'default' => 'extra_small', 'heading' => esc_html__( 'Placeholder style', 'aiko' ), 'group' => esc_html__( 'Input', 'aiko' ),
			'value' => array(
				esc_html__( 'Full visibility', 'aiko' ) 		=> 'full',
				esc_html__( '0.1', 'aiko' ) 					=> 'very_small',
				esc_html__( '0.2', 'aiko' ) 					=> 'extra_small',
				esc_html__( '0.3', 'aiko' ) 					=> 'small',
				esc_html__( '0.4', 'aiko' ) 					=> 'normal',
				esc_html__( '0.5', 'aiko' ) 					=> 'large',
				esc_html__( '0.6', 'aiko' ) 					=> 'extra_large',
				esc_html__( '0.7', 'aiko' ) 					=> 'huge',
				esc_html__( '0.8', 'aiko' ) 					=> 'very_huge',
				esc_html__( '0.9', 'aiko' ) 					=> 'extra_huge'
			)
		),

		array( 'param_name' => 'button_size', 'type' => 'dropdown', 'heading' => esc_html__( 'Button size', 'aiko' ), 'group' => esc_html__( 'Button', 'aiko' ),
			'value' => array(
				esc_html__( 'Small', 'aiko' ) 					=> '',
				esc_html__( 'Normal', 'aiko' ) 					=> 'normal',
				esc_html__( 'Large', 'aiko' ) 					=> 'large'
			)
		),
		array( 'param_name' => 'button_style', 'type' => 'dropdown', 'heading' => esc_html__( 'Button style', 'aiko' ), 'group' => esc_html__( 'Button', 'aiko' ), 
			'value' => array(
				esc_html__( 'Filled (gradient)', 'aiko' ) 		=> '',
				esc_html__( 'Filled', 'aiko' ) 					=> 'filled',
				esc_html__( 'Outline', 'aiko' ) 					=> 'outline',
				esc_html__( 'Clean', 'aiko' ) 					=> 'clean'
			)
		),
		array( 'param_name' => 'button_shape', 'type' => 'dropdown', 'heading' => esc_html__( 'Button shape', 'aiko' ), 'group' => esc_html__( 'Button', 'aiko' ),
			'value' => array(
				esc_html__( 'Inherit', 'aiko' ) 			=> '',
				esc_html__( 'Square', 'aiko' ) 			=> 'square',
				esc_html__( 'Soft Rounded', 'aiko' ) 	=> 'soft_rounded',
				esc_html__( 'Softer Rounded', 'aiko' ) 	=> 'softer_rounded',
				esc_html__( 'Hard Rounded', 'aiko' ) 	=> 'hard_rounded'
			)
		),
		array( 'param_name' => 'button_width', 'type' => 'dropdown', 'heading' => esc_html__( 'Button width', 'aiko' ), 'group' => esc_html__( 'Button', 'aiko' ),
			'value' => array(
				esc_html__( 'Inline', 'aiko' ) 			=> '',
				esc_html__( 'Full width', 'aiko' ) 		=> 'full'
			)
		),
		array( 'param_name' => 'color_scheme', 'preview' => true, 'type' => 'dropdown', 'heading' => esc_html__( 'Button color scheme', 'aiko' ), 'group' => esc_html__( 'Button', 'aiko' ), 'value' => $color_scheme_arr ),
		array( 'param_name' => 'button_font_weight', 'type' => 'dropdown', 'heading' => esc_html__( 'Button font weight', 'aiko' ), 'group' => esc_html__( 'Button', 'aiko' ),
			'value' => array(
				esc_html__( 'Default', 'aiko' ) 		=> '',
				esc_html__( 'Normal', 'aiko' ) 		=> 'normal',
				esc_html__( 'Bold', 'aiko' ) 		=> 'bold',
				esc_html__( 'Bolder', 'aiko' ) 		=> 'bolder',
				esc_html__( 'Lighter', 'aiko' ) 		=> 'lighter',
				esc_html__( 'Light', 'aiko' ) 		=> 'light',
				esc_html__( 'Thin', 'aiko' ) 		=> 'thin',
				esc_html__( '100', 'aiko' ) 			=> '100',
				esc_html__( '200', 'aiko' ) 			=> '200',
				esc_html__( '300', 'aiko' ) 			=> '300',
				esc_html__( '400', 'aiko' ) 			=> '400',
				esc_html__( '500', 'aiko' ) 			=> '500',
				esc_html__( '600', 'aiko' ) 			=> '600',
				esc_html__( '700', 'aiko' ) 			=> '700',
				esc_html__( '800', 'aiko' ) 			=> '800',
				esc_html__( '900', 'aiko' ) 			=> '900'
			)
		),
	));
}

function aiko_bt_bb_contact_form_7_class( $class, $atts ) {
	if ( isset( $atts['input_size'] ) && $atts['input_size'] != '' ) {
		$class[] = 'bt_bb_input_size' . '_' . $atts['input_size'];
	}
	if ( isset( $atts['input_style'] ) && $atts['input_style'] != '' ) {
		$class[] = 'bt_bb_input_style' . '_' . $atts['input_style'];
	}
	if ( isset( $atts['shape'] ) && $atts['shape'] != '' ) {
		$class[] = 'bt_bb_shape' . '_' . $atts['shape'];
	}
	if ( isset( $atts['input_color_scheme'] ) && $atts['input_color_scheme'] != '' ) {
		$class[] = 'bt_bb_input_color_scheme' . '_' . bt_bb_get_color_scheme_id( $atts['input_color_scheme'] );
	}
	if ( isset( $atts['placeholder_style'] ) && $atts['placeholder_style'] != '' ) {
		$class[] = 'bt_bb_placeholder_style' . '_' . $atts['placeholder_style'];
	}
	if ( isset( $atts['button_size'] ) && $atts['button_size'] != '' ) {
		$class[] = 'bt_bb_button_size' . '_' . $atts['button_size'];
	}
	if ( isset( $atts['button_width'] ) && $atts['button_width'] != '' ) {
		$class[] = 'bt_bb_button_width' . '_' . $atts['button_width'];
	}
	if ( isset( $atts['button_shape'] ) && $atts['button_shape'] != '' ) {
		$class[] = 'bt_bb_button_shape' . '_' . $atts['button_shape'];
	}
	if ( isset( $atts['button_style'] ) && $atts['button_style'] != '' ) {
		$class[] = 'bt_bb_button_style' . '_' . $atts['button_style'];
	}
	if ( isset( $atts['color_scheme'] ) && $atts['color_scheme'] != '' ) {
		$class[] = 'bt_bb_color_scheme' . '_' . bt_bb_get_color_scheme_id( $atts['color_scheme'] );
	}
	if ( isset( $atts['button_font_weight'] ) && $atts['button_font_weight'] != '' ) {
		$class[] = 'bt_bb_button_font_weight' . '_' . $atts['button_font_weight'];
	}
	return $class;
}

function aiko_bt_bb_contact_form_7_style( $style, $atts ) {
	if ( isset( $atts['color_scheme'] ) && $atts['color_scheme'] != '' ) {
	
		$color_scheme_id = NULL;
		if ( is_numeric ( $atts['color_scheme'] ) ) {
			$color_scheme_id = $atts['color_scheme'];
		} else if ( $atts['color_scheme'] != '' ) {
			$color_scheme_id = bt_bb_get_color_scheme_id( $atts['color_scheme'] );
		}
		$color_scheme_colors = bt_bb_get_color_scheme_colors_by_id( $color_scheme_id - 1 );
		if ( $color_scheme_colors ) $style .= '; --primary-color:' . $color_scheme_colors[0] . '; --secondary-color:' . $color_scheme_colors[1] . ';';
	}

	if ( isset( $atts['input_color_scheme'] ) && $atts['input_color_scheme'] != '' ) {
	
		$input_color_scheme_id = NULL;
		if ( is_numeric ( $atts['input_color_scheme'] ) ) {
			$input_color_scheme_id = $atts['input_color_scheme'];
		} else if ( $atts['input_color_scheme'] != '' ) {
			$input_color_scheme_id = bt_bb_get_color_scheme_id( $atts['input_color_scheme'] );
		}
		$input_color_scheme_colors = bt_bb_get_color_scheme_colors_by_id( $input_color_scheme_id - 1 );
		if ( $input_color_scheme_colors ) $style .= '; --input-primary-color:' . $input_color_scheme_colors[0] . '; --input-secondary-color:' . $input_color_scheme_colors[1] . ';';
	}
	return $style;
}

add_filter( 'bt_bb_contact_form_7_class', 'aiko_bt_bb_contact_form_7_class', 10, 2 );
add_filter( 'bt_bb_contact_form_7_style', 'aiko_bt_bb_contact_form_7_style', 10, 2 );



// ACCORDION - TRIGGER COLOR, TITLE SIZE, FONT WEIGHT
if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_accordion', array(
		array( 'param_name' => 'trigger_color', 'type' => 'dropdown', 'heading' => esc_html__( 'Trigger color', 'aiko' ), 'preview' => true,
			'value' => array(
				esc_html__( 'Inherit', 'aiko' )			=> '',
				esc_html__( 'Dark', 'aiko' )				=> 'dark',
				esc_html__( 'Light', 'aiko' )			=> 'light',
				esc_html__( 'Accent', 'aiko' )			=> 'accent',
				esc_html__( 'Alternate', 'aiko' )		=> 'alternate'
			)
		),
		array( 'param_name' => 'trigger_style', 'type' => 'dropdown', 'heading' => esc_html__( 'Trigger style', 'aiko' ), 'preview' => true,
			'value' => array(
				esc_html__( 'Plus/Minus (borderless)', 'aiko' )	=> '',
				esc_html__( 'Plus/Minus (outline)', 'aiko' )		=> 'outline',
				esc_html__( 'Arrow', 'aiko' )					=> 'arrow'
			)
		),
		array( 'param_name' => 'title_size', 'type' => 'dropdown', 'heading' => esc_html__( 'Title size', 'aiko' ), 
			'value' => array(
				esc_html__( 'Normal', 'aiko' ) 		=> '',
				esc_html__( 'Large', 'aiko' ) 		=> 'large'
			)
		),
		array( 'param_name' => 'font_weight', 'type' => 'dropdown', 'heading' => esc_html__( 'Title font weight', 'aiko' ), 
			'value' => array(
				esc_html__( 'Default', 'aiko' ) 		=> '',
				esc_html__( 'Normal', 'aiko' ) 		=> 'normal',
				esc_html__( 'Bold', 'aiko' ) 		=> 'bold',
				esc_html__( 'Bolder', 'aiko' ) 		=> 'bolder',
				esc_html__( 'Lighter', 'aiko' ) 		=> 'lighter',
				esc_html__( 'Light', 'aiko' ) 		=> 'light',
				esc_html__( 'Thin', 'aiko' ) 		=> 'thin',
				esc_html__( '100', 'aiko' ) 			=> '100',
				esc_html__( '200', 'aiko' ) 			=> '200',
				esc_html__( '300', 'aiko' ) 			=> '300',
				esc_html__( '400', 'aiko' ) 			=> '400',
				esc_html__( '500', 'aiko' ) 			=> '500',
				esc_html__( '600', 'aiko' ) 			=> '600',
				esc_html__( '700', 'aiko' ) 			=> '700',
				esc_html__( '800', 'aiko' ) 			=> '800',
				esc_html__( '900', 'aiko' ) 			=> '900'
			)
		),
	));
}

function aiko_bt_bb_accordion_class( $class, $atts ) {
	if ( isset( $atts['trigger_color'] ) && $atts['trigger_color'] != '' ) {
		$class[] = 'bt_bb_trigger_color' . '_' . $atts['trigger_color'];
	}
	if ( isset( $atts['trigger_style'] ) && $atts['trigger_style'] != '' ) {
		$class[] = 'bt_bb_trigger_style' . '_' . $atts['trigger_style'];
	}
	if ( isset( $atts['title_size'] ) && $atts['title_size'] != '' ) {
		$class[] = 'bt_bb_title_size' . '_' . $atts['title_size'];
	}
	if ( isset( $atts['font_weight'] ) && $atts['font_weight'] != '' ) {
		$class[] = 'bt_bb_font_weight' . '_' . $atts['font_weight'];
	}
	return $class;
}
add_filter( 'bt_bb_accordion_class', 'aiko_bt_bb_accordion_class', 10, 2 );


// POST GRID - COLOR SCHEME, EXCERPT LINES
if ( function_exists( 'bt_bb_add_params' ) ) {
	bt_bb_add_params( 'bt_bb_css_post_grid', array(
		array( 'param_name' => 'color_scheme', 'preview' => true, 'type' => 'dropdown', 'heading' => esc_html__( 'Color scheme', 'aiko' ), 'value' => $color_scheme_arr ),
		array( 'param_name' => 'title_lines', 'type' => 'dropdown', 'heading' => esc_html__( 'Title lines', 'aiko' ), 
			'value' => array(
				esc_html__( 'All', 'aiko' )		=> '',
				esc_html__( '4', 'aiko' )		=> '4',
				esc_html__( '3', 'aiko' )		=> '3',
				esc_html__( '2', 'aiko' )		=> '2',
				esc_html__( '1', 'aiko' )		=> '1'
			)
		),
		array( 'param_name' => 'title_font_weight', 'type' => 'dropdown', 'heading' => esc_html__( 'Title font weight', 'aiko' ), 
			'value' => array(
				esc_html__( 'Default', 'aiko' ) 		=> '',
				esc_html__( 'Normal', 'aiko' ) 		=> 'normal',
				esc_html__( 'Bold', 'aiko' ) 		=> 'bold',
				esc_html__( 'Bolder', 'aiko' ) 		=> 'bolder',
				esc_html__( 'Lighter', 'aiko' ) 		=> 'lighter',
				esc_html__( 'Light', 'aiko' ) 		=> 'light',
				esc_html__( 'Thin', 'aiko' ) 		=> 'thin',
				esc_html__( '100', 'aiko' ) 			=> '100',
				esc_html__( '200', 'aiko' ) 			=> '200',
				esc_html__( '300', 'aiko' ) 			=> '300',
				esc_html__( '400', 'aiko' ) 			=> '400',
				esc_html__( '500', 'aiko' ) 			=> '500',
				esc_html__( '600', 'aiko' ) 			=> '600',
				esc_html__( '700', 'aiko' ) 			=> '700',
				esc_html__( '800', 'aiko' ) 			=> '800',
				esc_html__( '900', 'aiko' ) 			=> '900'
			)
		),
		array( 'param_name' => 'excerpt_lines', 'type' => 'dropdown', 'heading' => esc_html__( 'Excerpt lines', 'aiko' ), 
			'value' => array(
				esc_html__( 'All', 'aiko' )		=> '',
				esc_html__( '4', 'aiko' )		=> '4',
				esc_html__( '3', 'aiko' )		=> '3',
				esc_html__( '2', 'aiko' )		=> '2',
				esc_html__( '1', 'aiko' )		=> '1'
			)
		),
	));
}

function aiko_bt_bb_css_post_grid_class( $class, $atts ) {
	if ( isset( $atts['color_scheme'] ) && $atts['color_scheme'] != '' ) {
		$class[] = 'bt_bb_color_scheme' . '_' . bt_bb_get_color_scheme_id( $atts['color_scheme'] );
	}
	if ( isset( $atts['title_lines'] ) && $atts['title_lines'] != '' ) {
		$class[] = 'bt_bb_title_lines' . '_' . $atts['title_lines'];
	}
	if ( isset( $atts['title_font_weight'] ) && $atts['title_font_weight'] != '' ) {
		$class[] = 'bt_bb_title_font_weight' . '_' . $atts['title_font_weight'];
	}
	if ( isset( $atts['excerpt_lines'] ) && $atts['excerpt_lines'] != '' ) {
		$class[] = 'bt_bb_excerpt_lines' . '_' . $atts['excerpt_lines'];
	}
	return $class;
}

function aiko_bt_bb_css_post_grid_style( $style, $atts ) {
	if ( isset( $atts['color_scheme'] ) && $atts['color_scheme'] != '' ) {
		$color_scheme_id = NULL;
		if ( is_numeric ( $atts['color_scheme'] ) ) {
			$color_scheme_id = $atts['color_scheme'];
		} else if ( $atts['color_scheme'] != '' ) {
			$color_scheme_id = bt_bb_get_color_scheme_id( $atts['color_scheme'] );
		}
		$color_scheme_colors = bt_bb_get_color_scheme_colors_by_id( $color_scheme_id - 1 );
		if ( $color_scheme_colors ) $style .= '; --post-grid-primary-color:' . $color_scheme_colors[0] . '; --post-grid-secondary-color:' . $color_scheme_colors[1] . ';';
	}
	return $style;
}

add_filter( 'bt_bb_css_post_grid_class', 'aiko_bt_bb_css_post_grid_class', 10, 2 );
add_filter( 'bt_bb_css_post_grid_style', 'aiko_bt_bb_css_post_grid_style', 10, 2 );



/* FRONT END 
---------------------------------------------------------- */

/* OLD ELEMENTS */
function bt_bb_fe_new_params( $elements_array) {

	$elements_array[ 'bt_bb_section' ][ 'params' ][ 'negative_margin' ] = array( 'ajax_filter' => array( 'class', 'data-bt-override-class' ) );
	$elements_array[ 'bt_bb_section' ][ 'params' ][ 'shape' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_section' ][ 'params' ][ 'top_left_shape' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_section' ][ 'params' ][ 'top_right_shape' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_section' ][ 'params' ][ 'bottom_left_shape' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_section' ][ 'params' ][ 'bottom_right_shape' ] = array( 'ajax_filter' => array( 'class' ) );

	$elements_array[ 'bt_bb_headline' ][ 'params' ][ 'dash_color' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_headline' ][ 'params' ][ 'style' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_headline' ][ 'params' ][ 'heading_letter_spacing' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_headline' ][ 'params' ][ 'supertitle_letter_spacing' ] = array( 'ajax_filter' => array( 'class' ) );

	$elements_array[ 'bt_bb_button' ][ 'params' ][ 'icon_animation' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_button' ][ 'params' ][ 'icon_color_scheme' ] = array( 'ajax_filter' => array( 'class', 'style' ) );

	$elements_array[ 'bt_bb_icon' ][ 'params' ][ 'text_size' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_icon' ][ 'params' ][ 'text_color' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_icon' ][ 'params' ][ 'align_content' ] = array( 'ajax_filter' => array( 'class' ) );

	$elements_array[ 'bt_bb_service' ][ 'params' ][ 'text_color' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_service' ][ 'params' ][ 'align_content' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_service' ][ 'params' ][ 'title_size' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_service' ][ 'params' ][ 'title_font_weight' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_service' ][ 'params' ][ 'letter_spacing' ] = array( 'ajax_filter' => array( 'class' ) );

	$elements_array[ 'bt_bb_counter' ][ 'params' ][ 'text' ] = array( 'js_handler' => array( 'target_selector' => '.bt_bb_counter_text', 'type' => 'inner_html' ) );
	$elements_array[ 'bt_bb_counter' ][ 'params' ][ 'font_weight' ] = array( 'ajax_filter' => array( 'class' ) );

	$elements_array[ 'bt_bb_separator' ][ 'params' ][ 'opacity' ] = array( 'ajax_filter' => array( 'class' ) );

	$elements_array[ 'bt_bb_latest_posts' ][ 'params' ][ 'title_lines' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_latest_posts' ][ 'params' ][ 'excerpt_lines' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_latest_posts' ][ 'params' ][ 'title_font_weight' ] = array( 'ajax_filter' => array( 'class' ) );

	$elements_array[ 'bt_bb_image' ][ 'params' ][ 'top_negative_margin' ] = array( 'ajax_filter' => array( 'class', 'data-bt-override-class' ) );
	$elements_array[ 'bt_bb_image' ][ 'params' ][ 'bottom_negative_margin' ] = array( 'ajax_filter' => array( 'class', 'data-bt-override-class' ) );
	$elements_array[ 'bt_bb_image' ][ 'params' ][ 'right_negative_margin' ] = array( 'ajax_filter' => array( 'class', 'data-bt-override-class' ) );
	$elements_array[ 'bt_bb_image' ][ 'params' ][ 'left_negative_margin' ] = array( 'ajax_filter' => array( 'class', 'data-bt-override-class' ) );

	$elements_array[ 'bt_bb_custom_menu' ][ 'params' ][ 'color_scheme' ] = array( 'ajax_filter' => array( 'class', 'style' ) );
	$elements_array[ 'bt_bb_custom_menu' ][ 'params' ][ 'font_size' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_custom_menu' ][ 'params' ][ 'style' ] = array( 'ajax_filter' => array( 'class' ) );

	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'text' ] = array( 'js_handler' => array( 'target_selector' => '.bt_bb_price_list_text', 'type' => 'inner_html' ) );
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'hover_color_scheme' ] = array( 'ajax_filter' => array( 'class', 'style' ) );
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'shape' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'shadow' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'style' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'hover_style' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'icons_color' ] = array( 'ajax_filter' => array( 'class' ) );
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'button_style' ] = array();
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'button_color_scheme' ] = array();
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'hover_button_color_scheme' ] = array( 'ajax_filter' => array( 'class', 'style' ) );
	$elements_array[ 'bt_bb_price_list' ][ 'params' ][ 'font_weight' ] = array( 'ajax_filter' => array( 'class' ) );
	
    return $elements_array;
}
add_filter( 'bt_bb_fe_elements', 'bt_bb_fe_new_params' );



/* NEW ELEMENTS */
function aiko_bt_bb_fe( $elements ) {

	$elements[ 'bt_bb_contact_form_7' ] = array(
		'edit_box_selector' => '',
		'params' => array(
			'input_size'				=> array( 'ajax_filter' => array( 'class' ) ),
			'input_style'				=> array( 'ajax_filter' => array( 'class' ) ),
			'shape'						=> array( 'ajax_filter' => array( 'class' ) ),
			'placeholder_style'			=> array( 'ajax_filter' => array( 'class' ) ),
			'input_color_scheme'		=> array( 'ajax_filter' => array( 'class', 'style' ) ), 
			'button_size'				=> array( 'ajax_filter' => array( 'class' ) ),
			'button_style'				=> array( 'ajax_filter' => array( 'class' ) ),
			'button_shape'				=> array( 'ajax_filter' => array( 'class' ) ),
			'button_width'				=> array( 'ajax_filter' => array( 'class' ) ),
			'button_font_weight'		=> array( 'ajax_filter' => array( 'class' ) ),
			'color_scheme'				=> array( 'ajax_filter' => array( 'class', 'style' ) ),
		),
	);

	$elements[ 'bt_bb_card_icon' ] = array(
		'edit_box_selector' => '',
		'params' => array(
			'icon'						=> array(),
			'title'						=> array(),
			'text'						=> array( 'js_handler' => array( 'target_selector' => '.bt_bb_card_icon_inner .bt_bb_card_icon_text p', 'type' => 'inner_html' ) ),
			'url'						=> array( 'js_handler' => array( 'target_selector' => 'a', 'type' => 'attr', 'attr' => 'href' ) ),
			'target' 					=> array( 'js_handler' => array( 'target_selector' => 'a', 'type' => 'attr', 'attr' => 'target' ) ),
			'padding'					=> array( 'ajax_filter' => array( 'class', 'data-bt-override-class' ) ),
			
			'style'						=> array( 'ajax_filter' => array( 'class' ) ),
			'shape'						=> array( 'ajax_filter' => array( 'class' ) ),
			'shadow'					=> array( 'ajax_filter' => array( 'class' ) ),
			'blur'						=> array( 'ajax_filter' => array( 'class' ) ),
			'color_scheme'				=> array( 'ajax_filter' => array( 'class', 'style' ) ),
			'hover_color_scheme'		=> array( 'ajax_filter' => array( 'class', 'style' ) ),
			'hover_text_color'			=> array( 'ajax_filter' => array( 'class' ) ),
			'background_color'			=> array( 'js_handler'  => array( 'target_selector' => '', 'type' => 'background_color' ) ),
			'border_color'				=> array( 'ajax_filter' => array( 'class' ) ),
			'show_content'				=> array( 'ajax_filter' => array( 'class' ) ),
			'title_size'				=> array(),
			'title_font_weight'			=> array(),
			'icon_style'				=> array(),
			'icon_size'					=> array(),
			'icon_shape'				=> array(),
			'icon_color_scheme'			=> array(),
			'icon_hover_color_scheme'	=> array( 'ajax_filter' => array( 'class', 'style' ) ),

		),
	);

	$elements[ 'bt_bb_progress_bar_advanced' ] = array(
		'edit_box_selector' => '',
		'params' => array(
			'progress_text'				=> array(),
			'text'						=> array( 'js_handler' => array( 'target_selector' => 'p', 'type' => 'inner_html' ) ),
			'size'						=> array( 'ajax_filter' => array( 'class' ) ),
			'progress_text_position'	=> array( 'ajax_filter' => array( 'class' ) ),
			'progress_text_color'		=> array( 'ajax_filter' => array( 'class' ) ),
			'text_below_color'		=> array( 'ajax_filter' => array( 'class' ) ),
			'font_weight'			=> array( 'ajax_filter' => array( 'class' ) ),
		),
	);

	$elements[ 'bt_bb_card_image' ] = array(
		'edit_box_selector' => '',
		'params' => array(
			'image'						=> array(),
			'url'						=> array( 'js_handler' => array( 'target_selector' => 'a', 'type' => 'attr', 'attr' => 'href' ) ),
			'target' 					=> array( 'js_handler' => array( 'target_selector' => 'a', 'type' => 'attr', 'attr' => 'target' ) ),
			'shape' 					=> array( 'js_handler' => array( 'target_selector' => '', 'type' => 'class' ) ),
			'shadow' 					=> array( 'js_handler' => array( 'target_selector' => '', 'type' => 'class' ) ),
			'style'						=> array( 'ajax_filter' => array( 'class' ) ),
			'blur'						=> array( 'ajax_filter' => array( 'class' ) ),
			'border_color'				=> array( 'ajax_filter' => array( 'class' ) ),
			'hover_color_scheme'		=> array( 'ajax_filter' => array( 'class', 'style' ) ),
			'hover_style'				=> array( 'ajax_filter' => array( 'class' ) ),
		),
	);

	$elements[ 'bt_bb_css_post_grid' ] = array(
		'edit_box_selector' => '',
		'params' => array(
			'gap'						=> array( 'ajax_filter' => array( 'class' ) ),
			'shape' 					=> array( 'ajax_filter' => array( 'class' ) ),
			'color_scheme'				=> array( 'ajax_filter' => array( 'class', 'style' ) ), 
			'excerpt_lines' 			=> array( 'ajax_filter' => array( 'class' ) ),
			'title_lines' 				=> array( 'ajax_filter' => array( 'class' ) ),
			'title_font_weight' 		=> array( 'ajax_filter' => array( 'class' ) ),
		),
	);

	$elements[ 'bt_bb_single_product' ] = array(
		'edit_box_selector' => '',
		'params' => array(
			'product_id'        		=> array(),
			'product_image'      		=> array(),
			'product_title'        		=> array( 'js_handler' => array( 'target_selector' => '.bt_bb_single_product_title a', 'type' => 'inner_html' ) ),
			'product_price'      		=> array( 'js_handler' => array( 'target_selector' => '.bt_bb_single_product_price', 'type' => 'inner_html' ) ),
			'title_font_weight'    		=> array(),
			'shape'						=> array( 'ajax_filter' => array( 'class' ) ),
			'show_button'				=> array( 'ajax_filter' => array( 'class' ) ),
			'show_category'				=> array(),
		),
	);

	$elements[ 'bt_bb_process' ] = array(
		'edit_box_selector' => '',
		'params' => array(
			'icon_color_scheme'			=> array( 'ajax_filter' => array( 'class', 'style' ) ),
			'title_font_weight'			=> array( 'ajax_filter' => array( 'class' ) ),
		),
	);

	$elements[ 'bt_bb_process_step' ] = array(
		'edit_box_selector' => '',
		'params' => array(
			'icon'						=> array(),
			'title'						=> array( 'js_handler' => array( 'target_selector' => '.bt_bb_process_step_content .bt_bb_card_icon_text p', 'type' => 'inner_html' ) ),
			'text'						=> array( 'js_handler' => array( 'target_selector' => '.bt_bb_process_step_content .bt_bb_card_icon_text p', 'type' => 'inner_html' ) ),
		),
	);

	$elements[ 'bt_bb_animated_headline' ] = array(
		'edit_box_selector' => '',
		'params' => array(
			'title_size'				=> array( 'ajax_filter' => array( 'class' ) ),
			'lines'						=> array( 'ajax_filter' => array( 'class' ) ),
		),
	);

	$elements[ 'bt_bb_links' ] = array(
		'edit_box_selector' => '',
		'params' => array(
			'supertitle'				=> array(),
			'title_font_weight'			=> array( 'ajax_filter' => array( 'class' ) ),
			'button_text'				=> array(),
			'icon'						=> array(),
		),
	);

	$elements[ 'bt_bb_link_item' ] = array(
		'edit_box_selector' => '',
		'params' => array(
			'text'					=> array(),
			'image'					=> array(),
		),
	);

	return $elements;
}

add_filter( 'bt_bb_fe_elements', 'aiko_bt_bb_fe' );


/* ADD NEW ELEMENTS */
function aiko_bt_bb_fe_templates( $templates ) {

	$templates[ 'progress_bar_advanced' ] = array(
		'base' 			=> esc_html__( 'bt_bb_progress_bar_advanced', 'aiko' ),
		'name' 			=> esc_html__( 'Advanced Progress Bar', 'aiko' ),
		'description' 	=> esc_html__( 'Advanced Progress Bar', 'aiko' ),
	);

	$templates[ 'animated_headline' ] = array(
		'base' 			=> esc_html__( 'bt_bb_animated_headline', 'aiko' ),
		'name' 			=> esc_html__( 'Animated Headline', 'aiko' ),
		'description' 	=> esc_html__( 'Animated headline with effect', 'aiko' ),
	);

	$templates[ 'card_icon' ] = array(
		'base' 			=> esc_html__( 'bt_bb_card_icon', 'aiko' ),
		'name' 			=> esc_html__( 'Card Icon', 'aiko' ),
		'description' 	=> esc_html__( 'Card with icon and text', 'aiko' ),
	);

	$templates[ 'card_image' ] = array(
		'base' 			=> esc_html__( 'bt_bb_card_image', 'aiko' ),
		'name' 			=> esc_html__( 'Card Image', 'aiko' ),
		'description' 	=> esc_html__( 'Card with image and text', 'aiko' ),
	);

	$templates[ 'floating_image' ] = array(
		'base' 			=> esc_html__( 'bt_bb_floating_image', 'aiko' ),
		'name' 			=> esc_html__( 'Floating Image', 'aiko' ),
		'description' 	=> esc_html__( 'Absolute positioned floating image', 'aiko' ),
	);

	$templates[ 'links' ] = array(
		'base' 			=> esc_html__( 'bt_bb_links', 'aiko' ),
		'name' 			=> esc_html__( 'Links', 'aiko' ),
		'description' 	=> esc_html__( 'Links', 'aiko' ),
	);

	$templates[ 'process' ] = array(
		'base' 			=> esc_html__( 'bt_bb_process', 'aiko' ),
		'name' 			=> esc_html__( 'Process', 'aiko' ),
		'description' 	=> esc_html__( 'Process', 'aiko' ),
	);

	$templates[ 'single_product' ] = array(
		'base' 			=> esc_html__( 'bt_bb_single_product', 'aiko' ),
		'name' 			=> esc_html__( 'Single Product', 'aiko' ),
		'description' 	=> esc_html__( 'Single WooCommerce product', 'aiko' ),
	);

	return $templates;
}

add_filter( 'bt_bb_fe_templates', 'aiko_bt_bb_fe_templates' );