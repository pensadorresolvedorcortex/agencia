<?php

require_once( get_template_directory() . '/assets/php/before_framework/functions.php' );
require_once( get_template_directory() . '/assets/php/before_framework/customize_params.php' );