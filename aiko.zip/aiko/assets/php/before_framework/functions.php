<?php

/**
 * Color schemes
 */

if ( ! function_exists( 'aiko_color_schemes' ) ) {
	function aiko_color_schemes( $color_scheme_arr ) {

		$theme_color_schemes = array();
		
		/* 01 */ $theme_color_schemes[] = 'accent-light;Accent color, Light color;var(--accent-color);var(--light-color)';
		/* 02 */ $theme_color_schemes[] = 'accent-dark;Accent color, Dark color;var(--accent-color);var(--dark-color)';
		
		/* 03 */ $theme_color_schemes[] = 'light-accent;Light color, Accent color;var(--light-color);var(--accent-color)';
		/* 04 */ $theme_color_schemes[] = 'dark-accent;Dark color, Accent color;var(--dark-color);var(--accent-color)';
		
		/* 05 */ $theme_color_schemes[] = 'alternate-light;Alternate color, Light color;var(--alternate-color);var(--light-color)';
		/* 06 */ $theme_color_schemes[] = 'alternate-dark;Alternate color, Dark color;var(--alternate-color);var(--dark-color)';
		
		/* 07 */ $theme_color_schemes[] = 'light-alternate;Light color, Alternate color;var(--light-color);var(--alternate-color)';
		/* 08 */ $theme_color_schemes[] = 'dark-alternate;Dark color, Alternate color;var(--dark-color);var(--alternate-color)';
		
		/* 09 */ $theme_color_schemes[] = 'light-dark;Light color, Dark color;var(--light-color);var(--dark-color)';
		/* 10 */ $theme_color_schemes[] = 'dark-light;Dark color, Light color;var(--dark-color);var(--light-color)';
		
		/* 11 */ $theme_color_schemes[] = 'light-transparent;Light color, Transparent;var(--light-color);var(--transparent-color)';
		/* 12 */ $theme_color_schemes[] = 'dark-transparent;Dark color, Transparent;var(--dark-color);var(--transparent-color)';

		/* 13 */ $theme_color_schemes[] = 'dark-gray;Dark color, Gray color;var(--dark-color);var(--gray-color)';

		/* 14 */ $theme_color_schemes[] = 'accent-alternate;Accent color, Alternate color;var(--accent-color);var(--alternate-color)';
		/* 15 */ $theme_color_schemes[] = 'alternate-accent;Alternate color, Accent color;var(--alternate-color);var(--accent-color)';

		/* 16 */ $theme_color_schemes[] = 'accent-transparent;Accent color, Transparent;var(--accent-color);var(--transparent-color)';
		/* 17 */ $theme_color_schemes[] = 'alternate-transparent;Alternate color, Transparent;var(--alternate-color);var(--transparent-color)';

		/* 18 */ $theme_color_schemes[] = 'gray-accent;Gray color, Accent color;var(--service-gray-color);var(--accent-color)';

		/* 19 */ $theme_color_schemes[] = 'all-light;All light color;var(--light-color);var(--light-color)';
		/* 20 */ $theme_color_schemes[] = 'all-dark;All dark color;var(--dark-color);var(--dark-color)';

		/* 21 */ $theme_color_schemes[] = 'dark-dark-gray;Dark color, Dark gray color;var(--dark-color);var(--dark-gray-color)';
		/* 22 */ $theme_color_schemes[] = 'light-dark-transparent;Light color, Dark transparent color;var(--light-color);var(--dark-10-color)';

		/* 23 */ $theme_color_schemes[] = 'light-light-transparent;Light color, Light transparent color;var(--light-color);var(--light-30-color)';
		/* 24 */ $theme_color_schemes[] = 'light-pink;Light color, Pink color;var(--light-color);var(--pink-color)';

		/* 25 */ $theme_color_schemes[] = 'accent-dark-gray;Accent color, Dark gray color;var(--accent-color);var(--dark-gray-color)';

		/* 26 */ $theme_color_schemes[] = 'light-semi-dark;Light color, Semi dark color;var(--light-color);var(--dark-30-color)';
		/* 27 */ $theme_color_schemes[] = 'dark-semi-light;Dark color, Semi light color;var(--dark-color);var(--light-60-color)';

		/* 28 */ $theme_color_schemes[] = 'gray-alternate;Gray color, Alternate color;var(--service-gray-color);var(--alternate-color)';

		/* 29 */ $theme_color_schemes[] = 'pink-alternate;Pink color, Alternate color;var(--pink-color);var(--alternate-color)';

		return array_merge( $theme_color_schemes, $color_scheme_arr );
	}
}

add_filter( 'bt_bb_color_scheme_arr', 'aiko_color_schemes' );

