<?php

// SHOP GENERAL
// SHOP SINGLE BUTTON STYLE
if ( ! function_exists( 'boldthemes_get_button_styles' ) ) {
	function boldthemes_get_button_styles() {
		$button_styles = array(
			'filled'			=> esc_html__( 'Filled', 'aiko' ),
			'filled_gradient'	=> esc_html__( 'Filled (gradient)', 'aiko' ),
			'outline'			=> esc_html__( 'Outline', 'aiko' ),
			'clean'				=> esc_html__( 'Clean', 'aiko' ),
		);
		return $button_styles;
	}
}