<?php

/* Colors */
BoldThemes_Customize_Default::$data['accent_color']							= '#0E17FF';
BoldThemes_Customize_Default::$data['alternate_color']						= '#FF00B7';

/* Logo */
BoldThemes_Customize_Default::$data['logo_height'] 							= '100px';
BoldThemes_Customize_Default::$data['sticky_logo_height'] 					= '60px';
BoldThemes_Customize_Default::$data['responsive_logo_height'] 				= '70px';
BoldThemes_Customize_Default::$data['menu_hover_color_scheme'] 				= '1';
BoldThemes_Customize_Default::$data['header_lines'] 						= '';
BoldThemes_Customize_Default::$data['lines_opacity'] 						= '';
BoldThemes_Customize_Default::$data['blur'] 								= '';
BoldThemes_Customize_Default::$data['sticky_blur'] 							= '';
BoldThemes_Customize_Default::$data['current_menu_line_color'] 				= '';
BoldThemes_Customize_Default::$data['sticky_current_menu_line_color'] 		= '';


/* Typography */
BoldThemes_Customize_Default::$data['body_font'] 							= 'Plus Jakarta Sans';
BoldThemes_Customize_Default::$data['heading_font'] 						= 'Space Grotesk';
BoldThemes_Customize_Default::$data['heading_font_weight'] 					= '300';
BoldThemes_Customize_Default::$data['heading_letter_spacing'] 				= '-1px';
BoldThemes_Customize_Default::$data['supertitle_font'] 						= 'Plus Jakarta Sans';
BoldThemes_Customize_Default::$data['supertitle_font_weight'] 				= '500';
BoldThemes_Customize_Default::$data['supertitle_letter_spacing'] 			= '2px';
BoldThemes_Customize_Default::$data['subtitle_font'] 						= 'Plus Jakarta Sans';
BoldThemes_Customize_Default::$data['subtitle_font_weight'] 				= '500';
BoldThemes_Customize_Default::$data['menu_font'] 							= 'Plus Jakarta Sans';
BoldThemes_Customize_Default::$data['menu_first_level_text_transform'] 		= 'uppercase';
BoldThemes_Customize_Default::$data['menu_other_levels_text_transform'] 	= 'uppercase';
BoldThemes_Customize_Default::$data['menu_first_level_font_weight'] 		= '500';
BoldThemes_Customize_Default::$data['menu_other_levels_font_weight'] 		= '500';
BoldThemes_Customize_Default::$data['button_font'] 							= 'Plus Jakarta Sans';
BoldThemes_Customize_Default::$data['button_font_weight'] 					= '700';
BoldThemes_Customize_Default::$data['button_shape'] 						= 'round';
BoldThemes_Customize_Default::$data['button_text_transform'] 				= 'uppercase';
BoldThemes_Customize_Default::$data['button_style']							= 'filled_gradient';
BoldThemes_Customize_Default::$data['button_color_scheme']					= '14';


/* Posts slider default image (for posts without featured image) */
BoldThemes_Customize_Default::$data['post_image_default'] 					= '';

/* Template */
BoldThemes_Customize_Default::$data['content_width']						= 'boxed-1400';
BoldThemes_Customize_Default::$data['sidebar_headline_size']				= 'small';


/* Header */
BoldThemes_Customize_Default::$data['header_position']						= 'top';
BoldThemes_Customize_Default::$data['header_width']							= 'wide';
BoldThemes_Customize_Default::$data['sticky_header_width']					= 'wide';
BoldThemes_Customize_Default::$data['primary_menu_position']				= 'logo-right';
BoldThemes_Customize_Default::$data['footer_width']							= 'wide-boxed-1400';
BoldThemes_Customize_Default::$data['default_headline_width']				= 'wide-boxed-1400';
BoldThemes_Customize_Default::$data['default_headline_size']				= 'extralarge';
BoldThemes_Customize_Default::$data['default_headline_color_scheme']		= '9';


/* Blog */
BoldThemes_Customize_Default::$data['blog_list_headline_size'] 				= 'normal';
BoldThemes_Customize_Default::$data['blog_list_read_more_icon']				= '';
BoldThemes_Customize_Default::$data['blog_list_read_more_size']				= 'medium';
BoldThemes_Customize_Default::$data['blog_list_read_more_color_scheme']		= '14';
BoldThemes_Customize_Default::$data['blog_list_read_more_style']			= 'filled_gradient';
BoldThemes_Customize_Default::$data['blog_list_show_superheadline'] 		= array();
BoldThemes_Customize_Default::$data['blog_list_show_subheadline'] 			= array( 'date', 'author', 'categories' );
BoldThemes_Customize_Default::$data['blog_single_show_bottom'] 				= array( 'tags' );
BoldThemes_Customize_Default::$data['blog_image_shape']						= '';


/* Portfolio */
BoldThemes_Customize_Default::$data['pf_list_headline_size'] 				= 'normal';
BoldThemes_Customize_Default::$data['pf_list_read_more_icon']				= '';
BoldThemes_Customize_Default::$data['pf_list_read_more_size']				= 'medium';
BoldThemes_Customize_Default::$data['pf_list_read_more_style']				= 'filled_gradient';
BoldThemes_Customize_Default::$data['pf_list_read_more_color_scheme']		= '14';
BoldThemes_Customize_Default::$data['pf_image_shape']						= '';

/* Shop */
BoldThemes_Customize_Default::$data['shop_button_color_scheme']				= '14';
BoldThemes_Customize_Default::$data['shop_button_style']					= 'filled_gradient';
BoldThemes_Customize_Default::$data['shop_list_button_color_scheme']		= '14';
BoldThemes_Customize_Default::$data['shop_image_shape']						= '';
BoldThemes_Customize_Default::$data['shop_list_headline_size']				= 'extrasmall';


BoldThemes_Customize_Default::$data['search_list_read_more_icon']			= '';
BoldThemes_Customize_Default::$data['search_list_read_more_size']			= 'medium';
BoldThemes_Customize_Default::$data['search_list_read_more_color_scheme']	= '14';
BoldThemes_Customize_Default::$data['search_list_read_more_style']			= 'filled_gradient';
BoldThemes_Customize_Default::$data['search_list_show_superheadline'] 		= array();
BoldThemes_Customize_Default::$data['search_list_show_subheadline'] 		= array( 'date', 'author' );

require_once( get_template_directory() . '/assets/php/after_framework/functions.php' );
require_once( get_template_directory() . '/assets/php/after_framework/customize_params.php' );

