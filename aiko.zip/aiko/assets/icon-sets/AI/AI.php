<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'android (AI set)' => $set . '_e900',
	'chatbot (AI set)' => $set . '_e901',
	'artificial-intelligence (AI set)' => $set . '_e902',
	'smart-assistant (AI set)' => $set . '_e903',
	'binary-codes (AI set)' => $set . '_e904',
	'chat-bot (AI set)' => $set . '_e905',
	'chips (AI set)' => $set . '_e906',
	'cloud-computing (AI set)' => $set . '_e907',
	'cpu (AI set)' => $set . '_e908',
	'data-analysis (AI set)' => $set . '_e909',
	'filtering (AI set)' => $set . '_e90a',
	'facial-recognition (AI set)' => $set . '_e90b',
	'gear (AI set)' => $set . '_e90c',
	'image-file (AI set)' => $set . '_e90d',
	'image-processing (AI set)' => $set . '_e90e',
	'face-scan (AI set)' => $set . '_e90f',
	'robot-arm (AI set)' => $set . '_e910',
	'emotions (AI set)' => $set . '_e911',
	'smart-assistant1 (AI set)' => $set . '_e912',
	'voice-recognition (AI set)' => $set . '_e913',
	'text-tool (AI set)' => $set . '_e914',
	'text-to-speech (AI set)' => $set . '_e915',
	'translate (AI set)' => $set . '_e916',
	'virtual-reality (AI set)' => $set . '_e917',
	'eye-scanner (AI set)' => $set . '_e918'
);