<?php $admin_style = sanitize_text_field('

@font-face{ font-family:"Essential";src:url("' . get_parent_theme_file_uri( 'framework/assets/icon-sets/Essential/Essential.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'framework/assets/icon-sets/Essential/Essential.ttf' ) . '")format("truetype"); }
*[data-ico-essential]:before{ font-family:Essential;content:attr(data-ico-essential); }
.bt_bb_icon_preview.bt_bb_icon_preview_essential { font-family:Essential; }

@font-face{ font-family:"FontAwesome5Brands";src:url("' . get_parent_theme_file_uri( 'framework/assets/icon-sets/FontAwesome5Brands/FontAwesome5Brands.woff' ) . '")format("woff"); }
*[data-ico-fontawesome5brands]:before{ font-family:FontAwesome5Brands;content:attr(data-ico-fontawesome5brands); }
.bt_bb_icon_preview.bt_bb_icon_preview_fontawesome5brands { font-family:FontAwesome5Brands; }

@font-face{ font-family:"FontAwesome5Regular";src:url("' . get_parent_theme_file_uri( 'framework/assets/icon-sets/FontAwesome5Regular/FontAwesome5Regular.woff' ) . '")format("woff"); }
*[data-ico-fontawesome5regular]:before{ font-family:FontAwesome5Regular;content:attr(data-ico-fontawesome5regular); }
.bt_bb_icon_preview.bt_bb_icon_preview_fontawesome5regular { font-family:FontAwesome5Regular; }

@font-face{ font-family:"FontAwesome5Solid";src:url("' . get_parent_theme_file_uri( 'framework/assets/icon-sets/FontAwesome5Solid/FontAwesome5Solid.woff' ) . '")format("woff"); }
*[data-ico-fontawesome5solid]:before{ font-family:FontAwesome5Solid;content:attr(data-ico-fontawesome5solid); }
.bt_bb_icon_preview.bt_bb_icon_preview_fontawesome5solid { font-family:FontAwesome5Solid; }

@font-face{ font-family:"FontAwesome6Brands";src:url("' . get_parent_theme_file_uri( 'framework/assets/icon-sets/FontAwesome6Brands/FontAwesome6Brands.woff2' ) . '")format("woff2"),url("' . get_parent_theme_file_uri( 'framework/assets/icon-sets/FontAwesome6Brands/FontAwesome6Brands.ttf' ) . '")format("truetype"); }
*[data-ico-fontawesome6brands]:before{ font-family:FontAwesome6Brands;content:attr(data-ico-fontawesome6brands); }
.bt_bb_icon_preview.bt_bb_icon_preview_fontawesome6brands { font-family:FontAwesome6Brands; }

@font-face{ font-family:"FontAwesome6Regular";src:url("' . get_parent_theme_file_uri( 'framework/assets/icon-sets/FontAwesome6Regular/FontAwesome6Regular.woff2' ) . '")format("woff2"),url("' . get_parent_theme_file_uri( 'framework/assets/icon-sets/FontAwesome6Regular/FontAwesome6Regular.ttf' ) . '")format("truetype"); }
*[data-ico-fontawesome6regular]:before{ font-family:FontAwesome6Regular;content:attr(data-ico-fontawesome6regular); }
.bt_bb_icon_preview.bt_bb_icon_preview_fontawesome6regular { font-family:FontAwesome6Regular; }

@font-face{ font-family:"FontAwesome6Solid";src:url("' . get_parent_theme_file_uri( 'framework/assets/icon-sets/FontAwesome6Solid/FontAwesome6Solid.woff2' ) . '")format("woff2"),url("' . get_parent_theme_file_uri( 'framework/assets/icon-sets/FontAwesome6Solid/FontAwesome6Solid.ttf' ) . '")format("truetype"); }
*[data-ico-fontawesome6solid]:before{ font-family:FontAwesome6Solid;content:attr(data-ico-fontawesome6solid); }
.bt_bb_icon_preview.bt_bb_icon_preview_fontawesome6solid { font-family:FontAwesome6Solid; }

@font-face{ font-family:"Icon7Stroke";src:url("' . get_parent_theme_file_uri( 'framework/assets/icon-sets/Icon7Stroke/Icon7Stroke.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'framework/assets/icon-sets/Icon7Stroke/Icon7Stroke.ttf' ) . '")format("truetype"); }
*[data-ico-icon7stroke]:before{ font-family:Icon7Stroke;content:attr(data-ico-icon7stroke); }
.bt_bb_icon_preview.bt_bb_icon_preview_icon7stroke { font-family:Icon7Stroke; }

@font-face{ font-family:"AI";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/AI/AI.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/AI/AI.ttf' ) . '")format("truetype"); }
*[data-ico-ai]:before{ font-family:AI;content:attr(data-ico-ai); }
.bt_bb_icon_preview.bt_bb_icon_preview_ai { font-family:AI; }

@font-face{ font-family:"Artificial";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/Artificial/Artificial.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/Artificial/Artificial.ttf' ) . '")format("truetype"); }
*[data-ico-artificial]:before{ font-family:Artificial;content:attr(data-ico-artificial); }
.bt_bb_icon_preview.bt_bb_icon_preview_artificial { font-family:Artificial; }

@font-face{ font-family:"Chatbot";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/Chatbot/Chatbot.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/Chatbot/Chatbot.ttf' ) . '")format("truetype"); }
*[data-ico-chatbot]:before{ font-family:Chatbot;content:attr(data-ico-chatbot); }
.bt_bb_icon_preview.bt_bb_icon_preview_chatbot { font-family:Chatbot; }

@font-face{ font-family:"DeliveryBot";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/DeliveryBot/DeliveryBot.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/DeliveryBot/DeliveryBot.ttf' ) . '")format("truetype"); }
*[data-ico-deliverybot]:before{ font-family:DeliveryBot;content:attr(data-ico-deliverybot); }
.bt_bb_icon_preview.bt_bb_icon_preview_deliverybot { font-family:DeliveryBot; }

@font-face{ font-family:"IoniconsFilled";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/IoniconsFilled/IoniconsFilled.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/IoniconsFilled/IoniconsFilled.ttf' ) . '")format("truetype"); }
*[data-ico-ioniconsfilled]:before{ font-family:IoniconsFilled;content:attr(data-ico-ioniconsfilled); }
.bt_bb_icon_preview.bt_bb_icon_preview_ioniconsfilled { font-family:IoniconsFilled; }

@font-face{ font-family:"IoniconsLogos";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/IoniconsLogos/IoniconsLogos.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/IoniconsLogos/IoniconsLogos.ttf' ) . '")format("truetype"); }
*[data-ico-ioniconslogos]:before{ font-family:IoniconsLogos;content:attr(data-ico-ioniconslogos); }
.bt_bb_icon_preview.bt_bb_icon_preview_ioniconslogos { font-family:IoniconsLogos; }

@font-face{ font-family:"IoniconsOutline";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/IoniconsOutline/IoniconsOutline.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/IoniconsOutline/IoniconsOutline.ttf' ) . '")format("truetype"); }
*[data-ico-ioniconsoutline]:before{ font-family:IoniconsOutline;content:attr(data-ico-ioniconsoutline); }
.bt_bb_icon_preview.bt_bb_icon_preview_ioniconsoutline { font-family:IoniconsOutline; }

@font-face{ font-family:"IoniconsSharp";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/IoniconsSharp/IoniconsSharp.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/IoniconsSharp/IoniconsSharp.ttf' ) . '")format("truetype"); }
*[data-ico-ioniconssharp]:before{ font-family:IoniconsSharp;content:attr(data-ico-ioniconssharp); }
.bt_bb_icon_preview.bt_bb_icon_preview_ioniconssharp { font-family:IoniconsSharp; }

@font-face{ font-family:"MachineLearning";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/MachineLearning/MachineLearning.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/MachineLearning/MachineLearning.ttf' ) . '")format("truetype"); }
*[data-ico-machinelearning]:before{ font-family:MachineLearning;content:attr(data-ico-machinelearning); }
.bt_bb_icon_preview.bt_bb_icon_preview_machinelearning { font-family:MachineLearning; }

@font-face{ font-family:"RemixIconsBuildings";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsBuildings/RemixIconsBuildings.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsBuildings/RemixIconsBuildings.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconsbuildings]:before{ font-family:RemixIconsBuildings;content:attr(data-ico-remixiconsbuildings); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconsbuildings { font-family:RemixIconsBuildings; }

@font-face{ font-family:"RemixIconsBusiness";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsBusiness/RemixIconsBusiness.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsBusiness/RemixIconsBusiness.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconsbusiness]:before{ font-family:RemixIconsBusiness;content:attr(data-ico-remixiconsbusiness); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconsbusiness { font-family:RemixIconsBusiness; }

@font-face{ font-family:"RemixIconsCommunication";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsCommunication/RemixIconsCommunication.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsCommunication/RemixIconsCommunication.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconscommunication]:before{ font-family:RemixIconsCommunication;content:attr(data-ico-remixiconscommunication); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconscommunication { font-family:RemixIconsCommunication; }

@font-face{ font-family:"RemixIconsDesign";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsDesign/RemixIconsDesign.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsDesign/RemixIconsDesign.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconsdesign]:before{ font-family:RemixIconsDesign;content:attr(data-ico-remixiconsdesign); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconsdesign { font-family:RemixIconsDesign; }

@font-face{ font-family:"RemixIconsDevelopment";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsDevelopment/RemixIconsDevelopment.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsDevelopment/RemixIconsDevelopment.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconsdevelopment]:before{ font-family:RemixIconsDevelopment;content:attr(data-ico-remixiconsdevelopment); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconsdevelopment { font-family:RemixIconsDevelopment; }

@font-face{ font-family:"RemixIconsDevice";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsDevice/RemixIconsDevice.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsDevice/RemixIconsDevice.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconsdevice]:before{ font-family:RemixIconsDevice;content:attr(data-ico-remixiconsdevice); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconsdevice { font-family:RemixIconsDevice; }

@font-face{ font-family:"RemixIconsDocument";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsDocument/RemixIconsDocument.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsDocument/RemixIconsDocument.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconsdocument]:before{ font-family:RemixIconsDocument;content:attr(data-ico-remixiconsdocument); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconsdocument { font-family:RemixIconsDocument; }

@font-face{ font-family:"RemixIconsEditor";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsEditor/RemixIconsEditor.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsEditor/RemixIconsEditor.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconseditor]:before{ font-family:RemixIconsEditor;content:attr(data-ico-remixiconseditor); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconseditor { font-family:RemixIconsEditor; }

@font-face{ font-family:"RemixIconsFinance";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsFinance/RemixIconsFinance.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsFinance/RemixIconsFinance.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconsfinance]:before{ font-family:RemixIconsFinance;content:attr(data-ico-remixiconsfinance); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconsfinance { font-family:RemixIconsFinance; }

@font-face{ font-family:"RemixIconsHealth";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsHealth/RemixIconsHealth.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsHealth/RemixIconsHealth.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconshealth]:before{ font-family:RemixIconsHealth;content:attr(data-ico-remixiconshealth); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconshealth { font-family:RemixIconsHealth; }

@font-face{ font-family:"RemixIconsLogos";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsLogos/RemixIconsLogos.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsLogos/RemixIconsLogos.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconslogos]:before{ font-family:RemixIconsLogos;content:attr(data-ico-remixiconslogos); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconslogos { font-family:RemixIconsLogos; }

@font-face{ font-family:"RemixIconsMap";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsMap/RemixIconsMap.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsMap/RemixIconsMap.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconsmap]:before{ font-family:RemixIconsMap;content:attr(data-ico-remixiconsmap); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconsmap { font-family:RemixIconsMap; }

@font-face{ font-family:"RemixIconsMedia";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsMedia/RemixIconsMedia.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsMedia/RemixIconsMedia.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconsmedia]:before{ font-family:RemixIconsMedia;content:attr(data-ico-remixiconsmedia); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconsmedia { font-family:RemixIconsMedia; }

@font-face{ font-family:"RemixIconsOthers";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsOthers/RemixIconsOthers.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsOthers/RemixIconsOthers.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconsothers]:before{ font-family:RemixIconsOthers;content:attr(data-ico-remixiconsothers); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconsothers { font-family:RemixIconsOthers; }

@font-face{ font-family:"RemixIconsSystem";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsSystem/RemixIconsSystem.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsSystem/RemixIconsSystem.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconssystem]:before{ font-family:RemixIconsSystem;content:attr(data-ico-remixiconssystem); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconssystem { font-family:RemixIconsSystem; }

@font-face{ font-family:"RemixIconsUser";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsUser/RemixIconsUser.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsUser/RemixIconsUser.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconsuser]:before{ font-family:RemixIconsUser;content:attr(data-ico-remixiconsuser); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconsuser { font-family:RemixIconsUser; }

@font-face{ font-family:"RemixIconsWeather";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsWeather/RemixIconsWeather.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/RemixIconsWeather/RemixIconsWeather.ttf' ) . '")format("truetype"); }
*[data-ico-remixiconsweather]:before{ font-family:RemixIconsWeather;content:attr(data-ico-remixiconsweather); }
.bt_bb_icon_preview.bt_bb_icon_preview_remixiconsweather { font-family:RemixIconsWeather; }

@font-face{ font-family:"Services";src:url("' . get_parent_theme_file_uri( 'assets/icon-sets/Services/Services.woff' ) . '")format("woff"),url("' . get_parent_theme_file_uri( 'assets/icon-sets/Services/Services.ttf' ) . '")format("truetype"); }
*[data-ico-services]:before{ font-family:Services;content:attr(data-ico-services); }
.bt_bb_icon_preview.bt_bb_icon_preview_services { font-family:Services; }', array() );