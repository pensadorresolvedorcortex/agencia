<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(

	'chatbot_01 (Chatbot set)' => $set . '_e900',
	'chatbot_02 (Chatbot set)' => $set . '_e901',
	'chatbot_03 (Chatbot set)' => $set . '_e902',
	'chatbot_04 (Chatbot set)' => $set . '_e903',
	'chatbot_05 (Chatbot set)' => $set . '_e904',
	'chatbot_06 (Chatbot set)' => $set . '_e905',
	'chatbot_07 (Chatbot set)' => $set . '_e906',
	'chatbot_08 (Chatbot set)' => $set . '_e907',
	'chatbot_09 (Chatbot set)' => $set . '_e908',
	'chatbot_10 (Chatbot set)' => $set . '_e909',
	'chatbot_11 (Chatbot set)' => $set . '_e90a',
	'chatbot_12 (Chatbot set)' => $set . '_e90b',
	'chatbot_13 (Chatbot set)' => $set . '_e90c',
	'chatbot_14 (Chatbot set)' => $set . '_e90d',
	'chatbot_15 (Chatbot set)' => $set . '_e90e',
	'chatbot_16 (Chatbot set)' => $set . '_e90f'
);