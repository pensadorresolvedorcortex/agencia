<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'deliverybot_02 (DeliveryBot set)' => $set . '_e900',
	'deliverybot_03 (DeliveryBot set)' => $set . '_e901',
	'deliverybot_04 (DeliveryBot set)' => $set . '_e902',
	'deliverybot_05 (DeliveryBot set)' => $set . '_e903',
	'deliverybot_06 (DeliveryBot set)' => $set . '_e904',
	'deliverybot_07 (DeliveryBot set)' => $set . '_e905',
	'deliverybot_08 (DeliveryBot set)' => $set . '_e906',
	'deliverybot_09 (DeliveryBot set)' => $set . '_e907',
	'deliverybot_10 (DeliveryBot set)' => $set . '_e908',
	'deliverybot_01 (DeliveryBot set)' => $set . '_e909'
);
