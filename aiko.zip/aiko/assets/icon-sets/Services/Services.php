<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(

	'services_01 (Services set)' => $set . '_e900',
	'services_02 (Services set)' => $set . '_e901',
	'services_03 (Services set)' => $set . '_e902',
	'services_04 (Services set)' => $set . '_e903',
	'services_05 (Services set)' => $set . '_e904',
	'services_06 (Services set)' => $set . '_e905',
	'services_07 (Services set)' => $set . '_e906',
	'services_08 (Services set)' => $set . '_e907',
	'services_09 (Services set)' => $set . '_e908',
	'services_10 (Services set)' => $set . '_e909',
	'services_11 (Services set)' => $set . '_e90a',
	'services_12 (Services set)' => $set . '_e90b',
	'services_13 (Services set)' => $set . '_e90c',
	'services_14 (Services set)' => $set . '_e90d',
	'services_15 (Services set)' => $set . '_e90e',
	'services_16 (Services set)' => $set . '_e90f'
);
