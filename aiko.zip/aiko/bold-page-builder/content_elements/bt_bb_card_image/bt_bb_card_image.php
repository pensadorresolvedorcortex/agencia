<?php

class bt_bb_card_image extends BT_BB_Element {

	function handle_shortcode( $atts, $content ) {
		extract( shortcode_atts( apply_filters( 'bt_bb_extract_atts', array(
			'image'      					=> '',
			'size'							=> '',

			'url'    						=> '',
			'target' 						=> '',
			
			'color_scheme' 					=> '',
			'hover_color_scheme' 			=> '',
			'hover_style' 					=> '',
			'background_color'   			=> '',
			'padding'                		=> '',
			'shape'							=> '',
			'shadow'						=> '',
			'blur'							=> '',
			'style'							=> '',
			'border_color'					=> ''
		) ), $atts, $this->shortcode ) );
		
		$class = array( $this->shortcode );
		$data_override_class = array();

		if ( $el_class != '' ) {
			$class[] = $el_class;
		}

		$id_attr = '';
		if ( $el_id != '' ) {
			$id_attr = ' ' . 'id="' . esc_attr( $el_id ) . '"';
		}

		if ( $url != '' ) {
			$class[] = 'btWithLink';
		}

		if ( $shadow != '' ) {
			$class[] = $this->prefix . 'shadow' . '_' . $shadow;
		}

		if ( $blur != '' ) {
			$class[] = $this->prefix . 'blur' . '_' . $blur;
		}

		if ( $border_color != '' ) {
			$class[] = $this->prefix . 'border_color' . '_' . $border_color;
		}

		if ( $style != '' ) {
			$class[] = $this->prefix . 'style' . '_' . $style;
		}

		$el_inner_style = '';
		if ( $background_color != '' ) {
			$el_style = $el_style . 'background-color:' . $background_color . ';';
			//$el_inner_style = $el_inner_style . 'background-color:' . $background_color . ';';
		}

		$this->responsive_data_override_class(
			$class, $data_override_class,
			array(
				'prefix' => $this->prefix,
				'param' => 'padding',
				'value' => $padding
			)
		);
		
		$color_scheme_id = NULL;
		if ( is_numeric ( $color_scheme ) ) {
			$color_scheme_id = $color_scheme;
		} else if ( $color_scheme != '' ) {
			$color_scheme_id = bt_bb_get_color_scheme_id( $color_scheme );
		}
		$color_scheme_colors = bt_bb_get_color_scheme_colors_by_id( $color_scheme_id - 1 );
		if ( $color_scheme_colors ) $el_style .= '; --card-image-primary-color:' . $color_scheme_colors[0] . '; --card-image-secondary-color:' . $color_scheme_colors[1] . ';';
		if ( $color_scheme != '' ) $class[] = $this->prefix . 'color_scheme_' .  $color_scheme_id;

		$hover_color_scheme_id = NULL;
		if ( is_numeric ( $hover_color_scheme ) ) {
			$hover_color_scheme_id = $hover_color_scheme;
		} else if ( $hover_color_scheme != '' ) {
			$hover_color_scheme_id = bt_bb_get_color_scheme_id( $hover_color_scheme );
		}
		$hover_color_scheme_colors = bt_bb_get_color_scheme_colors_by_id( $hover_color_scheme_id - 1 );
		if ( $hover_color_scheme_colors ) $el_style .= '; --hover-card-image-primary-color:' . $hover_color_scheme_colors[0] . '; --hover-card-image-secondary-color:' . $hover_color_scheme_colors[1] . ';';
		if ( $hover_color_scheme != '' ) $class[] = $this->prefix . 'hover_color_scheme_' .  $hover_color_scheme_id;


		if ( $shape != '' ) {
			$class[] = $this->prefix . 'shape' . '_' . $shape;
		}

		if ( $hover_style != '' ) {
			$class[] = $this->prefix . 'hover_style' . '_' . $hover_style;
		}

		$content = do_shortcode( $content );

		$link = bt_bb_get_permalink_by_slug( $url );

		$class = apply_filters( $this->shortcode . '_class', $class, $atts );
		$class_attr = implode( ' ', $class );

		if ( $el_class != '' ) {
			$class_attr = $class_attr . ' ' . $el_class;
		}

		$inner_style_attr = '';
		if ( $el_inner_style != '' ) {
			$inner_style_attr = ' ' . 'style="' . esc_attr( $el_inner_style ) . '"';
		}

		$style_attr = '';
		if ( $el_style != '' ) {
			$style_attr = ' ' . 'style="' . esc_attr( $el_style ) . '"';
		}

		$output = '<div' . $id_attr . ' class="' . esc_attr( $class_attr ) . '" ' . $style_attr . ' data-bt-override-class="' . htmlspecialchars( json_encode( $data_override_class, JSON_FORCE_OBJECT ), ENT_QUOTES, 'UTF-8' ) . '">';

			// LINK
			if ( $link != '' ) {
				$target_attr = ' target="_self" ';
				if ( $target != '' ) {
					$target_attr = ' ' . 'target="' . esc_attr( $target ) . '"';
				}
				$output .= '<a href="' . esc_url( $link ) . '" ' . $target_attr . ' class="btCardLink"></a>';
			}

			// IMAGE
			if ( $image != '' ) {
				$output .=  '<div class="' . esc_attr( $this->shortcode . '_image') . '">' . do_shortcode( '[bt_bb_image image="' . esc_attr( $image ) . '" size="' . esc_attr( $size ) . '" lazy_load="no" ignore_fe_editor="true"]' ) . '</div>';
			} else {
				$output .= '<img src="' . BT_BB_Root::$path . 'img/placeholder3.png" alt="' . esc_html__( 'Placeholder image', 'aiko' ) . '" title="' . esc_html__( 'Placeholder image', 'aiko' ) . '">';
			}

			// TEXT BOX
			$output .= '<div class="' . esc_attr( $this->shortcode . '_text_box' ) . '" ' . $inner_style_attr . '>';

				// INNER CONTENT
				if ( $content != '' ) $output .= '<div class="' . esc_attr( $this->shortcode . '_content_inner' ) . '">' . ( $content ) . '</div>';

			$output .= '</div>';


		$output .= '</div>';

		$output = apply_filters( 'bt_bb_general_output', $output, $atts );
		$output = apply_filters( $this->shortcode . '_output', $output, $atts );

		return $output;

	}

	function map_shortcode() {

		$color_scheme_arr = bt_bb_get_color_scheme_param_array();
		
		bt_bb_map( $this->shortcode, array( 'name' => esc_html__( 'Card Image', 'aiko' ), 'description' => esc_html__( 'Card with image and text', 'aiko' ), 'icon' => $this->prefix_backend . 'icon' . '_' . $this->shortcode, 'container' => 'vertical', 'toggle' => true, 'accept' => array( 'bt_bb_button' => true,'bt_bb_image' => true,  'bt_bb_service' => true, 'bt_bb_headline' => true, 'bt_bb_icon' => true, 'bt_bb_text' => true, 'bt_bb_separator' => true, 'bt_bb_working_hours' => true ),
			'params' => array(
				array( 'param_name' => 'image', 'type' => 'attach_image', 'preview' => true, 'heading' => esc_html__( 'Image', 'aiko' ) 
				),
				array( 'param_name' => 'size', 'type' => 'dropdown', 'heading' => esc_html__( 'Image size', 'aiko' ), 
					'value' => bt_bb_get_image_sizes()
				),
				array( 'param_name' => 'padding', 'type' => 'dropdown', 'default' => '', 'heading' => esc_html__( 'Content padding', 'aiko' ), 'preview' => true, 'responsive_override' => true,
					'value' => array(
						esc_html__( 'Default', 'aiko' ) 			=> 'none',
						esc_html__( 'Text indent', 'aiko' ) 		=> 'text_indent',
						esc_html__( '0px', 'aiko' ) 				=> '0px',
						esc_html__( '5px', 'aiko' ) 				=> '5px',
						esc_html__( '10px', 'aiko' ) 			=> '10px',
						esc_html__( '15px', 'aiko' ) 			=> '15px',
						esc_html__( '20px', 'aiko' ) 			=> '20px',
						esc_html__( '25px', 'aiko' ) 			=> '25px',
						esc_html__( '30px', 'aiko' ) 			=> '30px',
						esc_html__( '35px', 'aiko' ) 			=> '35px',
						esc_html__( '40px', 'aiko' ) 			=> '40px',
						esc_html__( '45px', 'aiko' ) 			=> '45px',
						esc_html__( '50px', 'aiko' ) 			=> '50px',
						esc_html__( '55px', 'aiko' ) 			=> '55px',
						esc_html__( '60px', 'aiko' ) 			=> '60px',
						esc_html__( '65px', 'aiko' ) 			=> '65px',
						esc_html__( '70px', 'aiko' ) 			=> '70px',
						esc_html__( '75px', 'aiko' ) 			=> '75px',
						esc_html__( '80px', 'aiko' ) 			=> '80px',
						esc_html__( '85px', 'aiko' ) 			=> '85px',
						esc_html__( '90px', 'aiko' ) 			=> '90px',
						esc_html__( '95px', 'aiko' ) 			=> '95px',
						esc_html__( '100px', 'aiko' ) 			=> '100px'
					)
				),


				array( 'param_name' => 'url', 'type' => 'link', 'heading' => esc_html__( 'URL', 'aiko' ), 'preview' => true, 'description' => esc_html__( 'Enter full or local URL (e.g. https://www.bold-themes.com or /pages/about-us), post slug (e.g. about-us).', 'aiko' ), 'group' => esc_html__( 'URL', 'aiko' ) ),
				array( 'param_name' => 'target', 'type' => 'dropdown', 'group' => esc_html__( 'URL', 'aiko' ), 'heading' => esc_html__( 'Target', 'aiko' ),
					'value' => array(
						esc_html__( 'Self (open in same tab)', 'aiko' ) 	=> '_self',
						esc_html__( 'Blank (open in new tab)', 'aiko' ) 	=> '_blank',
					)
				),
				
				array( 'param_name' => 'style', 'type' => 'dropdown', 'default' => 'borderless', 'heading' => esc_html__( 'Style', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Filled', 'aiko' ) 					=> '',
						esc_html__( 'Filled with border', 'aiko' ) 		=> 'filled_border',
						esc_html__( 'Outline', 'aiko' ) 					=> 'outline'
					)
				),
				array( 'param_name' => 'shape', 'type' => 'dropdown', 'heading' => esc_html__( 'Shape', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Inherit', 'aiko' ) 					=> '',
						esc_html__( 'Square', 'aiko' ) 					=> 'square',
						esc_html__( 'Soft Rounded', 'aiko' ) 			=> 'soft-rounded',
						esc_html__( 'Hard Rounded', 'aiko' ) 			=> 'hard-rounded',
						esc_html__( 'Very Hard Rounded', 'aiko' ) 		=> 'very-hard-rounded'
					) 
				),
				array( 'param_name' => 'shadow', 'type' => 'dropdown', 'heading' => esc_html__( 'Shadow', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Hide', 'aiko' ) 								=> '',
						esc_html__( 'Always visible', 'aiko' ) 						=> 'show',
						esc_html__( 'Always visible, move up on hover', 'aiko' ) 	=> 'visible_move',
						esc_html__( 'Show on hover', 'aiko' ) 						=> 'on_hover',
						esc_html__( 'Show & zoom image on hover', 'aiko' ) 			=> 'on_hover_zoom',
						esc_html__( 'Show & move up on hover', 'aiko' ) 				=> 'move_up',
						esc_html__( 'Show, move up & zoom image on hover', 'aiko' ) 	=> 'move_up_zoom'
					)
				),
				array( 'param_name' => 'blur', 'type' => 'dropdown', 'heading' => esc_html__( 'Blur', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'No', 'aiko' ) 					=> '',
						esc_html__( 'Yes', 'aiko' ) 					=> 'show'
					)
				),
				array( 'param_name' => 'color_scheme', 'type' => 'dropdown', 'heading' => esc_html__( 'Color scheme', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ), 'value' => $color_scheme_arr, 'preview' => true ),
				array( 'param_name' => 'hover_color_scheme', 'type' => 'dropdown', 'heading' => esc_html__( 'Hover color scheme', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ), 'value' => $color_scheme_arr, 'preview' => true ),
				array( 'param_name' => 'hover_style', 'type' => 'dropdown', 'heading' => esc_html__( 'Hover style', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Solid', 'aiko' ) 						=> '',
						esc_html__( 'Gradient', 'aiko' ) 					=> 'gradient'
					)
				),
				array( 'param_name' => 'background_color', 'preview' => true, 'type' => 'colorpicker', 'heading' => esc_html__( 'Background color', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ) ),
				array( 'param_name' => 'border_color', 'type' => 'dropdown', 'heading' => esc_html__( 'Border color', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Gray color', 'aiko' ) 							=> '',
						esc_html__( 'Accent color', 'aiko' ) 						=> 'accent',
						esc_html__( 'Alternate color', 'aiko' ) 						=> 'alternate',
						esc_html__( 'Light color', 'aiko' ) 							=> 'light',
						esc_html__( 'Dark color', 'aiko' ) 							=> 'dark'
					)
				),
			))
		);
	}
}