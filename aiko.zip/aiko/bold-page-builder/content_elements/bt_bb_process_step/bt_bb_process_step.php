<?php
class bt_bb_process_step extends BT_BB_Element {

	function handle_shortcode( $atts, $content ) {
		extract( shortcode_atts( apply_filters( 'bt_bb_extract_atts_' . $this->shortcode, array(
			'title'						=> '',
			'text'						=> '',
			'icon'						=> ''
		) ), $atts, $this->shortcode ) );
		
		wp_enqueue_script(
			'bt_bb_process_step',
			get_template_directory_uri() . '/bold-page-builder/content_elements/bt_bb_process_step/bt_bb_process_step.js',
			array( 'jquery' ),
			'',
			true
		);
		
		$title = html_entity_decode( $title, ENT_QUOTES, 'UTF-8' );
		$text  = html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );
		
		$title = nl2br( $title );
		$text = nl2br( $text );	
		
		$class = array( $this->shortcode );
		
		if ( $el_class != '' ) {
			$class[] = $el_class;
		}
		
		$id_attr = '';
		if ( $el_id != '' ) {
			$id_attr = ' ' . 'id="' . esc_attr( $el_id ) . '"';
		}
		
		$style_attr = '';
		if ( $el_style != '' ) {
			$style_attr = ' ' . 'style="' . esc_attr( $el_style ) . '"';
		}
		
		$class[] = 'bt_bb_process_step_item_count';
		
		$class = apply_filters( $this->shortcode . '_class', $class, $atts );
		
		$output = '';
	
		// ICON
		if ( $icon != '' ) $output .= '<div class="' . esc_attr( $this->shortcode . '_icon' ) . '">' . do_shortcode( '[bt_bb_icon icon="' . esc_attr( $icon ) . '" size="small" style="outline" shape="circle" ignore_fe_editor="true"]' ) . '</div>';
		
		// TITLE
		if ( $title != '' ) {
			$title = '<h4 class="' . esc_attr( $this->shortcode ) . '_title">' . $title . '</h4>';	
		}

		// TEXT
		if ( $text != '' ) {
			$text = '<span class="' . esc_attr( $this->shortcode ) . '_text">' . $text . '</span>';	
		}
		
		$output = '<div' . $id_attr . ' class="' . implode( ' ', $class ) . '"' . $style_attr . '>' . $output . '<div class="' . esc_attr( $this->shortcode ) . '_content">'. $title . $text . '</div></div>';
		
		$output = apply_filters( 'bt_bb_general_output', $output, $atts );
		$output = apply_filters( $this->shortcode . '_output', $output, $atts );
		
		return $output;
		
	}
	
	function map_shortcode() {
		
		bt_bb_map( $this->shortcode, array( 'name' => esc_html__( 'Process step', 'aiko' ), 
			'as_child' => array( 'only' => 'bt_bb_process' ), 
			'description' => esc_html__( 'Process step', 'aiko' ),'accept' => array( 'bt_bb_section' => false, 'bt_bb_row' => false, 'bt_bb_column' => false, 'bt_bb_column_inner' => false, 'bt_bb_tabs' => false, 'bt_bb_tab_item' => false, 'bt_bb_accordion' => false, 'bt_bb_accordion_item' => false, 'bt_bb_cost_calculator_item' => false, 'bt_cc_group' => false, 'bt_cc_multiply' => false, 'bt_cc_item' => false, 'bt_bb_content_slider_item' => false, 'bt_bb_google_maps_location' => false, '_content' => false ),'accept_all' => true, 'icon' => $this->prefix_backend . 'icon' . '_' . $this->shortcode,
			'params' => array(
				array( 'param_name' => 'icon', 'type' => 'iconpicker', 'heading' => esc_html__( 'Icon', 'aiko' ), 'preview' => true ),
				array( 'param_name' => 'title', 'type' => 'textfield', 'heading' => esc_html__( 'Title', 'aiko' ), 'preview' => true ),
				array( 'param_name' => 'text', 'type' => 'textarea', 'heading' => esc_html__( 'Text', 'aiko' ) ),
			)
		) );
	}
}



