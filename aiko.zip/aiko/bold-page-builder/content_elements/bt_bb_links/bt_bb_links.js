(function( $ ) {
	"use strict";
	$( '.bt_bb_link_item_text' ).click(function() {
		var $item = $( this ).closest( '.bt_bb_link_item' );
		if ( ! $item.hasClass('on') ) {
			$( this ).closest( '.bt_bb_links' ).find( '.bt_bb_link_item.on' ).removeClass( 'on' );
			$item.addClass( 'on' );
			if( ! window.initiallinks ){
				    
				var top_of_element = $item.offset().top;
				var bottom_of_element = $item.offset().top + $("#element").outerHeight();
				var bottom_of_screen = $( window ).scrollTop() + $(window).innerHeight();
				var top_of_screen = $( window ).scrollTop();
				var diff = top_of_screen - top_of_element;
				if( diff > 0 ) {
					$( 'html' ).scrollTop( $( 'html' ).scrollTop() - diff - 15 );
				}

			} else {
				window.initiallinks = false;
			}
		
		} else {
			$( this ).closest( '.bt_bb_link_item' ).removeClass( 'on' );
		}
	});
	$( '.bt_bb_links' ).each(function() {
		if ( $( this ).data( 'closed' ) != 'closed' ) {
			window.initiallinks = true;
			$( this ).find( '.bt_bb_link_item_text' ).first().click();
		}
	});
})( jQuery );