<?php

class bt_bb_links extends BT_BB_Element {

	function handle_shortcode( $atts, $content ) {
		extract( shortcode_atts( apply_filters( 'bt_bb_extract_atts_' . $this->shortcode, array(
			'supertitle'				=> '',
			'title_font_weight'			=> '',
			'button_text'				=> '',
			'icon'						=> '',
			'icon_position'				=> '',
			'url'						=> '',
			'target' 					=> '',
			'button_color_scheme' 		=> ''
			
		) ), $atts, $this->shortcode ) );
		
		$class = array( $this->shortcode );

		wp_enqueue_script(
			'bt_bb_links',
			get_template_directory_uri() . '/bold-page-builder/content_elements/bt_bb_links/bt_bb_links.js',
			array( 'jquery' ),
			'',
			true
		);
		
		if ( $el_class != '' ) {
			$class[] = $el_class;
		}
		
		$id_attr = '';
		if ( $el_id != '' ) {
			$id_attr = ' ' . 'id="' . esc_attr( $el_id ) . '"';
		}

		if ( $title_font_weight != '' ) {
			$class[] = $this->prefix . 'title_font_weight' . '_' . $title_font_weight;
		}

		if ( $supertitle == '' ) {
			$class[] = 'bt_bb_no_supertitle';
		}

		$class = apply_filters( $this->shortcode . '_class', $class, $atts );
		$class_attr = implode( ' ', $class );

		if ( $el_class != '' ) {
			$class_attr = $class_attr . ' ' . $el_class;
		}

		$style_attr = '';
		if ( $el_style != '' ) {
			$style_attr = ' ' . 'style="' . esc_attr( $el_style ) . '"';
		}

		$content = do_shortcode( $content );

		$output = '<div' . $id_attr . ' class="' . esc_attr( $class_attr ) . '" ' . $style_attr . ' >';

			if ( $supertitle != '' ) $output .= '<div class="' . esc_attr( $this->shortcode . '_supertitle' ) . '"><span>' . $supertitle . '</span></div>';

			$output .=  '<div class="' . esc_attr( $this->shortcode . '_items_box') . '">' . $content . '</div>';

			$output .=  '<div class="' . esc_attr( $this->shortcode . '_image_box') . '"></div>';

			if ( $button_text != '' ) $output .= '<div class="' . esc_attr( $this->shortcode . '_button' ) . '">' . do_shortcode( '[bt_bb_button text="' . esc_attr( $button_text ) . '" icon="' . esc_attr( $icon ) . '" url="' . esc_attr( $url ) . '" target="' . esc_attr( $target ) . '" color_scheme="' . esc_attr( $button_color_scheme ) . '" size="medium" style="outline" icon_position="' . esc_attr( $icon_position ) . '" shape="inherit" ignore_fe_editor="true"]' ) . '</div>';

		$output .= '</div>';
		
		$output = apply_filters( 'bt_bb_general_output', $output, $atts );
		$output = apply_filters( $this->shortcode . '_output', $output, $atts );

		return $output;

	}
	
	function map_shortcode() {

		$color_scheme_arr = bt_bb_get_color_scheme_param_array();

		bt_bb_map( $this->shortcode, array( 'name' => esc_html__( 'Links', 'aiko' ), 'description' => esc_html__( 'Links', 'aiko' ), 'container' => 'vertical', 
			'auto_add' => 'bt_bb_link_item', 'accept' => array( 'bt_bb_link_item' => true ), 'icon' => $this->prefix_backend . 'icon' . '_' . $this->shortcode,
			'params' => array(
				array( 'param_name' => 'supertitle', 'type' => 'textfield', 'heading' => esc_html__( 'Supertitle', 'aiko' ), 'preview' => true ),
				array( 'param_name' => 'title_font_weight', 'type' => 'dropdown', 'heading' => esc_html__( 'Title font weight', 'aiko' ),  
					'value' => array(
						esc_html__( 'Default', 'aiko' ) 		=> '',
						esc_html__( 'Normal', 'aiko' ) 		=> 'normal',
						esc_html__( 'Bold', 'aiko' ) 		=> 'bold',
						esc_html__( 'Bolder', 'aiko' ) 		=> 'bolder',
						esc_html__( 'Lighter', 'aiko' ) 		=> 'lighter',
						esc_html__( 'Light', 'aiko' ) 		=> 'light',
						esc_html__( 'Thin', 'aiko' ) 		=> 'thin',
						esc_html__( '100', 'aiko' ) 			=> '100',
						esc_html__( '200', 'aiko' ) 			=> '200',
						esc_html__( '300', 'aiko' ) 			=> '300',
						esc_html__( '400', 'aiko' ) 			=> '400',
						esc_html__( '500', 'aiko' ) 			=> '500',
						esc_html__( '600', 'aiko' ) 			=> '600',
						esc_html__( '700', 'aiko' ) 			=> '700',
						esc_html__( '800', 'aiko' ) 			=> '800',
						esc_html__( '900', 'aiko' ) 			=> '900'
					)
				),

				array( 'param_name' => 'button_text', 'type' => 'textfield', 'heading' => esc_html__( 'Button text', 'aiko' ), 'group' => esc_html__( 'Button', 'aiko' ) ),
				array( 'param_name' => 'icon', 'type' => 'iconpicker', 'heading' => esc_html__( 'Icon', 'aiko' ), 'group' => esc_html__( 'Button', 'aiko' ) ),
				array( 'param_name' => 'icon_position', 'type' => 'dropdown', 'heading' => esc_html__( 'Icon Position', 'aiko' ), 'group' => esc_html__( 'Button', 'aiko' ),
					'value' => array(
						esc_html__( 'Left', 'aiko' ) 	=> 'left',
						esc_html__( 'Right', 'aiko' ) 	=> 'right'
					)
				),
				array( 'param_name' => 'url', 'type' => 'link', 'heading' => esc_html__( 'Button URL', 'aiko' ), 'preview' => true, 'description' => esc_html__( 'Enter full or local URL (e.g. https://www.bold-themes.com or /pages/about-us), post slug (e.g. about-us).', 'aiko' ), 'group' => esc_html__( 'Button', 'aiko' ) ),
				array( 'param_name' => 'target', 'type' => 'dropdown', 'group' => esc_html__( 'Button', 'aiko' ), 'heading' => esc_html__( 'Target', 'aiko' ),
					'value' => array(
						esc_html__( 'Self (open in same tab)', 'aiko' ) 	=> '_self',
						esc_html__( 'Blank (open in new tab)', 'aiko' ) 	=> '_blank',
					)
				),
				array( 'param_name' => 'button_color_scheme', 'type' => 'dropdown', 'heading' => esc_html__( 'Button color scheme', 'aiko' ), 'group' => esc_html__( 'Button', 'aiko' ), 'value' => $color_scheme_arr ),
			)
		) );
	} 
}