<?php

class bt_bb_latest_posts extends BT_BB_Element {

	function handle_shortcode( $atts, $content ) {
		extract( shortcode_atts( apply_filters( 'bt_bb_extract_atts_' . $this->shortcode, array(
			'rows'            	=> '',
			'columns'         	=> '',
			'gap'             	=> '',
			'category'        	=> '',
			'target'          	=> '',
			'image_shape'     	=> '',
			'show_category'   	=> '',
			'show_date'       	=> '',
			'show_author'     	=> '',
			'show_comments'   	=> '',
			'show_excerpt'    	=> '',
			'lazy_load'  		=> 'no',
			'title_lines'		=> '',
			'excerpt_lines'		=> '',
			'title_font_weight'	=> ''
		) ), $atts, $this->shortcode ) );
		
		$class = array( $this->shortcode );
		
		if ( $el_class != '' ) {
			$class[] = $el_class;
		}	
		
		$id_attr = '';
		if ( $el_id != '' ) {
			$id_attr = ' ' . 'id="' . esc_attr( $el_id ) . '"';
		}

		$style_attr = '';
		$el_style = apply_filters( $this->shortcode . '_style', $el_style, $atts );
		if ( $el_style != '' ) {
			$style_attr = ' ' . 'style="' . esc_attr( $el_style ) . '"';
		}
		
		if ( $columns != '' ) {
			$class[] = $this->prefix . 'columns' . '_' . $columns;
		}
		
		if ( $gap != '' ) {
			$class[] = $this->prefix . 'gap' . '_' . $gap;
		}

		if ( $show_date != '' ) {
			$class[] = $this->prefix . 'show_date' . '_' . $show_date;
		}
		
		if ( $image_shape != '' ) {
			$class[] = $this->prefix . 'image_shape' . '_' . $image_shape;
		}

		if ( $title_font_weight != '' ) {
			$class[] = $this->prefix . 'title_font_weight' . '_' . $title_font_weight;
		}

		if ( $title_lines != '' ) {
			$class[] = $this->prefix . 'title_lines' . '_' . $title_lines;
		}

		if ( $excerpt_lines != '' ) {
			$class[] = $this->prefix . 'excerpt_lines' . '_' . $excerpt_lines;
		}

		do_action( $this->shortcode . '_before_extra_responsive_param' );
		foreach ( $this->extra_responsive_data_override_param as $p ) {
			if ( ! is_array( $atts ) || ! array_key_exists( $p, $atts ) ) continue;
			$this->responsive_data_override_class(
				$class, $data_override_class,
				apply_filters( $this->shortcode . '_responsive_data_override', array(
					'prefix' => $this->prefix,
					'param' => $p,
					'value' => $atts[ $p ],
				) )
			);
		}
		
		$class = apply_filters( $this->shortcode . '_class', $class, $atts );
		
		$number = (int)$rows * (int)$columns;
		
		$posts = bt_bb_get_posts( $number, 0, $category );
		
		$output = '';

		foreach( $posts as $post_item ) {

			$output .= '<div class="' . esc_attr( $this->shortcode ) . '_item">';

				// DATE
				if ( $show_date != '' ) {
					$output .= '<span class="' . esc_attr( $this->shortcode ) . '_item_date">';
						$output .= get_the_date( '', $post_item['ID'] );
					$output .= '</span>';
				}

				$post_thumbnail_id = get_post_thumbnail_id( $post_item['ID'] );

				if ( $post_thumbnail_id != '' ) {
					$img = wp_get_attachment_image_src( $post_thumbnail_id, $size = 'medium' );

						if ( $image_shape == 'rounded_square' ) {
							$img = wp_get_attachment_image_src( $post_thumbnail_id, $size = 'boldthemes_medium_square' );
						}
					$img_src = BT_BB_Root::$path . 'img/blank.gif';
					$data_img = '';
					if ( $lazy_load == 'yes' ) {
						$img_class = 'btLazyLoadImage';
						if ( $img ) {
							$data_img = ' data-image_src="' . esc_attr( $img[0] ) . '"';
						}
					} else {
						if ( $img ) {
							$img_src = $img[0];
						}
						$img_class = '';
					}
					$output .= '<div class="' . esc_attr( $this->shortcode ) . '_item_image"><a href="' . esc_url_raw( $post_item['permalink'] ) . '" target="' . esc_attr( $target ) . '"><img src="' . esc_url_raw( $img_src ) . '" alt="' . esc_attr( $post_item['title'] ) . '" title="' . esc_attr( $post_item['title'] ) . '" class="' . esc_attr( $img_class ) . '" ' . $data_img .  '"></a></div>';
				}

				$output .= '<div class="' . esc_attr( $this->shortcode ) . '_item_content">';

					// TITLE
					$output .= '<h5 class="' . esc_attr( $this->shortcode ) . '_item_title">';
						$output .= '<a href="' . esc_url_raw( $post_item['permalink'] ) . '" target="' . esc_attr( $target ) . '">' . $post_item['title'] . '</a>';
					$output .= '</h5>';
					
					// EXCERPT
					if ( $show_excerpt == 'show_excerpt' ) {
						$output .= '<div class="' . esc_attr( $this->shortcode ) . '_item_excerpt">';
							$output .= $post_item['excerpt'];
						$output .= '</div>';
					}

					// META DATA
					if ( $show_category == 'show_category' || $show_author == 'show_author' || $show_author == 'show_comments' ) {
						$meta_output = '<div class="' . esc_attr( $this->shortcode ) . '_item_meta">';

							if ( $show_category == 'show_category' ) {
								$meta_output .= '<div class="' . esc_attr( $this->shortcode ) . '_item_category">';
									$meta_output .= $post_item['category_list'];
								$meta_output .= '</div>';
							}

							if ( $show_author == 'show_author' ) {
								$meta_output .= '<span class="' . esc_attr( $this->shortcode ) . '_item_author">';
									$meta_output .= '' . $post_item['author'];
								$meta_output .= '</span>';
							}

							if ( $show_comments == 'show_comments' && $post_item['comments'] != '' ) {
								$meta_output .= '<span class="' . esc_attr( $this->shortcode ) . '_item_comments">';
									$meta_output .= $post_item['comments'];
								$meta_output .= '</span>';
							}
				
						$meta_output .= '</div>';
						$output .= $meta_output;
					}

				$output .= '</div>';
				
			$output .= '</div>';
		}

		$output = '<div' . $id_attr . ' class="' . esc_attr( implode( ' ', $class ) ) . '"' . $style_attr . '>' . $output . '</div>';
		
		$output = apply_filters( 'bt_bb_general_output', $output, $atts );
		$output = apply_filters( $this->shortcode . '_output', $output, $atts );

		return $output;

	}

	function map_shortcode() {

		bt_bb_map( $this->shortcode, array( 'name' => esc_html__( 'Latest Posts', 'aiko' ), 'description' => esc_html__( 'List of latest posts', 'aiko' ), 'icon' => $this->prefix_backend . 'icon' . '_' . $this->shortcode,
			'params' => array(
				array( 'param_name' => 'rows', 'type' => 'textfield', 'value' => '1', 'heading' => esc_html__( 'Rows', 'aiko' ), 'preview' => true ),
				array( 'param_name' => 'columns', 'type' => 'dropdown', 'value' => '3', 'heading' => esc_html__( 'Columns', 'aiko' ), 'preview' => true,
					'value' => array(
						esc_html__( '1', 'aiko' ) => '1',
						esc_html__( '2', 'aiko' ) => '2',
						esc_html__( '3', 'aiko' ) => '3',
						esc_html__( '4', 'aiko' ) => '4',
						esc_html__( '6', 'aiko' ) => '6'
					)
				),
				array( 'param_name' => 'gap', 'type' => 'dropdown', 'heading' => esc_html__( 'Gap', 'aiko' ), 'preview' => true,
					'value' => array(
						esc_html__( 'Normal', 'aiko' ) 	=> 'normal',
						esc_html__( 'No gap', 'aiko' ) 	=> 'no_gap',
						esc_html__( 'Small', 'aiko' ) 	=> 'small',
						esc_html__( 'Large', 'aiko' ) 	=> 'large'
					)
				),				
				array( 'param_name' => 'category', 'type' => 'textfield', 'heading' => esc_html__( 'Category', 'aiko' ), 'description' => esc_html__( 'Enter category slug or leave empty to show all', 'aiko' ), 'preview' => true ),
				array( 'param_name' => 'target', 'type' => 'dropdown', 'heading' => esc_html__( 'Target', 'aiko' ),
					'value' => array(
						esc_html__( 'Self (open in same tab)', 'aiko' ) 	=> '_self',
						esc_html__( 'Blank (open in new tab)', 'aiko' ) 	=> '_blank',
					)
				),
				

				array( 'param_name' => 'show_date', 'default' => '', 'type' => 'dropdown', 'heading' => esc_html__( 'Show date', 'aiko' ), 
					'value' => array(
						esc_html__( 'No', 'aiko' )					=> '',
						esc_html__( 'Show on top', 'aiko' )			=> 'show_date',
						esc_html__( 'Show below image', 'aiko' )		=> 'show_date_below'
					)
				),
				array( 'param_name' => 'show_category', 'type' => 'checkbox', 'value' => array( esc_html__( 'Yes', 'aiko' ) => 'show_category' ), 'heading' => esc_html__( 'Show category', 'aiko' ), 'preview' => true
				),
				
				array( 'param_name' => 'show_author', 'type' => 'checkbox', 'value' => array( esc_html__( 'Yes', 'aiko' ) => 'show_author' ), 'heading' => esc_html__( 'Show author', 'aiko' ), 'preview' => true
				),
				array( 'param_name' => 'show_comments', 'type' => 'checkbox', 'value' => array( esc_html__( 'Yes', 'aiko' ) => 'show_comments' ), 'heading' => esc_html__( 'Show number of comments', 'aiko' ), 'preview' => true
				),
				array( 'param_name' => 'show_excerpt', 'type' => 'checkbox', 'value' => array( esc_html__( 'Yes', 'aiko' ) => 'show_excerpt' ), 'heading' => esc_html__( 'Show excerpt', 'aiko' ), 'preview' => true
				),
				array( 'param_name' => 'lazy_load', 'type' => 'dropdown', 'default' => 'yes', 'heading' => esc_html__( 'Lazy load images', 'aiko' ),
					'value' => array(
						esc_html__( 'No', 'aiko' ) 		=> 'no',
						esc_html__( 'Yes', 'aiko' ) 	=> 'yes'
					)
				),


				array( 'param_name' => 'image_shape', 'type' => 'dropdown', 'group' => esc_html__( 'Design', 'aiko' ), 'heading' => esc_html__( 'Image shape', 'aiko' ),
					'value' => array(
						esc_html__( 'Square', 'aiko' ) 			=> 'square',
						esc_html__( 'Soft Rounded', 'aiko' ) 	=> 'rounded',
						esc_html__( 'Hard Rounded', 'aiko' ) 	=> 'round'
					)
				),
				array( 'param_name' => 'title_font_weight', 'type' => 'dropdown', 'group' => esc_html__( 'Design', 'aiko' ), 'heading' => esc_html__( 'Title font weight', 'aiko' ), 
					'value' => array(
						esc_html__( 'Default', 'aiko' ) 		=> '',
						esc_html__( 'Normal', 'aiko' ) 		=> 'normal',
						esc_html__( 'Bold', 'aiko' ) 		=> 'bold',
						esc_html__( 'Bolder', 'aiko' ) 		=> 'bolder',
						esc_html__( 'Lighter', 'aiko' ) 		=> 'lighter',
						esc_html__( 'Light', 'aiko' ) 		=> 'light',
						esc_html__( 'Thin', 'aiko' ) 		=> 'thin',
						esc_html__( '100', 'aiko' ) 			=> '100',
						esc_html__( '200', 'aiko' ) 			=> '200',
						esc_html__( '300', 'aiko' ) 			=> '300',
						esc_html__( '400', 'aiko' ) 			=> '400',
						esc_html__( '500', 'aiko' ) 			=> '500',
						esc_html__( '600', 'aiko' ) 			=> '600',
						esc_html__( '700', 'aiko' ) 			=> '700',
						esc_html__( '800', 'aiko' ) 			=> '800',
						esc_html__( '900', 'aiko' ) 			=> '900'
					)
				),
				array( 'param_name' => 'title_lines', 'default' => '', 'type' => 'dropdown', 'group' => esc_html__( 'Design', 'aiko' ), 'heading' => esc_html__( 'Title lines', 'aiko' ), 'description' => esc_html__( 'Limit and show 1, 2, 3 or 4 lines of post title', 'aiko' ), 
					'value' => array(
						esc_html__( 'All', 'aiko' )		=> '',
						esc_html__( '3', 'aiko' )		=> '3',
						esc_html__( '2', 'aiko' )		=> '2',
						esc_html__( '1', 'aiko' )		=> '1'
					)
				),
				array( 'param_name' => 'excerpt_lines', 'default' => '', 'type' => 'dropdown', 'group' => esc_html__( 'Design', 'aiko' ), 'heading' => esc_html__( 'Excerpt lines', 'aiko' ), 'description' => esc_html__( 'Limit and show 1, 2, 3 or 4 lines of post excerpt text', 'aiko' ), 
					'value' => array(
						esc_html__( '4', 'aiko' )		=> '',
						esc_html__( '3', 'aiko' )		=> '3',
						esc_html__( '2', 'aiko' )		=> '2',
						esc_html__( '1', 'aiko' )		=> '1'
					)
				),
				
			)
		) );
	} 
}