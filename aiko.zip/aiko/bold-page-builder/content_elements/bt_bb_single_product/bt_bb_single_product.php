<?php

class bt_bb_single_product extends BT_BB_Element {

	function handle_shortcode( $atts, $content ) {
		extract( shortcode_atts( apply_filters( 'bt_bb_extract_atts', array(
			'product_id'        		=> '',
			'product_image'      		=> '',
			'product_title'        		=> '',
			'product_price'      		=> '',
			'html_tag'					=> 'h4',
			'show_category'      		=> '',
			'show_button'      			=> '',
			'shape'						=> '',
			'title_font_weight'			=> '',
			'hover_background_color'	=> '#F2F2F2'
			
		) ), $atts, $this->shortcode ) );
		
		if ( class_exists( 'WooCommerce' ) && $product_id != '' ) {
			$product = wc_get_product( $product_id );
		} else {
			$product = false;
		}
		$product_exists = ( $product != false ) ? true : false;
		
		$class = array( $this->shortcode, 'woocommerce' );

		if ( !$product_exists ) {
			$class[] = "btNoWooProduct";
		}

		if ( $el_class != '' ) {
			$class[] = $el_class;
		}

		$id_attr = '';
		if ( $el_id != '' ) {
			$id_attr = ' ' . 'id="' . esc_attr( $el_id ) . '"';
		}

		$background_el_style = '';
		if ( $hover_background_color != '' ) {
			$background_el_style = $background_el_style . 'background-color:' . $hover_background_color . ';';
		}

		if ( $shape != '' ) {
			$class[] = $this->prefix . 'shape' . '_' . $shape;
		}

		if ( $show_button != '' ) {
			$class[] = $this->prefix . 'show_button' . '_' . $show_button;
		}
		
		if ( $product_title == '' && $product_exists ) {
			$product_title = $product->get_title();
		}

		if ( $show_category == 'show' && $product_exists ) {
			$show_category = wc_get_product_category_list( $product->get_id() );
		}
		
		if ( $product_price == '' && $product_exists ) {
			$product_price = $product->get_price_html();
		}
		
		if ( $product_image == '' ) {
			if ( $product_exists ) $product_image = $product->get_image( 'shop_catalog' );
		} else {
			$post_image = get_post( $product_image );
			if ( $post_image == '' ) return;
		
			$image = wp_get_attachment_image_src( $product_image, "full" );
			$caption = $post_image->post_excerpt;
			
			$image = $image[0];
			if ( $caption == '' ) {
				$caption = $product_title;
			}
			
			$product_image = '<div>' . do_shortcode( '[bt_bb_image image="' . esc_attr( $image ) . '" size="boldthemes_small_2x3" ignore_fe_editor="true"]' ) . ' </div>';
		}

		$style_attr = '';
		if ( $el_style != '' ) {
			$style_attr = ' ' . 'style="' . esc_attr( $el_style ) . '"';
		}

		$background_style_attr = '';
		if ( $background_el_style != '' ) {
			$background_style_attr = ' ' . 'style="' . esc_attr( $background_el_style ) . '"';
		}

		$class = apply_filters( $this->shortcode . '_class', $class, $atts );

		$output = '<div class="' . esc_attr( implode( ' ', $class ) ) . '" ' . $style_attr . ' ' . $id_attr . '>';

			

				if ( $product_id == 0 ) {

					$output .= '<p>' . esc_html__( 'Please select WooCommerce product.', 'bold-builder' ) . '</p>';
					
				} else {
					$output .= '<div class="' . esc_attr( $this->shortcode . '_background' ) . '" ' . $background_style_attr . '></div>';
					
					$output .= '<div class="' . esc_attr( $this->shortcode . '_image' ) . '"><a href="' . get_permalink($product_id) . '" target="_self">'. $product_image . '</a></div>';

					$output .= '<div class="' . esc_attr( $this->shortcode . '_content' ) . '">';

						if ( $show_category != '' ) $output .= '<div class="' . esc_attr( $this->shortcode . '_category' ) . '">'. $show_category . '</div>';

						if ( $product_title != '' ) $output .= '<div class="' . esc_attr( $this->shortcode . '_title' ) . '"><a href="' . get_permalink($product_id) . '" target="_self">' . do_shortcode('[bt_bb_headline headline="' . esc_attr( $product_title ) . '" html_tag="'. esc_attr( $html_tag ) .'" font_weight="'. esc_attr( $title_font_weight ) .'" size="extrasmall" ignore_fe_editor="true"]' ) . '</a></div>';
						
						if ( $product_price != '' ) $output .= '<div class="' . esc_attr( $this->shortcode . '_price' ) . '"><span>' . $product_price . '</span></div>';

						if (  $product_exists && ( $show_button != '' ) || ( $show_button == 'hover' ) ) {
							$output .= '<div class="' . esc_attr( $this->shortcode . '_price_cart' ) . '">';
								$output .= do_shortcode( '[add_to_cart id="' . esc_attr( $product_id ) . '" style="" show_price="false"]' );
							$output .= '</div>';
						}

					$output .= '</div>';
				}
			
		$output .= '</div>';

		$output = apply_filters( 'bt_bb_general_output', $output, $atts );
		$output = apply_filters( $this->shortcode . '_output', $output, $atts );

		return $output;

	}

	function map_shortcode() {

		if ( class_exists( 'WooCommerce' )  ) {
			$args = array(
				'limit' 		=> -1,
				'orderby' 		=> 'title',
				'order' 		=> 'ASC',
			);
			$query = new WC_Product_Query( $args );
			$products = $query->get_products();
			$products_arr = array();
			$products_arr[ 'Not selected' ] = 0;
			foreach($products as $product) {
				$products_arr[ $product->get_name() ] = $product->get_id();
			}
		} else {
			$products_arr = array();
		}
		
		bt_bb_map( $this->shortcode, array( 'name' => esc_html__( 'Single Product', 'aiko' ), 'description' => esc_html__( 'Single WooCommerce product', 'aiko' ),  'icon' => $this->prefix_backend . 'icon' . '_' . $this->shortcode,
			'params' => array(
				array( 'param_name' => 'product_id', 'type' => 'dropdown', 'heading' => esc_html__( 'Product', 'aiko' ), 'value' => $products_arr ),
				array( 'param_name' => 'product_title', 'type' => 'textfield', 'preview' => true, 'heading' => esc_html__( 'Custom product title', 'aiko' ) ),
				array( 'param_name' => 'product_price', 'type' => 'textfield', 'heading' => esc_html__( 'Custom product price', 'aiko' ) ),
				array( 'param_name' => 'product_image', 'preview' => true, 'type' => 'attach_image', 'heading' => esc_html__( 'Custom product image', 'aiko' ) ),
				
				array( 'param_name' => 'show_category', 'type' => 'dropdown', 'heading' => esc_html__( 'Show category', 'aiko' ), 
					'value' => array(
						esc_html__( 'Hide', 'aiko' ) 		=> '',
						esc_html__( 'Show', 'aiko' ) 		=> 'show'
					)
				),
				array( 'param_name' => 'show_button', 'type' => 'dropdown', 'heading' => esc_html__( 'Show button', 'aiko' ), 
					'value' => array(
						esc_html__( 'Hide', 'aiko' ) 		=> '',
						esc_html__( 'Show', 'aiko' ) 		=> 'yes',
						esc_html__( 'Show on hover', 'aiko' ) 	=> 'on_hover'
					)
				),
				array( 'param_name' => 'html_tag', 'type' => 'dropdown', 'default' => 'h4', 'heading' => esc_html__( 'HTML title tag', 'aiko' ),
					'value' => array(
						esc_html__( 'h1', 'aiko' ) 				=> 'h1',
						esc_html__( 'h2', 'aiko' )	 			=> 'h2',
						esc_html__( 'h3', 'aiko' ) 				=> 'h3',
						esc_html__( 'h4', 'aiko' ) 				=> 'h4',
						esc_html__( 'h5', 'aiko' ) 				=> 'h5',
						esc_html__( 'h6', 'aiko' ) 				=> 'h6'
				) ),
				array( 'param_name' => 'title_font_weight', 'type' => 'dropdown', 'heading' => esc_html__( 'Title font weight', 'aiko' ), 
					'value' => array(
						esc_html__( 'Default', 'aiko' ) 		=> '',
						esc_html__( 'Normal', 'aiko' ) 		=> 'normal',
						esc_html__( 'Bold', 'aiko' ) 		=> 'bold',
						esc_html__( 'Bolder', 'aiko' ) 		=> 'bolder',
						esc_html__( 'Lighter', 'aiko' ) 		=> 'lighter',
						esc_html__( 'Light', 'aiko' ) 		=> 'light',
						esc_html__( 'Thin', 'aiko' ) 		=> 'thin',
						esc_html__( '100', 'aiko' ) 			=> '100',
						esc_html__( '200', 'aiko' ) 			=> '200',
						esc_html__( '300', 'aiko' ) 			=> '300',
						esc_html__( '400', 'aiko' ) 			=> '400',
						esc_html__( '500', 'aiko' ) 			=> '500',
						esc_html__( '600', 'aiko' ) 			=> '600',
						esc_html__( '700', 'aiko' ) 			=> '700',
						esc_html__( '800', 'aiko' ) 			=> '800',
						esc_html__( '900', 'aiko' ) 			=> '900'
					)
				),
				array( 'param_name' => 'hover_background_color', 'preview' => true, 'type' => 'colorpicker', 'heading' => esc_html__( 'Background color', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ) ),
				array( 'param_name' => 'shape', 'type' => 'dropdown', 'heading' => esc_html__( 'Shape', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Inherit', 'aiko' ) 			=> '',
						esc_html__( 'Square', 'aiko' ) 			=> 'square',
						esc_html__( 'Soft Rounded', 'aiko' ) 	=> 'soft_rounded',
						esc_html__( 'Hard Rounded', 'aiko' ) 	=> 'hard_rounded'
					)
				),
			)
		) );
	}
}