<?php

class bt_bb_card_icon extends BT_BB_Element {

	function handle_shortcode( $atts, $content ) {
		extract( shortcode_atts( apply_filters( 'bt_bb_extract_atts', array(
			'icon'							=> '',
			'title'							=> '',
			'text'							=> '',
			'html_tag'						=> 'h4',

			'url'							=> '',
			'target' 						=> '',

			'background_color'				=> '',
			'text_color'					=> '',
			'color_scheme' 					=> '',
			'icon_color_scheme' 			=> '',
			'icon_hover_color_scheme' 		=> '',
			'hover_color_scheme' 			=> '',
			'padding'						=> 'normal',
			'shape'							=> '',
			'shadow'						=> '',
			'blur'							=> '',
			'title_size'					=> 'small',
			'icon_size'						=> 'huge',
			'icon_style'					=> 'borderless',
			'icon_shape'					=> 'square',
			'style'							=> '',
			'title_font_weight'				=> '',
			'border_color'					=> '',
			'hover_text_color'				=> '',
			'show_content'					=> '',
			'font'          				=> '',
			'font_subset'   				=> '',
			'min_height'					=> ''
		) ), $atts, $this->shortcode ) );
		
		$class = array( $this->shortcode );
		$data_override_class = array();

		if ( $font != '' && $font != 'inherit' ) {
			require_once( WP_PLUGIN_DIR   . '/bold-page-builder/content_elements_misc/misc.php' );
			bt_bb_enqueue_google_font( $font, $font_subset );
		}

		wp_enqueue_script(
			'bt_bb_card_icon',
			get_template_directory_uri() . '/bold-page-builder/content_elements/bt_bb_card_icon/bt_bb_card_icon.js',
			array( 'jquery' ),
			'',
			true
		);

		$title = html_entity_decode( $title, ENT_QUOTES, 'UTF-8' );

		if ( $el_class != '' ) {
			$class[] = $el_class;
		}

		$id_attr = '';
		if ( $el_id != '' ) {
			$id_attr = ' ' . 'id="' . esc_attr( $el_id ) . '"';
		}

		if ( $url != '' ) {
			$class[] = 'btWithLink';
		}

		if ( $text == '' ) {
			$class[] = 'bt_bb_no_text';
		}

		if ( $background_color != '' ) {
			$el_style = $el_style . 'background-color:' . $background_color . ';';
		}

		$el_inner_style = '';
		if ( $min_height != '' ) {
			$el_style = $el_style . 'min-height:' . $min_height . ';';
			$el_inner_style = $el_inner_style . 'min-height:' . $min_height . ';';
		}

		$this->responsive_data_override_class(
			$class, $data_override_class,
			array(
				'prefix' => $this->prefix,
				'param' => 'padding',
				'value' => $padding
			)
		);

		$color_scheme_id = NULL;
		if ( is_numeric ( $color_scheme ) ) {
			$color_scheme_id = $color_scheme;
		} else if ( $color_scheme != '' ) {
			$color_scheme_id = bt_bb_get_color_scheme_id( $color_scheme );
		}
		$color_scheme_colors = bt_bb_get_color_scheme_colors_by_id( $color_scheme_id - 1 );
		if ( $color_scheme_colors ) $el_style .= '; --card-primary-color:' . $color_scheme_colors[0] . '; --card-secondary-color:' . $color_scheme_colors[1] . ';';
		if ( $color_scheme != '' ) $class[] = $this->prefix . 'color_scheme_' .  $color_scheme_id;


		$icon_color_scheme_id = NULL;
		if ( is_numeric ( $icon_color_scheme ) ) {
			$icon_color_scheme_id = $icon_color_scheme;
		} else if ( $icon_color_scheme != '' ) {
			$icon_color_scheme_id = bt_bb_get_color_scheme_id( $icon_color_scheme );
		}
		$icon_color_scheme_colors = bt_bb_get_color_scheme_colors_by_id( $icon_color_scheme_id - 1 );
		if ( $icon_color_scheme_colors ) $el_style .= '; --icon-card-primary-color:' . $icon_color_scheme_colors[0] . '; --icon-card-secondary-color:' . $icon_color_scheme_colors[1] . ';';
		if ( $icon_color_scheme != '' ) $class[] = $this->prefix . 'icon_color_scheme_' .  $icon_color_scheme_id;


		$icon_hover_color_scheme_id = NULL;
		if ( is_numeric ( $icon_hover_color_scheme ) ) {
			$icon_hover_color_scheme_id = $icon_hover_color_scheme;
		} else if ( $icon_hover_color_scheme != '' ) {
			$icon_hover_color_scheme_id = bt_bb_get_color_scheme_id( $icon_hover_color_scheme );
		}
		$icon_hover_color_scheme_colors = bt_bb_get_color_scheme_colors_by_id( $icon_hover_color_scheme_id - 1 );
		if ( $icon_hover_color_scheme_colors ) $el_style .= '; --icon-hover-card-primary-color:' . $icon_hover_color_scheme_colors[0] . '; --icon-hover-card-secondary-color:' . $icon_hover_color_scheme_colors[1] . ';';
		if ( $icon_hover_color_scheme != '' ) $class[] = $this->prefix . 'icon_hover_color_scheme_' .  $icon_hover_color_scheme_id;


		$hover_color_scheme_id = NULL;
		if ( is_numeric ( $hover_color_scheme ) ) {
			$hover_color_scheme_id = $hover_color_scheme;
		} else if ( $hover_color_scheme != '' ) {
			$hover_color_scheme_id = bt_bb_get_color_scheme_id( $hover_color_scheme );
		}
		$hover_color_scheme_colors = bt_bb_get_color_scheme_colors_by_id( $hover_color_scheme_id - 1 );
		if ( $hover_color_scheme_colors ) $el_style .= '; --hover-card-primary-color:' . $hover_color_scheme_colors[0] . '; --hover-card-secondary-color:' . $hover_color_scheme_colors[1] . ';';
		if ( $hover_color_scheme != '' ) $class[] = $this->prefix . 'hover_color_scheme_' .  $hover_color_scheme_id;


		if ( $hover_text_color != '' ) {
			$class[] = $this->prefix . 'hover_text_color' . '_' . $hover_text_color;
		}

		if ( $show_content != '' ) {
			$class[] = $this->prefix . 'show_content' . '_' . $show_content;
		}

		if ( $shape != '' ) {
			$class[] = $this->prefix . 'shape' . '_' . $shape;
		}

		if ( $style != '' ) {
			$class[] = $this->prefix . 'style' . '_' . $style;
		}

		if ( $border_color != '' ) {
			$class[] = $this->prefix . 'border_color' . '_' . $border_color;
		}

		if ( $shadow != '' ) {
			$class[] = $this->prefix . 'shadow' . '_' . $shadow;
		}

		if ( $blur != '' ) {
			$class[] = $this->prefix . 'blur' . '_' . $blur;
		}

		if ( $font != '' ) {
			$class[] = 'bt_bb_has_font';
		}

		$el_title_style = '';
		if ( $font != '' && $font != 'inherit' ) {
			$el_title_style = $el_title_style . ';' . 'font-family:\'' . urldecode( $font ) . '\'';
		}

		$title_style_attr = '';
		$el_title_style = apply_filters( $this->shortcode . '_style', $el_title_style, $atts );
		if ( $el_title_style != '' ) {
			$title_style_attr = ' ' . 'style="' . esc_attr( $el_title_style ) . '"';
		}

		$content = do_shortcode( $content );

		$link = bt_bb_get_permalink_by_slug( $url );

		$class = apply_filters( $this->shortcode . '_class', $class, $atts );
		$class_attr = implode( ' ', $class );

		if ( $el_class != '' ) {
			$class_attr = $class_attr . ' ' . $el_class;
		}

		$inner_style_attr = '';
		if ( $el_inner_style != '' ) {
			$inner_style_attr = ' ' . 'style="' . esc_attr( $el_inner_style ) . '"';
		}

		$style_attr = '';
		if ( $el_style != '' ) {
			$style_attr = ' ' . 'style="' . esc_attr( $el_style ) . '"';
		}

		$text_style = '';
		if ( $text_color != '' ) {
			$text_style = $text_style . 'color:' . $text_color . ';';
		}

		$text_style_attr = '';
		if ( $text_style != '' ) {
			$text_style_attr = ' ' . 'style="' . esc_attr( $text_style ) . '"';
		}

		$output = '<div' . $id_attr . ' class="' . esc_attr( $class_attr ) . '" ' . $style_attr . ' data-bt-override-class="' . htmlspecialchars( json_encode( $data_override_class, JSON_FORCE_OBJECT ), ENT_QUOTES, 'UTF-8' ) . '"><div class="' . esc_attr( $this->shortcode . '_inner' ) . '" ' . $inner_style_attr . '>';

			// LINK
			if ( $link != '' ) {
				$target_attr = ' target="_self" ';
				if ( $target != '' ) {
					$target_attr = ' ' . 'target="' . esc_attr( $target ) . '"';
				}
				$output .= '<a href="' . esc_url( $link ) . '" ' . $target_attr . ' class="btCardLink" ' . $inner_style_attr . '></a>';
			}
			
			// ICON
			if ( $icon != '' ) $output .= '<div class="' . esc_attr( $this->shortcode . '_icon' ) . '">' . do_shortcode( '[bt_bb_icon icon="' . esc_attr( $icon ) . '" size="' . esc_attr( $icon_size ) . '" style="' . esc_attr( $icon_style ) . '" shape="' . esc_attr( $icon_shape ) . '" color_scheme="' . esc_attr( $icon_color_scheme ) . '" ignore_fe_editor="true"]' ) . '</div>';


			$output .= '<div class="' . esc_attr( $this->shortcode . '_content' ) . '" >';

				// TITLE
				if ( $title != '' )	$output .= '<div class="' . esc_attr( $this->shortcode . '_title' ) . '" ' . $title_style_attr . '>' . do_shortcode('[bt_bb_headline headline="' . esc_attr( $title ) . '" html_tag="'. esc_attr( $html_tag ) .'" size="' . esc_attr( $title_size ) . '" font_weight="'. esc_attr( $title_font_weight ) .'" ignore_fe_editor="true"]' ) . '</div>';

				// TEXT
				if ( $text != '' ) $output .= '<div class="' . esc_attr( $this->shortcode . '_text' ) . '" ' . $text_style_attr . '><p>' . nl2br( $text ) . '</p></div>';

				// INNER CONTENT
				if ( $content != '' ) $output .= '<div class="' . esc_attr( $this->shortcode . '_content_inner' ) . '">' . ( $content ) . '</div>';

			$output .= '</div>';

		$output .= '</div></div>';

		$output = apply_filters( 'bt_bb_general_output', $output, $atts );
		$output = apply_filters( $this->shortcode . '_output', $output, $atts );

		return $output;

	}

	function map_shortcode() {
		
		$color_scheme_arr = bt_bb_get_color_scheme_param_array();
		include( WP_PLUGIN_DIR   . '/bold-page-builder/content_elements_misc/fonts.php' );

		bt_bb_map( $this->shortcode, array( 'name' => esc_html__( 'Card Icon', 'aiko' ), 'description' => esc_html__( 'Card with icon and text', 'aiko' ), 'icon' => $this->prefix_backend . 'icon' . '_' . $this->shortcode, 'container' => 'vertical', 'toggle' => true, 'accept' => array( 'bt_bb_button' => true, 'bt_bb_text' => true, 'bt_bb_separator' => true ),
			'params' => array(
				array( 'param_name' => 'icon', 'type' => 'iconpicker', 'heading' => esc_html__( 'Icon', 'aiko' ), 'preview' => true ),
				array( 'param_name' => 'title', 'type' => 'textfield', 'heading' => esc_html__( 'Title', 'aiko' ), 'preview' => true ),
				array( 'param_name' => 'text', 'type' => 'textarea', 'heading' => esc_html__( 'Text', 'aiko' ) ),
				array( 'param_name' => 'padding', 'default' => 'normal', 'type' => 'dropdown', 'heading' => esc_html__( 'Inner padding', 'aiko' ), 'preview' => true, 'responsive_override' => true,
					'value' => array(
						esc_html__( 'No padding', 'aiko' ) 	=> 'none',
						esc_html__( 'Normal', 'aiko' ) 		=> 'normal',
						esc_html__( '5px', 'aiko' ) 			=> '5px',
						esc_html__( '10px', 'aiko' ) 		=> '10px',
						esc_html__( '15px', 'aiko' ) 		=> '15px',
						esc_html__( '20px', 'aiko' ) 		=> '20px',
						esc_html__( '25px', 'aiko' ) 		=> '25px',
						esc_html__( '30px', 'aiko' ) 		=> '30px',
						esc_html__( '35px', 'aiko' ) 		=> '35px',
						esc_html__( '40px', 'aiko' ) 		=> '40px',
						esc_html__( '45px', 'aiko' ) 		=> '45px',
						esc_html__( '50px', 'aiko' ) 		=> '50px',
						esc_html__( '55px', 'aiko' ) 		=> '55px',
						esc_html__( '60px', 'aiko' ) 		=> '60px',
						esc_html__( '65px', 'aiko' ) 		=> '65px',
						esc_html__( '70px', 'aiko' ) 		=> '70px',
						esc_html__( '75px', 'aiko' ) 		=> '75px',
						esc_html__( '80px', 'aiko' ) 		=> '80px',
						esc_html__( '85px', 'aiko' ) 		=> '85px',
						esc_html__( '90px', 'aiko' ) 		=> '90px',
						esc_html__( '95px', 'aiko' ) 		=> '95px',
						esc_html__( '100px', 'aiko' ) 		=> '100px'
					)
				),
				array( 'param_name' => 'html_tag', 'type' => 'dropdown', 'default' => 'h4', 'heading' => esc_html__( 'HTML title tag', 'aiko' ),
					'value' => array(
						esc_html__( 'h1', 'aiko' ) 				=> 'h1',
						esc_html__( 'h2', 'aiko' )	 			=> 'h2',
						esc_html__( 'h3', 'aiko' ) 				=> 'h3',
						esc_html__( 'h4', 'aiko' ) 				=> 'h4',
						esc_html__( 'h5', 'aiko' ) 				=> 'h5',
						esc_html__( 'h6', 'aiko' ) 				=> 'h6'
				) ),
				

				array( 'param_name' => 'url', 'type' => 'link', 'heading' => esc_html__( 'URL', 'aiko' ), 'preview' => true, 'description' => esc_html__( 'Enter full or local URL (e.g. https://www.bold-themes.com or /pages/about-us), post slug (e.g. about-us).', 'aiko' ), 'group' => esc_html__( 'URL', 'aiko' ) ),
				array( 'param_name' => 'target', 'type' => 'dropdown', 'group' => esc_html__( 'URL', 'aiko' ), 'heading' => esc_html__( 'Target', 'aiko' ),
					'value' => array(
						esc_html__( 'Self (open in same tab)', 'aiko' ) 	=> '_self',
						esc_html__( 'Blank (open in new tab)', 'aiko' ) 	=> '_blank',
					)
				),
				

				array( 'param_name' => 'style', 'type' => 'dropdown', 'default' => 'borderless', 'heading' => esc_html__( 'Style', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Filled', 'aiko' ) 					=> '',
						esc_html__( 'Outline', 'aiko' ) 					=> 'outline',
						esc_html__( 'Filled + Outline', 'aiko' ) 		=> 'filled_outline'
					)
				),
				array( 'param_name' => 'shape', 'type' => 'dropdown', 'heading' => esc_html__( 'Shape', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Inherit', 'aiko' ) 			=> '',
						esc_html__( 'Square', 'aiko' ) 			=> 'square',
						esc_html__( 'Soft Rounded', 'aiko' ) 	=> 'soft_rounded',
						esc_html__( 'Hard Rounded', 'aiko' ) 	=> 'hard_rounded',
						esc_html__( 'Very Rounded', 'aiko' ) 	=> 'very_rounded'
					)
				),
				array( 'param_name' => 'shadow', 'type' => 'dropdown', 'heading' => esc_html__( 'Shadow', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Hide', 'aiko' ) 								=> '',
						esc_html__( 'Always visible', 'aiko' ) 						=> 'show',
						esc_html__( 'Always visible, on hover move up', 'aiko' ) 	=> 'show_move',
						esc_html__( 'Show on hover', 'aiko' ) 						=> 'on_hover',
						esc_html__( 'Show & move up on hover', 'aiko' ) 				=> 'move_up'
					)
				),
				array( 'param_name' => 'blur', 'type' => 'dropdown', 'heading' => esc_html__( 'Blur', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'No', 'aiko' ) 					=> '',
						esc_html__( 'Yes', 'aiko' ) 					=> 'show'
					)
				),
				array( 'param_name' => 'color_scheme', 'type' => 'dropdown', 'heading' => esc_html__( 'Color scheme', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ), 'value' => $color_scheme_arr, 'preview' => true, 'description' => esc_html__( 'Choose color scheme for Card background (or border) and content color.', 'aiko' ) ),
				array( 'param_name' => 'hover_color_scheme', 'type' => 'dropdown', 'heading' => esc_html__( 'Hover background gradient color scheme', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ), 'value' => $color_scheme_arr, 'preview' => true, 'description' => esc_html__( 'Choose color scheme for filled gradient style on hover.', 'aiko' ) ),
				
				array( 'param_name' => 'background_color', 'preview' => true, 'type' => 'colorpicker', 'heading' => esc_html__( 'Background color', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ), 'description' => esc_html__( 'Choose Card background color (note: it overrides chosen color scheme).', 'aiko' ) ),
				array( 'param_name' => 'text_color', 'type' => 'colorpicker', 'heading' => esc_html__( 'Text color', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ), 'description' => esc_html__( 'Choose text color (note: it overrides chosen color from color scheme).', 'aiko' ) ),
				array( 'param_name' => 'hover_text_color', 'type' => 'dropdown', 'heading' => esc_html__( 'Hover text color', 'aiko' ),  'description' => esc_html__( 'Choose text color on hover (note: it overrides chosen color from color scheme).', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Inherit', 'aiko' ) 								=> '',
						esc_html__( 'Accent color', 'aiko' ) 						=> 'accent',
						esc_html__( 'Alternate color', 'aiko' ) 						=> 'alternate',
						esc_html__( 'Light color', 'aiko' ) 							=> 'light',
						esc_html__( 'Dark color', 'aiko' ) 							=> 'dark'
					)
				),
				array( 'param_name' => 'border_color', 'type' => 'dropdown', 'heading' => esc_html__( 'Border color', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Gray color', 'aiko' ) 							=> '',
						esc_html__( 'Accent color', 'aiko' ) 						=> 'accent',
						esc_html__( 'Alternate color', 'aiko' ) 						=> 'alternate',
						esc_html__( 'Light color', 'aiko' ) 							=> 'light',
						esc_html__( 'Dark color', 'aiko' ) 							=> 'dark',
						esc_html__( 'Dark gray color', 'aiko' ) 						=> 'dark_gray'
					)
				),
				array( 'param_name' => 'min_height', 'type' => 'textfield', 'heading' => esc_html__( 'Minimun Card height', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ), 'description' => esc_html__( 'E.g. 3em or 300px', 'aiko' ) ),
				

				array( 'param_name' => 'show_content', 'type' => 'dropdown', 'heading' => esc_html__( 'Show content', 'aiko' ), 'group' => esc_html__( 'Content', 'aiko' ),
					'value' => array(
						esc_html__( 'Show always', 'aiko' ) 							=> '',
						esc_html__( 'Show on hover', 'aiko' ) 						=> 'on_hover'
					)
				),
				array( 'param_name' => 'font', 'type' => 'dropdown', 'group' => esc_html__( 'Content', 'aiko' ), 'heading' => esc_html__( 'Title font', 'aiko' ), 'preview' => true, 'value' => array( esc_html__( 'Inherit', 'aiko' ) => 'inherit' ) + $font_arr
				),
				array( 'param_name' => 'font_subset', 'type' => 'textfield', 'group' => esc_html__( 'Content', 'aiko' ), 'heading' => esc_html__( 'Title font subset', 'aiko' ), 'value' => 'latin,latin-ext', 'description' => esc_html__( 'E.g. latin,latin-ext,cyrillic,cyrillic-ext', 'aiko' ) ),
				array( 'param_name' => 'title_size', 'type' => 'dropdown', 'default' => 'small', 'heading' => esc_html__( 'Title size', 'aiko' ), 'group' => esc_html__( 'Content', 'aiko' ),
					'value' => array(
						esc_html__( 'Extra small', 'aiko' ) 		=> 'extrasmall',
						esc_html__( 'Small', 'aiko' ) 			=> 'small',
						esc_html__( 'Medium', 'aiko' ) 			=> 'medium',
						esc_html__( 'Normal', 'aiko' ) 			=> 'normal',
						esc_html__( 'Large', 'aiko' ) 			=> 'large'
					)
				),
				array( 'param_name' => 'title_font_weight', 'type' => 'dropdown', 'heading' => esc_html__( 'Title font weight', 'aiko' ), 'group' => esc_html__( 'Content', 'aiko' ),
					'value' => array(
						esc_html__( 'Default', 'aiko' ) 		=> '',
						esc_html__( 'Normal', 'aiko' ) 		=> 'normal',
						esc_html__( 'Bold', 'aiko' ) 		=> 'bold',
						esc_html__( 'Bolder', 'aiko' ) 		=> 'bolder',
						esc_html__( 'Lighter', 'aiko' ) 		=> 'lighter',
						esc_html__( 'Light', 'aiko' ) 		=> 'light',
						esc_html__( 'Thin', 'aiko' ) 		=> 'thin',
						esc_html__( '100', 'aiko' ) 			=> '100',
						esc_html__( '200', 'aiko' ) 			=> '200',
						esc_html__( '300', 'aiko' ) 			=> '300',
						esc_html__( '400', 'aiko' ) 			=> '400',
						esc_html__( '500', 'aiko' ) 			=> '500',
						esc_html__( '600', 'aiko' ) 			=> '600',
						esc_html__( '700', 'aiko' ) 			=> '700',
						esc_html__( '800', 'aiko' ) 			=> '800',
						esc_html__( '900', 'aiko' ) 			=> '900'
					)
				),


				array( 'param_name' => 'icon_style', 'type' => 'dropdown', 'default' => 'borderless', 'heading' => esc_html__( 'Icon style', 'aiko' ), 'group' => esc_html__( 'Icon', 'aiko' ),
					'value' => array(
						esc_html__( 'Borderless', 'aiko' ) 				=> 'borderless',
						esc_html__( 'Filled', 'aiko' ) 					=> 'filled',
						esc_html__( 'Filled gradient', 'aiko' ) 			=> 'filled_gradient',
						esc_html__( 'Borderless gradient', 'aiko' ) 		=> 'borderless_gradient'
					)
				),
				array( 'param_name' => 'icon_size', 'type' => 'dropdown', 'default' => 'huge', 'heading' => esc_html__( 'Icon size', 'aiko' ), 'group' => esc_html__( 'Icon', 'aiko' ), 'responsive_override' => true,
					'value' => array(
						esc_html__( 'Extra small', 'aiko' ) 		=> 'xsmall',
						esc_html__( 'Small', 'aiko' ) 			=> 'small',
						esc_html__( 'Normal', 'aiko' ) 			=> 'normal',
						esc_html__( 'Large', 'aiko' ) 			=> 'large',
						esc_html__( 'Extra large', 'aiko' ) 		=> 'xlarge',
						esc_html__( 'Huge', 'aiko' ) 			=> 'huge'
					)
				),
				array( 'param_name' => 'icon_shape', 'type' => 'dropdown', 'default' => 'square', 'heading' => esc_html__( 'Icon shape', 'aiko' ), 'group' => esc_html__( 'Icon', 'aiko' ),
					'value' => array(
						esc_html__( 'Circle', 'aiko' ) 			=> 'circle',
						esc_html__( 'Square', 'aiko' ) 			=> 'square',
						esc_html__( 'Soft rounded square', 'aiko' ) 	=> 'round',
						esc_html__( 'Hard rounded square', 'aiko' ) 	=> 'hard-round'
					)
				),
				array( 'param_name' => 'icon_color_scheme', 'type' => 'dropdown', 'heading' => esc_html__( 'Icon color scheme', 'aiko' ),  'description' => esc_html__( 'Choose icon color scheme (note: it overrides chosen color from color scheme).', 'aiko' ), 'group' => esc_html__( 'Icon', 'aiko' ), 'value' => $color_scheme_arr, 'preview' => true ),
				array( 'param_name' => 'icon_hover_color_scheme', 'type' => 'dropdown', 'heading' => esc_html__( 'Icon hover color scheme', 'aiko' ), 'group' => esc_html__( 'Icon', 'aiko' ), 'description' => esc_html__( 'Choose icon color scheme on hover (note: it overrides chosen color from color scheme).', 'aiko' ), 'value' => $color_scheme_arr ),
				
			) )
		);
	}
}