<?php

class bt_bb_link_item extends BT_BB_Element {

	function handle_shortcode( $atts, $content ) {
		extract( shortcode_atts( apply_filters( 'bt_bb_extract_atts_' . $this->shortcode, array(
			'text'					=> '',
			'image'      			=> '',
			'image_size'			=> '',
			'url'					=> '',
			'target'				=> ''

		) ), $atts, $this->shortcode ) );
		
		$class = array( $this->shortcode );
		$data_override_class = array();


		if ( $el_class != '' ) {
			$class[] = $el_class;
		}
		
		$id_attr = '';
		if ( $el_id != '' ) {
			$id_attr = ' ' . 'id="' . esc_attr( $el_id ) . '"';
		}

		if ( $target == '' ) {
			$target = '_self';
		}

		if ( $url != '' ) {
			$class[] = 'btWithLink';
		}

		$link = bt_bb_get_permalink_by_slug( $url );

		$class = apply_filters( $this->shortcode . '_class', $class, $atts );
		$class_attr = implode( ' ', $class );

		if ( $el_class != '' ) {
			$class_attr = $class_attr . ' ' . $el_class;
		}

		$style_attr = '';
		if ( $el_style != '' ) {
			$style_attr = ' ' . 'style="' . esc_attr( $el_style ) . '"';
		}

		$output = '<div' . $id_attr . ' class="' . esc_attr( $class_attr ) . '" ' . $style_attr . '>';

			// TEXT
			if ( $text != '' ) {

				$output .= '<div class="' . esc_attr( $this->shortcode . '_text' ) . '">';

					// LINK
					if ( $link != '' ) {
						$target_attr = ' target="_self" ';
						if ( $target != '' ) {
							$target_attr = ' ' . 'target="' . esc_attr( $target ) . '"';
						}
						$output .= '<a href="' . esc_url( $link ) . '" ' . $target_attr . ' class="' . esc_attr( $this->shortcode . '_main_link') . '"></a>';
					}

					$output .= '<h4>' . $text . '</h4>';

				$output .= '</div>';
			}

			// IMAGE
			if ( $image != '' ) $output .= '<div class="' . esc_attr( $this->shortcode . '_image') . '">' . do_shortcode( '[bt_bb_image image="' . esc_attr( $image ) . '" size="boldthemes_medium_square" shape="very-rounded" lazy_load="no" ignore_fe_editor="true"]' ) . '</div>';
			
		$output .= '</div>';
		
		$output = apply_filters( 'bt_bb_general_output', $output, $atts );
		$output = apply_filters( $this->shortcode . '_output', $output, $atts );

		return $output;

	}
	
	function map_shortcode() {

		bt_bb_map( $this->shortcode, array( 'name' => esc_html__( 'Link item', 'aiko' ), 'as_child' => array( 'only' => 'bt_bb_links' ), 'description' => esc_html__( 'Text with link', 'aiko' ), 'accept' => array( 'bt_bb_section' => false, 'bt_bb_row' => false, 'bt_bb_column' => false, 'bt_bb_column_inner' => false, 'bt_bb_tabs' => false, 'bt_bb_tab_item' => false, 'bt_bb_accordion' => false, 'bt_bb_accordion_item' => false, 'bt_bb_cost_calculator_item' => false, 'bt_cc_group' => false, 'bt_cc_multiply' => false, 'bt_cc_item' => false, 'bt_bb_content_slider_item' => false, 'bt_bb_google_maps_location' => false, '_content' => false ),'accept_all' => true, 'icon' => $this->prefix_backend . 'icon' . '_' . $this->shortcode,
			'params' => array(
				array( 'param_name' => 'text', 'type' => 'textfield', 'heading' => esc_html__( 'Text', 'aiko' ), 'preview' => true ),
				array( 'param_name' => 'image', 'type' => 'attach_image', 'preview' => true, 'heading' => esc_html__( 'Image', 'aiko' ) 
				),
				array( 'param_name' => 'image_size', 'type' => 'dropdown', 'heading' => esc_html__( 'Image size', 'aiko' ), 
					'value' => bt_bb_get_image_sizes()
				),

				array( 'param_name' => 'url', 'type' => 'textfield', 'group' => esc_html__( 'URL', 'aiko' ), 'heading' => esc_html__( 'URL', 'aiko' ), 'description' => esc_html__( 'Enter full or local URL (e.g. https://www.bold-themes.com or /pages/about-us), post slug (e.g. about-us).', 'aiko' ), 'preview' => true ),
				array( 'param_name' => 'target', 'type' => 'dropdown', 'group' => esc_html__( 'URL', 'aiko' ), 'heading' => esc_html__( 'Target', 'aiko' ),
					'value' => array(
						esc_html__( 'Self (open in same tab)', 'aiko' ) => '_self',
						esc_html__( 'Blank (open in new tab)', 'aiko' ) => '_blank',
					)
				),
			)
		) );
	} 
}