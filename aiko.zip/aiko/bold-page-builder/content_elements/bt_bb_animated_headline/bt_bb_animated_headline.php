<?php

class bt_bb_animated_headline extends BT_BB_Element {

	function handle_shortcode( $atts, $content ) {
		
		extract( shortcode_atts( apply_filters( 'bt_bb_extract_atts_' . $this->shortcode, array(
			'headlines'				=> '',
			'html_tag'				=> 'h1',
			'title_size'			=> 'normal',
			'animation_duration'	=> '2000',
			'animation_loop'		=> '0',
			'lines'					=> '2',
			'animation_character'	=> '!<>-_\\/[]{}—=+*^?#________'
		) ), $atts, $this->shortcode ) );
		
		$class = array();
		$data_override_class = array();
		
		$this->enqueue();
		
		$class[] = 'bt_bb_animated_headline';

		if ( $el_class != '' ) {
			$class[] = $el_class;
		}

		$id_attr = '';
		if ( $el_id != '' ) {
			$id_attr = ' ' . 'id="' . esc_attr( $el_id ) . '"';
		}

		$this->responsive_data_override_class(
			$class, $data_override_class,
			array(
				'prefix' => $this->prefix,
				'param' => 'title_size',
				'value' => $title_size
			)
		);

		if ( $lines != '' ) {
			$class[] = $this->prefix . 'lines' . '_' . $lines;
		}
		
		$class = apply_filters( $this->shortcode . '_class', $class, $atts );
		$class_attr = implode( ' ', $class );

		if ( $el_class != '' ) {
			$class_attr = $class_attr . ' ' . $el_class;
		}

		$style_attr = '';
		if ( $el_style != '' ) {
			$style_attr = ' ' . 'style="' . esc_attr( $el_style ) . '"';
		}

		$output = '<div' . $id_attr . ' class="' . esc_attr( $class_attr ) . '" ' . $style_attr . ' data-bt-override-class="' . htmlspecialchars( json_encode( $data_override_class, JSON_FORCE_OBJECT ), ENT_QUOTES, 'UTF-8' ) . '">';

		if ( $headlines != '' ) {
			$headline_items = preg_split( '/\r\n|\n|\r/', $headlines );
			
			$output .= '<' . $html_tag . ' class="' . esc_attr( $this->shortcode . '_content' ) . '" data-content="' . esc_attr( json_encode( $headline_items ) ) . '" data-duration="' . esc_attr( $animation_duration ) . '" data-loop="' . esc_attr( $animation_loop ) . '" data-characters="' . esc_attr( $animation_character ) . '"></' . $html_tag . '>';
		}

		$output .= '</div>';
		
		$output = apply_filters( 'bt_bb_general_output', $output, $atts );
		$output = apply_filters( $this->shortcode . '_output', $output, $atts );
			
		return $output;
	}
	
	function enqueue() {
		wp_enqueue_script(
			'bt_bb_animated_headline',
			get_template_directory_uri() . '/bold-page-builder/content_elements/bt_bb_animated_headline/bt_bb_animated_headline.js',
			array( 'jquery' ),
			false,
			true
		);		
	}

	function map_shortcode() {

		bt_bb_map( $this->shortcode, array( 'name' => esc_html__( 'Animated Headline', 'aiko' ), 'description' => esc_html__( 'Animated headline with effect', 'aiko' ), 'icon' => $this->prefix_backend . 'icon' . '_' . $this->shortcode,
			'params' => array(
				array( 'param_name' => 'headlines', 'type' => 'textarea', 'heading' => esc_html__( 'Animated Headlines', 'aiko' ), 'description' => esc_html__( 'Type Headlines separated by new line', 'aiko' ), ),
				array( 'param_name' => 'html_tag', 'type' => 'dropdown', 'default' => 'h1', 'heading' => esc_html__( 'HTML headline tag', 'aiko' ),
					'value' => array(
						esc_html__( 'h1', 'aiko' ) 				=> 'h1',
						esc_html__( 'h2', 'aiko' )	 			=> 'h2',
						esc_html__( 'h3', 'aiko' ) 				=> 'h3',
						esc_html__( 'h4', 'aiko' ) 				=> 'h4',
						esc_html__( 'h5', 'aiko' ) 				=> 'h5',
						esc_html__( 'h6', 'aiko' ) 				=> 'h6'
				) ),
				
				array( 'param_name' => 'title_size', 'type' => 'dropdown', 'default' => 'medium', 'heading' => esc_html__( 'Headline size', 'aiko' ), 'responsive_override' => true,
					'value' => array(
						esc_html__( 'Extra small', 'aiko' ) 		=> 'extrasmall',
						esc_html__( 'Small', 'aiko' ) 			=> 'small',
						esc_html__( 'Medium', 'aiko' ) 			=> 'medium',
						esc_html__( 'Normal', 'aiko' ) 			=> 'normal',
						esc_html__( 'Large', 'aiko' ) 			=> 'large',
						esc_html__( 'Extra Large', 'aiko' ) 		=> 'extralarge',
						esc_html__( 'Huge', 'aiko' ) 			=> 'huge'
					)
				),
				array( 'param_name' => 'lines', 'default' => '2', 'type' => 'dropdown', 'heading' => esc_html__( 'Headline lines', 'aiko' ), 'description' => esc_html__( 'Limit and show 1, 2, 3, 4 or 5 lines of headline', 'aiko' ), 
					'value' => array(
						esc_html__( '5', 'aiko' )		=> '5',
						esc_html__( '4', 'aiko' )		=> '4',
						esc_html__( '3', 'aiko' )		=> '3',
						esc_html__( '2', 'aiko' )		=> '2',
						esc_html__( '1', 'aiko' )		=> '1'
					)
				),

				array( 'param_name' => 'animation_character', 'type' => 'textfield', 'heading' => esc_html__( 'Animated characters', 'aiko' ), 'default' => '!<>-_\\/[]{}—=+*^?#________', 'placeholder' => esc_html__( '!<>-_\\/[]{}—=+*^?#________', 'aiko' ), 'group' => esc_html__( 'Animation', 'aiko' ), 'description' => esc_html__( 'Type some characters (e.g."!<>-_\\/[]{}—=+*^?#________" ). Make sure to not leave the field empty.', 'aiko' ), ),
				array( 'param_name' => 'animation_duration', 'default' => '2000', 'type' => 'dropdown', 'preview' => true, 'heading' => esc_html__( 'Animation speed', 'aiko' ), 'group' => esc_html__( 'Animation', 'aiko' ),
					'value' => array(
						esc_html__( '100ms', 'aiko' ) 				=> '100',
						esc_html__( '200ms', 'aiko' ) 				=> '200',
						esc_html__( '300ms', 'aiko' ) 				=> '300',
						esc_html__( '400ms', 'aiko' ) 				=> '400',
						esc_html__( '500ms', 'aiko' ) 				=> '500',
						esc_html__( '600ms', 'aiko' ) 				=> '600',
						esc_html__( '700ms', 'aiko' ) 				=> '700',
						esc_html__( '800ms', 'aiko' ) 				=> '800',
						esc_html__( '900ms', 'aiko' ) 				=> '900',
						esc_html__( '1000ms', 'aiko' ) 				=> '1000',
						esc_html__( '1100ms', 'aiko' ) 				=> '1100',
						esc_html__( '1200ms', 'aiko' ) 				=> '1200',
						esc_html__( '1300ms', 'aiko' ) 				=> '1300',
						esc_html__( '1400ms', 'aiko' ) 				=> '1400',
						esc_html__( '1500ms', 'aiko' ) 				=> '1500',
						esc_html__( '2000ms (default)', 'aiko' ) 	=> '2000',
						esc_html__( '2500ms', 'aiko' ) 				=> '2500',
						esc_html__( '3000ms', 'aiko' ) 				=> '3000',
						esc_html__( '3500ms', 'aiko' ) 				=> '3500',
						esc_html__( '4000ms', 'aiko' ) 				=> '4000',
						esc_html__( '4500ms', 'aiko' ) 				=> '4500',
						esc_html__( '5000ms', 'aiko' ) 				=> '5000',
						esc_html__( '5500ms', 'aiko' ) 				=> '5500',
						esc_html__( '6000ms', 'aiko' ) 				=> '6000'
					)
				),
				array( 'param_name' => 'animation_loop', 'default' => 'loop', 'type' => 'dropdown', 'preview' => true, 'heading' => esc_html__( 'Stop animation', 'aiko' ), 'description' => esc_html__( 'Stop animation after defined milliseconds or set animation on loop', 'aiko' ), 'group' => esc_html__( 'Animation', 'aiko' ), 
					'value' => array(
						esc_html__( 'Loop (default)', 'aiko' ) 		=> '0',
						esc_html__( '1000ms', 'aiko' ) 				=> '1000',
						esc_html__( '2000ms', 'aiko' ) 				=> '2000',
						esc_html__( '3000ms', 'aiko' ) 				=> '3000',
						esc_html__( '4000ms', 'aiko' ) 				=> '4000',
						esc_html__( '5000ms', 'aiko' ) 				=> '5000',
						esc_html__( '6000ms', 'aiko' ) 				=> '6000',
						esc_html__( '7000ms', 'aiko' ) 				=> '7000',
						esc_html__( '8000ms', 'aiko' ) 				=> '8000',
						esc_html__( '9000ms', 'aiko' ) 				=> '9000',
						esc_html__( '10000ms', 'aiko' ) 				=> '10000',
						esc_html__( '11000ms', 'aiko' ) 				=> '11000',
						esc_html__( '12000ms', 'aiko' ) 				=> '12000',
						esc_html__( '13000ms', 'aiko' ) 				=> '13000',
						esc_html__( '14000ms', 'aiko' ) 				=> '14000',
						esc_html__( '15000ms', 'aiko' ) 				=> '15000',
						esc_html__( '16000ms', 'aiko' ) 				=> '16000',
						esc_html__( '17000ms', 'aiko' ) 				=> '17000',
						esc_html__( '18000ms', 'aiko' ) 				=> '18000',
						esc_html__( '19000ms', 'aiko' ) 				=> '19000',
						esc_html__( '20000ms', 'aiko' ) 				=> '20000'
					)
				),
			)
		) );
	}
}
