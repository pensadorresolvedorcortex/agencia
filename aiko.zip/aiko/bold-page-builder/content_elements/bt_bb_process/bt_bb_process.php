<?php
class bt_bb_process extends BT_BB_Element {

	function handle_shortcode( $atts, $content ) {
		extract( shortcode_atts( apply_filters( 'bt_bb_extract_atts_' . $this->shortcode, array(
			'show_steps'				=> '',
			'icon_color_scheme'			=> '',
			'close_items_initially'		=> 'no',
			'title_font_weight'			=> ''
		) ), $atts, $this->shortcode ) );
		
		$class = array( $this->shortcode );
		$data_override_class = array();
		
		if ( $el_class != '' ) {
			$class[] = $el_class;
		}
		
		$id_attr = '';
		if ( $el_id != '' ) {
			$id_attr = ' ' . 'id="' . esc_attr( $el_id ) . '"';
		}

		if ( $show_steps != '' ) {
			$class[] = $this->prefix . 'show_steps' . '_' . $show_steps;
		}

		if ( $title_font_weight != '' ) {
			$class[] = $this->prefix . 'title_font_weight' . '_' . $title_font_weight;
		}

		$icon_color_scheme_id = NULL;
		if ( is_numeric ( $icon_color_scheme ) ) {
			$icon_color_scheme_id = $icon_color_scheme;
		} else if ( $icon_color_scheme != '' ) {
			$icon_color_scheme_id = bt_bb_get_color_scheme_id( $icon_color_scheme );
		}
		$icon_color_scheme_colors = bt_bb_get_color_scheme_colors_by_id( $icon_color_scheme_id - 1 );
		if ( $icon_color_scheme_colors ) $el_style .= '; --process-icon-primary-color:' . $icon_color_scheme_colors[0] . '; --process-icon-secondary-color:' . $icon_color_scheme_colors[1] . ';';
		if ( $icon_color_scheme != '' ) $class[] = $this->prefix . 'icon_color_scheme_' .  $icon_color_scheme_id;
		
		if ( $close_items_initially != '' ) {
			$class[] = $this->prefix . 'close_items_initially';
		}
		
		$style_attr = '';
		if ( $el_style != '' ) {
			$style_attr = ' ' . 'style="' . esc_attr( $el_style ) . '"';
		}
		
		$class = apply_filters( $this->shortcode . '_class', $class, $atts );
		
		$data_attr = '';
		if ( $close_items_initially == 'close_items_initially' ) {
			$data_attr = ' ' . 'data-closed=closed';
		}
		
		$content = do_shortcode( $content );
		
		$step_count = $this->get_count_process_step( $content, 'bt_bb_process_step_item_count' );
		
		$output = '<div' . $id_attr . ' class="' . implode( ' ', $class ) . '"' . $style_attr . $data_attr . ' data-slides="' . esc_attr(  $step_count ) . '" data-bt-override-class="' . htmlspecialchars( json_encode( $data_override_class, JSON_FORCE_OBJECT ), ENT_QUOTES, 'UTF-8' ) . '">' . $content . '</div>';
		
		$output = apply_filters( 'bt_bb_general_output', $output, $atts );
		$output = apply_filters( $this->shortcode . '_output', $output, $atts );
		
		return $output;
		
	}
	
	static function get_count_process_step( $content, $needle ) {
		$offset = 0;
		$allpos = array();
		while (($pos = mb_strpos($content, $needle, $offset)) !== FALSE) {
			$offset   = $pos + 1;
			$allpos[] = $pos;
		}
		return count($allpos);
	}
	
	function map_shortcode() {
		
		require_once( WP_PLUGIN_DIR   .  '/bold-page-builder/content_elements_misc/misc.php' );
		$color_scheme_arr = bt_bb_get_color_scheme_param_array();
		
		bt_bb_map( $this->shortcode, array( 'name' => esc_html__( 'Process', 'aiko' ), 'description' => esc_html__( 'Process with title, icons and text', 'aiko' ), 'container' => 'vertical', 
			'auto_add' => 'bt_bb_process_step', 'accept' => array( 'bt_bb_process_step' => true ), 'icon' => $this->prefix_backend . 'icon' . '_' . $this->shortcode,
			'params' => array( 
				array( 'param_name' => 'show_steps', 'type' => 'dropdown', 'heading' => esc_html__( 'How many steps to show', 'aiko' ), 'description' => esc_html__( 'Only applicable on horizontal process element.', 'aiko' ), 
					'value' => array(
						esc_html__( '2', 'aiko' ) 	=> '2',
						esc_html__( '3', 'aiko' ) 	=> '3',
						esc_html__( '4', 'aiko' ) 	=> '4',
						esc_html__( '5', 'aiko' ) 	=> '5',
						esc_html__( '6', 'aiko' ) 	=> '6'
					)
				),
				array( 'param_name' => 'icon_color_scheme', 'type' => 'dropdown', 'heading' => esc_html__( 'Icon Color Scheme', 'aiko' ), 'value' => $color_scheme_arr, 'preview' => true ),
				array( 'param_name' => 'close_items_initially', 'type' => 'checkbox', 'value' => array( esc_html__( 'Yes', 'aiko' ) => 'close_items_initially' ), 'heading' => esc_html__( 'Close all items initially', 'aiko' ), 'preview' => true 
				),
				array( 'param_name' => 'title_font_weight', 'type' => 'dropdown', 'heading' => esc_html__( 'Title font weight', 'aiko' ),  
					'value' => array(
						esc_html__( 'Default', 'aiko' ) 		=> '',
						esc_html__( 'Normal', 'aiko' ) 		=> 'normal',
						esc_html__( 'Bold', 'aiko' ) 		=> 'bold',
						esc_html__( 'Bolder', 'aiko' ) 		=> 'bolder',
						esc_html__( 'Lighter', 'aiko' ) 		=> 'lighter',
						esc_html__( 'Light', 'aiko' ) 		=> 'light',
						esc_html__( 'Thin', 'aiko' ) 		=> 'thin',
						esc_html__( '100', 'aiko' ) 			=> '100',
						esc_html__( '200', 'aiko' ) 			=> '200',
						esc_html__( '300', 'aiko' ) 			=> '300',
						esc_html__( '400', 'aiko' ) 			=> '400',
						esc_html__( '500', 'aiko' ) 			=> '500',
						esc_html__( '600', 'aiko' ) 			=> '600',
						esc_html__( '700', 'aiko' ) 			=> '700',
						esc_html__( '800', 'aiko' ) 			=> '800',
						esc_html__( '900', 'aiko' ) 			=> '900'
					)
				),
			)
		) );
	}
}

