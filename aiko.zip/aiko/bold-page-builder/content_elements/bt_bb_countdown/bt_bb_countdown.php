<?php

class bt_bb_countdown extends BT_BB_Element {

	function handle_shortcode( $atts, $content ) {
		
		extract( shortcode_atts( apply_filters( 'bt_bb_extract_atts_' . $this->shortcode, array(
			'datetime'        => '',
			'size'            => '',
			'hide_indication' => ''
		) ), $atts, $this->shortcode ) );

		$class = array( $this->shortcode, 'btCounterHolder' );
		$data_override_class = array();

		if ( $el_class != '' ) {
			$class[] = $el_class;
		}

		$id_attr = '';
		if ( $el_id != '' ) {
			$id_attr = ' ' . 'id="' . esc_attr( $el_id ) . '"';
		}

		$style_attr = '';
		$el_style = apply_filters( $this->shortcode . '_style', $el_style, $atts );
		if ( $el_style != '' ) {
			$style_attr = ' ' . 'style="' . esc_attr( $el_style ) . '"';
		}
		
		if ( $size == 'btCounterLargeSize' ) $size = 'large';
		else if ( $size == 'btCounterNormalSize' ) $size = 'normal';

		if ( $hide_indication == 'yes' ) {
			$class[] = 'bt_bb_hide_indication';
		}
		
		$this->responsive_data_override_class(
			$class, $data_override_class,
			array(
				'prefix' => $this->prefix,
				'param' => 'size',
				'value' => $size
			)
		);

		$datetime = sanitize_text_field( $datetime );

		$target = strtotime( $datetime );
		$now = strtotime( 'now' );
		
		$init_seconds = $target - $now;
		if ( $init_seconds < 0 ) {
			$init_seconds = 0;
		}
		
		$d_text = esc_html__( 'Days', 'aiko' );
		$h_text = esc_html__( 'Hours', 'aiko' );
		$m_text = esc_html__( 'Minutes', 'aiko' );
		$s_text = esc_html__( 'Seconds', 'aiko' );
		
		if ( $hide_indication == 'yes' ) {
			$d_text = '';
			$h_text = '';
			$m_text = '';
			$s_text = '';
		}

		do_action( $this->shortcode . '_before_extra_responsive_param' );
		foreach ( $this->extra_responsive_data_override_param as $p ) {
			if ( ! is_array( $atts ) || ! array_key_exists( $p, $atts ) ) continue;
			$this->responsive_data_override_class(
				$class, $data_override_class,
				apply_filters( $this->shortcode . '_responsive_data_override', array(
					'prefix' => $this->prefix,
					'param' => $p,
					'value' => $atts[ $p ],
				) )
			);
		}

		$class = apply_filters( $this->shortcode . '_class', $class, $atts );		

		$output = '<div' . $id_attr . ' class="' . implode( ' ', $class ) . '"' . $style_attr . ' data-bt-override-class="' . htmlspecialchars( json_encode( $data_override_class, JSON_FORCE_OBJECT ), ENT_QUOTES, 'UTF-8' ) . '">';
			$output .= '<div class="btCountdownHolder" data-init-seconds="' . esc_attr( $init_seconds ) . '" data-init-target-seconds="' . esc_attr( $target ) . '">';
							
				$output .= '<span class="days" data-text="' . esc_attr( $d_text ) . '"></span>';
				
				$output .= '<span class="hours">
								<span class="hours_text">
									<span>' . $h_text . '</span>
								</span>
								<span class="n0">
									<span></span>
									<span></span>
								</span>

								<span class="n1">
									<span></span>
									<span></span>
								</span>
								
							</span>';
				
				$output .= '<span class="minutes">
								<span class="minutes_text">
									<span>' . $m_text . '</span>
								</span>
								<span class="n0">
									<span></span>
									<span></span>
								</span>

								<span class="n1">
									<span></span>
									<span></span>
								</span>
								
							</span>';
				
				$output .= '<span class="seconds">
								<span class="seconds_text">
									<span>' . $s_text . '</span>
								</span>
								<span class="n0">
									<span></span>
									<span></span>
								</span>

								<span class="n1">
									<span></span>
									<span></span>
								</span>

							</span>';
			$output .= '</div>';
		$output .= '</div>';
		
		$output = apply_filters( 'bt_bb_general_output', $output, $atts );
		$output = apply_filters( $this->shortcode . '_output', $output, $atts );		

		return $output;
	}

	function map_shortcode() {

		bt_bb_map( $this->shortcode, array( 'name' => esc_html__( 'Countdown', 'aiko' ), 'description' => esc_html__( 'Animated countdown', 'aiko' ),  
			'icon' => $this->prefix_backend . 'icon' . '_' . $this->shortcode,
			'params' => array(
				array( 'param_name' => 'datetime', 'type' => 'textfield', 'heading' => esc_html__( 'Target date and time', 'aiko' ), 'placeholder' => esc_html__( 'YY-mm-dd HH:mm:ss', 'aiko' ), 'description' => esc_html__( 'YY-mm-dd HH:mm:ss, e.g. 2024-02-22 22:45:00', 'aiko' ), 'preview' => true ),
				array( 'param_name' => 'size', 'type' => 'dropdown', 'heading' => esc_html__( 'Size', 'aiko' ), 'preview' => true, 'responsive_override' => true,
					'value' => array(
						esc_html__( 'Normal', 'aiko' ) 	=> 'normal',
						esc_html__( 'Large', 'aiko' ) 	=> 'large'
				) ),
				array( 'param_name' => 'hide_indication', 'type' => 'dropdown', 'heading' => esc_html__( 'Hide indication', 'aiko' ), 'description' => esc_html__( 'Hide indication of days, hours, minutes and seconds', 'aiko' ),
					'value' => array(
						esc_html__( 'No', 'aiko' ) 	=> 'no',
						esc_html__( 'Yes', 'aiko' ) 	=> 'yes'
				) )
			) 
		) );

	}
}