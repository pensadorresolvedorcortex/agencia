<?php
class bt_bb_progress_bar_advanced extends BT_BB_Element {

	function handle_shortcode( $atts, $content ) {
		extract( shortcode_atts( apply_filters( 'bt_bb_extract_atts', array(
			'type'        		=> '',
			'percentage'        => '',
			'duration'        	=> '',
			'easing'        	=> '',
			'progress_text'     => '',
			'progress_text_position'     => '',
			'text'        		=> '',
			'url'				=> '',
			'target'			=> '',
			'size'        		=> '',
			'thickness'			=> '',
			'trail_thickness'	=> '',
			'color_from' 		=> '',
			'color_to' 			=> '',
			'trail_color'       => '',
			'fill_color'		=> '',
			'transparent'       => '',
			'progress_text_color' 	=> '',
			'text_below_color' 		=> '',
			'font_weight' 			=> '',
			'font'          		=> '',
			'font_subset'   		=> '',

			'gradient_color_from' 		=> '',
			'gradient_color_to' 		=> '',
			'progress_shape' 		=> ''
			
		) ), $atts, $this->shortcode ) );

		$pb_id = rand(1000, 100000);

		$content_elements_path = get_parent_theme_file_uri( 'bold-page-builder/content_elements/bt_bb_progress_bar_advanced/' );
		$content_elements_misc_path_js = get_parent_theme_file_uri( 'bold-page-builder/content_elements_misc/js/' );

		wp_enqueue_script( 
			'bt_bb_progressbar_advanced_js',
			$content_elements_path . 'bb_progressbar_advanced.js',
			array( 'jquery' ),
			'',
			true
		);

		wp_enqueue_script( 
			'bt_bb_progressbar_advanced',
			$content_elements_misc_path_js . 'bt_bb_progress_bar_advanced.js',
			array( 'jquery' ),
			'',
			true
		);

		$class = array( $this->shortcode );

		$class[] = 'animate-adv_progressbar';

		if ( $font != '' && $font != 'inherit' ) {
			require_once( WP_PLUGIN_DIR   . '/bold-page-builder/content_elements_misc/misc.php' );
			bt_bb_enqueue_google_font( $font, $font_subset );
			$class[] = 'bt_bb_has_font';
		}
		
		if ( $el_class != '' ) {
			$class[] = $el_class;
		}

		if ( $transparent != '' ) {
			$class[] = $this->prefix . 'trail_transparent';
		}

		$id_attr = '';
		if ( $el_id != '' ) {
			$id_attr = ' ' . 'id="' . esc_attr( $el_id ) . '"';
		}

		$style_attr = '';
		if ( $el_style != '' ) {
			$style_attr = ' ' . 'style="' . esc_attr( $el_style ) . '"';
		}
		
		if ( $type != '' ) {
			$class[] = $this->prefix . 'type' . '_' . $type;
		}

		if ( $progress_text_position != '' ) {
			$class[] = $this->prefix . 'progress_text_position' . '_' . $progress_text_position;
		}

		if ( $progress_shape != '' ) {
			$class[] = $this->prefix . 'progress_shape' . '_' . $progress_shape;
		}

		if ( $size != '' ) {
			$class[] = $this->prefix . 'size' . '_' . $size;
		}

		if ( $font_weight != '' ) {
			$class[] = $this->prefix . 'font_weight' . '_' . $font_weight;
		}

		if ( $progress_text_color != '' ) {
			$class[] = $this->prefix . 'progress_text_color' . '_' . $progress_text_color;
		}

		if ( $text_below_color != '' ) {
			$class[] = $this->prefix . 'text_below_color' . '_' . $text_below_color;
		}

		$el_title_style = '';
		if ( $font != '' && $font != 'inherit' ) {
			$el_title_style = $el_title_style . ';' . 'font-family:\'' . urldecode( $font ) . '\'';
		}

		$title_style_attr = '';
		$el_title_style = apply_filters( $this->shortcode . '_style', $el_title_style, $atts );
		if ( $el_title_style != '' ) {
			$title_style_attr = ' ' . 'style="' . esc_attr( $el_title_style ) . '"';
		}
		
		if ( $percentage == '' ) {
			$percentage = 100;
		}

		if ( $fill_color != '' ) {
			if ( strpos( $fill_color, '#' ) !== false ) {
				$fill_color = $this->hex2rgba($fill_color, 0.5);
			}
		}
		
		$container				= 'container_' . $pb_id;
		$container_text			= $text;
		$container_percentage	= $percentage / 100;
		$container_duration		= ( $duration == '' ) ? '1400' : $duration;	
		$container_easing		= ( $easing == '') ? 'linear' : $easing;
		
		$container_color_from	= ( $color_from == '') ? '#eee' : $color_from;
		$container_color_to		= ( $color_to == '') ? '#000' : $color_to;
		$container_trail_color	= ( $trail_color == '') ? '#eee' : $trail_color;
		$container_fill			= ( $fill_color) ? $fill_color : null;

		$container_gradient_color_from	= ( $gradient_color_from == '') ? '#eee' : $gradient_color_from;
		$container_gradient_color_to	= ( $gradient_color_to == '') ? '#eee' : $gradient_color_to;
		

		if ( $color_to == "" && $color_from != "") {
			$container_color_to = $container_color_from;
		}

		if ( $gradient_color_to == "" && $gradient_color_from != "") {
			$container_gradient_color_to = $container_gradient_color_from;
		}



		switch( $thickness ) {
			case 'small':	$container_depth_from	= 1;	$container_depth_to		= 1;	$container_stroke_width = 1;	$container_trail_width	= 1;break;
			case 'normal':	$container_depth_from	= 3;	$container_depth_to		= 3;	$container_stroke_width = 3;	$container_trail_width	= 3;break;
			case 'medium':	$container_depth_from	= 4;	$container_depth_to		= 4;	$container_stroke_width = 4;	$container_trail_width	= 4;break;
			case 'large':	$container_depth_from	= 6;	$container_depth_to		= 6;	$container_stroke_width = 6;	$container_trail_width	= 6;break;
			case 'xlarge':	$container_depth_from	= 8;	$container_depth_to		= 8;	$container_stroke_width = 8;	$container_trail_width	= 8;break;
			default:break;
		}

		switch( $trail_thickness ) {
			case 'small':	$container_trail_width	= 1;break;
			case 'normal':	$container_trail_width	= 3;break;
			case 'medium':	$container_trail_width	= 4;break;
			case 'large':	$container_trail_width	= 6;break;
			case 'xlarge':	$container_trail_width	= 8;break;
			default:break;
		}

		$link = '';

		if ( $url != '' && $url != '#' && substr( $url, 0, 4 ) != 'http' && substr( $url, 0, 5 ) != 'https' && substr( $url, 0, 6 ) != 'mailto' ) {
			$link = bt_bb_get_permalink_by_slug( $url );
		} else {
			$link = $url;
		}

		if ( $container_color_to == "" ) {
			$container_color_to = $container_color_from;
		}

		if ( $container_gradient_color_to == "" ) {
			$container_gradient_color_to = $container_gradient_color_from;
		}
		
		$content = do_shortcode( $content );
		$data = ' data-container="' . esc_attr( $container ) . '"';
		$data .= ' data-container-pbid="' . esc_attr( $pb_id ) . '"';
		$data .= ' data-container-type="' . esc_attr( $type ) . '"';
		$data .= ' data-container-percentage="' . esc_attr( $container_percentage ) . '"';
		$data .= ' data-container-stroke-width="' . esc_attr( $container_stroke_width ) . '"';
		$data .= ' data-container-trail-color="' . esc_attr( $container_trail_color ) . '"';
		$data .= ' data-container-trail-width="' . esc_attr( $container_trail_width ) . '"';
		$data .= ' data-container-easing="' . esc_attr( $container_easing ) . '"';
		$data .= ' data-container-color-from="' . esc_attr( $container_color_from ) . '"';
		$data .= ' data-container-gradient-color-from="' . esc_attr( $container_gradient_color_from ) . '"';
		$data .= ' data-container-depth-from="' . esc_attr( $container_depth_from ) . '"';
		$data .= ' data-container-color-to="' . esc_attr( $container_color_to ) . '"';
		$data .= ' data-container-gradient-color-to="' . esc_attr( $container_gradient_color_to ) . '"';
		$data .= ' data-container-depth-to="' . esc_attr( $container_depth_to ) . '"';
		$data .= ' data-container-fill="' . esc_attr( $container_fill ) . '"';
		$data .= ' data-container-duration="' . esc_attr( $container_duration ) . '"';
		$data .= ' data-container-text="' . esc_attr( $container_text ) . '"';

		$data .= ' data-container-color-from="' . esc_attr( $container_color_from ) . '"';
		$data .= ' data-container-gradient-color-from="' . esc_attr( $container_gradient_color_from ) . '"';

		$output = '';

		$class = apply_filters( $this->shortcode . '_class', $class, $atts );

		if ( $link != '' ) {
			$target_attr = 'target="_self"';
			if ( $target != '' ) {
				$target_attr = ' ' . 'target="' . ( $target ) . '"';
			}
			$output .= '<a href="' . esc_url( $link ) . '" ' . $target_attr . ' class="' . esc_attr( $this->shortcode . '_link' ) . '">';
		}

		// PROGRESS BAR
		$output .= '<div' . $id_attr . ' class="' . implode( ' ', $class ) . '"' . $style_attr . ' ' . $data . '>';	
			
			$output .= '<div id="' . esc_attr( 'container_' . $pb_id ) . '" class="container">';
				$output .= '<div id="' . esc_attr( 'container_inner_' . $pb_id ) . '" class="container_inner">';

					// PROGRESS TEXT
					if ( $progress_text != '' ) {
						$output .= '<div class="' . esc_attr( $this->shortcode ) . '_bar_text" ' . $title_style_attr . '>' . do_shortcode( '[bt_bb_counter number="' . esc_attr( $progress_text ) . '" size="large" ignore_fe_editor="true"]' ) . '</div>';
					}

					// TEXT BELOW
					if ( $container_text != '' ) {
					$output .= '<div class="' . esc_attr( $this->shortcode . '_bar_container_text' ) . '"><p>' . wp_kses_post( $container_text ) . '</p></div>';
				}

				$output .= '</div>';
			$output .= '</div>';

		$output .= '</div>';

		if ( $link != '' ) {
			$output .= '</a>';
		}

		$output = apply_filters( 'bt_bb_general_output', $output, $atts );
		$output = apply_filters( $this->shortcode . '_output', $output, $atts );
			
		return $output;
	}

	/* Convert hexdec color string to rgb(a) string */ 
	static function hex2rgba($color, $opacity = false) {

		$default = 'rgb(0,0,0)';

		// Return default if no color provided
		if (empty($color))
		return $default; 

		// Sanitize $color if "#" is provided 
		if ($color[0] == '#' ) {
			$color = substr( $color, 1 );
		}

		// Check if color has 6 or 3 characters and get values
		if (strlen($color) == 6) {
			$hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
		} elseif ( strlen( $color ) == 3 ) {
			$hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
		} else {
			return $default;
		}

		// Convert hexadec to rgb
		$rgb =  array_map('hexdec', $hex);

		// Check if opacity is set(rgba or rgb)
		if ($opacity) {
			if (abs($opacity) > 1)
			$opacity = 1.0;
			$output = 'rgba('.implode(",",$rgb).','.$opacity.')';
		} else {
			$output = 'rgb('.implode(",",$rgb).')';
		}

		// Return rgb(a) color string
		return $output;
	}

	function map_shortcode() {

		include( WP_PLUGIN_DIR   . '/bold-page-builder/content_elements_misc/fonts.php' );
		
		require_once( WP_PLUGIN_DIR   . '/bold-page-builder/content_elements_misc/misc.php' );
		
		bt_bb_map( $this->shortcode, array( 'name' => esc_html__( 'Advanced Progress Bar', 'aiko' ), 'description' => esc_html__( 'Advanced Progress Bar', 'aiko' ), 'icon' => $this->prefix_backend . 'icon' . '_' . $this->shortcode,
			'params' => array(
				array( 'param_name' => 'percentage', 'type' => 'textfield', 'heading' => esc_html__( 'Percentage', 'aiko' ), 'preview' => true ),
				array( 'param_name' => 'progress_text', 'type' => 'textfield', 'heading' => esc_html__( 'Title', 'aiko' ), 'preview' => true ),
				array( 'param_name' => 'text', 'type' => 'textfield', 'heading' => esc_html__( 'Text', 'aiko' ), 'preview' => true ),
				array( 'param_name' => 'type', 'type' => 'dropdown', 'heading' => esc_html__( 'Progress bar type', 'aiko' ), 'preview' => true,
					'value' => array(
						esc_html__( 'Semi circle', 'aiko' ) 	=> 'semi-circle',
						esc_html__( 'Circle', 'aiko' ) 		=> 'circle'
					)
				),
				
				array( 'param_name' => 'duration', 'type' => 'textfield', 'heading' => esc_html__( 'Animation duration', 'aiko' ), 'preview' => true ),
						array( 'param_name' => 'easing', 'type' => 'dropdown', 'heading' => esc_html__( 'Easing', 'aiko' ), 'preview' => true,
					'value' => array(
						esc_html__( 'Linear', 'aiko' ) 			=> 'linear',
						esc_html__( 'Ease In Out', 'aiko' ) 		=> 'easeInOut',
						esc_html__( 'Bounce', 'aiko' ) 			=> 'bounce'
					)
				),
				
				array( 'param_name' => 'progress_text_position', 'type' => 'dropdown', 'heading' => esc_html__( 'Title position', 'aiko' ), 
					'value' => array(
						esc_html__( 'Inside progress bar', 'aiko' ) 			=> '',
						esc_html__( 'Next to progress bar', 'aiko' ) 		=> 'next'
					)
				),
				
				array( 'param_name' => 'url', 'type' => 'link', 'heading' => esc_html__( 'URL', 'aiko' ), 'preview' => true, 'description' => esc_html__( 'Enter full or local URL (e.g. https://www.bold-themes.com or /pages/about-us), post slug (e.g. about-us).', 'aiko' ), 'group' => esc_html__( 'URL', 'aiko' ) ),
				array( 'param_name' => 'target', 'type' => 'dropdown', 'group' => esc_html__( 'URL', 'aiko' ), 'heading' => esc_html__( 'Target', 'aiko' ),
					'value' => array(
						esc_html__( 'Self (open in same tab)', 'aiko' ) 	=> '_self',
						esc_html__( 'Blank (open in new tab)', 'aiko' ) 	=> '_blank',
					)
				),

				array( 'param_name' => 'size', 'type' => 'dropdown', 'heading' => esc_html__( 'Size', 'aiko' ), 'preview' => true, 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Small', 'aiko' ) 		=> 'small',
						esc_html__( 'Normal', 'aiko' ) 		=> 'normal',
						esc_html__( 'Medium', 'aiko' ) 		=> 'medium',
						esc_html__( 'Large', 'aiko' ) 		=> 'large'
					)
				),
				array( 'param_name' => 'progress_shape', 'type' => 'dropdown', 'heading' => esc_html__( 'Shape', 'aiko' ), 'preview' => true, 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Inherit', 'aiko' ) 		=> '',
						esc_html__( 'Rounded corners', 'aiko' ) 	=> 'rounded'
					)
				),
				array( 'param_name' => 'thickness', 'type' => 'dropdown', 'heading' => esc_html__( 'Thickness', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Small', 'aiko' ) 			=> 'small',
						esc_html__( 'Normal', 'aiko' ) 			=> 'normal',
						esc_html__( 'Medium', 'aiko' ) 			=> 'medium',
						esc_html__( 'Large', 'aiko' ) 			=> 'large',
						esc_html__( 'Extra large', 'aiko' ) 		=> 'xlarge'
					)
				),
				array( 'param_name' => 'trail_thickness', 'type' => 'dropdown', 'heading' => esc_html__( 'Trail thickness', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Same as progress bar', 'aiko' ) => 'progressbar',
						esc_html__( 'Small', 'aiko' ) 				=> 'small',
						esc_html__( 'Normal', 'aiko' ) 				=> 'normal',
						esc_html__( 'Medium', 'aiko' ) 				=> 'medium',
						esc_html__( 'Large', 'aiko' ) 				=> 'large',
						esc_html__( 'Extra large', 'aiko' ) 			=> 'xlarge'
					)
				),
				array( 'param_name' => 'color_from', 'type' => 'colorpicker', 'heading' => esc_html__( 'Starting progress bar background color', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ) ),
				array( 'param_name' => 'color_to', 'type' => 'colorpicker', 'heading' => esc_html__( 'Ending progress bar background color', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ) ),

				array( 'param_name' => 'gradient_color_from', 'type' => 'colorpicker', 'heading' => esc_html__( 'Gradient start color', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ) ),
				array( 'param_name' => 'gradient_color_to', 'type' => 'colorpicker', 'heading' => esc_html__( 'Gradient end color', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ) ),
				
				
				array( 'param_name' => 'trail_color', 'type' => 'colorpicker', 'heading' => esc_html__( 'Color for lighter trail stroke underneath the actual progress path', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ) ),
				
				array( 'param_name' => 'fill_color', 'type' => 'colorpicker', 'heading' => esc_html__( 'Fill color', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ) ),
				
				array( 'param_name' => 'transparent', 'type' => 'checkbox', 'value' => array( esc_html__( 'Yes', 'aiko' ) => 'show_transparent_trail' ), 'heading' => esc_html__( 'Show trail as semi transparent', 'aiko' ), 'description' => esc_html__( 'Makes the progress bar trail semi transparent, at opacity od 10%.', 'aiko' ), 'preview' => true, 'group' => esc_html__( 'Design', 'aiko' ) ),
				
				
				array( 'param_name' => 'progress_text_color', 'type' => 'dropdown', 'heading' => esc_html__( 'Title color', 'aiko' ), 'group' => esc_html__( 'Content', 'aiko' ),
					'value' => array(
						esc_html__( 'Inherit', 'aiko' ) 					=> '',
						esc_html__( 'Gray color', 'aiko' ) 				=> 'gray',
						esc_html__( 'Accent color', 'aiko' ) 			=> 'accent',
						esc_html__( 'Alternate color', 'aiko' ) 			=> 'alternate',
						esc_html__( 'Light color', 'aiko' ) 				=> 'light',
						esc_html__( 'Dark color', 'aiko' ) 				=> 'dark'
					)
				),
				array( 'param_name' => 'font_weight', 'type' => 'dropdown', 'heading' => esc_html__( 'Title font weight', 'aiko' ), 'group' => esc_html__( 'Content', 'aiko' ), 
					'value' => array(
						esc_html__( 'Default', 'aiko' ) 		=> '',
						esc_html__( 'Normal', 'aiko' ) 		=> 'normal',
						esc_html__( 'Bold', 'aiko' ) 		=> 'bold',
						esc_html__( 'Bolder', 'aiko' ) 		=> 'bolder',
						esc_html__( 'Lighter', 'aiko' ) 		=> 'lighter',
						esc_html__( 'Light', 'aiko' ) 		=> 'light',
						esc_html__( 'Thin', 'aiko' ) 		=> 'thin',
						esc_html__( '100', 'aiko' ) 			=> '100',
						esc_html__( '200', 'aiko' ) 			=> '200',
						esc_html__( '300', 'aiko' ) 			=> '300',
						esc_html__( '400', 'aiko' ) 			=> '400',
						esc_html__( '500', 'aiko' ) 			=> '500',
						esc_html__( '600', 'aiko' ) 			=> '600',
						esc_html__( '700', 'aiko' ) 			=> '700',
						esc_html__( '800', 'aiko' ) 			=> '800',
						esc_html__( '900', 'aiko' ) 			=> '900'
					)
				),
				array( 'param_name' => 'text_below_color', 'type' => 'dropdown', 'heading' => esc_html__( 'Text color', 'aiko' ), 'group' => esc_html__( 'Content', 'aiko' ),
					'value' => array(
						esc_html__( 'Inherit', 'aiko' ) 					=> '',
						esc_html__( 'Gray color', 'aiko' ) 				=> 'gray',
						esc_html__( 'Accent color', 'aiko' ) 			=> 'accent',
						esc_html__( 'Alternate color', 'aiko' ) 			=> 'alternate',
						esc_html__( 'Light color', 'aiko' ) 				=> 'light',
						esc_html__( 'Dark color', 'aiko' ) 				=> 'dark'
					)
				),
				array( 'param_name' => 'font', 'type' => 'dropdown', 'group' => esc_html__( 'Content', 'aiko' ), 'heading' => esc_html__( 'Title font', 'aiko' ), 'preview' => true,
					'value' => array( esc_html__( 'Inherit', 'aiko' ) => 'inherit' ) + $font_arr
				),
				array( 'param_name' => 'font_subset', 'type' => 'textfield', 'group' => esc_html__( 'Content', 'aiko' ), 'heading' => esc_html__( 'Title font subset', 'aiko' ), 'value' => 'latin,latin-ext', 'description' => esc_html__( 'E.g. latin,latin-ext,cyrillic,cyrillic-ext', 'aiko' ) ),
			)
		) );
	}
}

