<?php

class bt_bb_service extends BT_BB_Element {

	function handle_shortcode( $atts, $content ) {
		extract( shortcode_atts( apply_filters( 'bt_bb_extract_atts_' . $this->shortcode, array(
			'icon'              => '',
			'title'             => '',
			'text'              => '',
			'url'               => '',
			'target'            => '',
			'color_scheme'      => '',
			'style'             => '',
			'size'              => '',
			'shape'             => '',
			'align'             => '',
			'text_color'        => '',
			'align_content'     => '',
			'title_size'	    => '',
			'letter_spacing'    => '',
			'title_font_weight' => '',
			'font'          	=> '',
			'font_subset'   	=> ''
		) ), $atts, $this->shortcode ) );

		$class = array( $this->shortcode );
		$data_override_class = array();

		if ( $font != '' && $font != 'inherit' ) {
			require_once( WP_PLUGIN_DIR   . '/bold-page-builder/content_elements_misc/misc.php' );
			bt_bb_enqueue_google_font( $font, $font_subset );
		}

		if ( $el_class != '' ) {
			$class[] = $el_class;
		}

		$id_attr = '';
		if ( $el_id != '' ) {
			$id_attr = ' ' . 'id="' . esc_attr( $el_id ) . '"';
		}
		
		$color_scheme_id = NULL;
		if ( is_numeric ( $color_scheme ) ) {
			$color_scheme_id = $color_scheme;
		} else if ( $color_scheme != '' ) {
			$color_scheme_id = bt_bb_get_color_scheme_id( $color_scheme );
		}
		$color_scheme_colors = bt_bb_get_color_scheme_colors_by_id( $color_scheme_id - 1 );
		if ( $color_scheme_colors ) $el_style .= '; --primary-color:' . $color_scheme_colors[0] . '; --secondary-color:' . $color_scheme_colors[1] . ';';
		if ( $color_scheme != '' ) $class[] = $this->prefix . 'color_scheme_' .  $color_scheme_id;

		if ( $text == '' ) {
			$class[] = 'btNoText';
		}

		if ( $title == '' ) {
			$class[] = 'btNoTitle';
		}	

		if ( $style != '' ) {
			$class[] = $this->prefix . 'style' . '_' . $style;
		}

		if ( $align_content != '' ) {
			$class[] = $this->prefix . 'align_content' . '_' . $align_content;
		}

		if ( $title_size != '' ) {
			$class[] = $this->prefix . 'title_size' . '_' . $title_size;
		}

		if ( $title_font_weight != '' ) {
			$class[] = $this->prefix . 'title_font_weight' . '_' . $title_font_weight;
		}

		if ( $letter_spacing != '' ) {
			$class[] = $this->prefix . 'letter_spacing' . '_' . $letter_spacing;
		}

		$el_title_style = '';
		if ( $font != '' && $font != 'inherit' ) {
			$el_title_style = $el_title_style . ';' . 'font-family:\'' . urldecode( $font ) . '\'';
		}

		$this->responsive_data_override_class(
			$class, $data_override_class,
			array(
				'prefix' => $this->prefix,
				'param' => 'size',
				'value' => $size
			)
		);

		if ( $shape != '' ) {
			$class[] = $this->prefix . 'shape' . '_' . $shape;
		}

		if ( $text_color != '' ) {
			$class[] = $this->prefix . 'text_color' . '_' . $text_color;
		}
		
		if ( $target != '' ) {
			$class[] = $this->prefix . 'target' . $target;
		}
		
		if ( $target == '_lightbox' ) {
			$class[] = 'bt_bb_use_lightbox';
			$target = '_blank';
		}

		$this->responsive_data_override_class(
			$class, $data_override_class,
			array(
				'prefix' => $this->prefix,
				'param' => 'align',
				'value' => $align
			)
		);

		$title_style_attr = '';
		$el_title_style = apply_filters( $this->shortcode . '_style', $el_title_style, $atts );
		if ( $el_title_style != '' ) {
			$title_style_attr = ' ' . 'style="' . esc_attr( $el_title_style ) . '"';
		}

		$style_attr = '';
		$el_style = apply_filters( $this->shortcode . '_style', $el_style, $atts );
		if ( $el_style != '' ) {
			$style_attr = ' ' . 'style="' . esc_attr( $el_style ) . '"';
		}
		
		$link = bt_bb_get_url( $url );

		$icon_title = wp_strip_all_tags($title);
		
		$icon = bt_bb_icon::get_html( $icon, '', $link, $icon_title, $target );
		
		foreach ( $this->extra_responsive_data_override_param as $p ) {
			if ( ! is_array( $atts ) || ! array_key_exists( $p, $atts ) ) continue;
			$this->responsive_data_override_class(
				$class, $data_override_class,
				apply_filters( $this->shortcode . '_responsive_data_override', array(
					'prefix' => $this->prefix,
					'param' => $p,
					'value' => $atts[ $p ],
				) )
			);
		}

		$class = apply_filters( $this->shortcode . '_class', $class, $atts );

		$output = $icon;

		if ( $link != '' ) {
			$output .= '<div class="' . esc_attr( $this->shortcode ) . '_content"><a href="' . esc_url( $link ) . '" target="' . esc_attr( $target ) . '">';
				if ( $title != '' ) $output .= '<div class="' . esc_attr( $this->shortcode ) . '_content_title" ' . $title_style_attr . '>' . $title . '</div>';
				if ( $text != '' ) $output .= '<div class="' . esc_attr( $this->shortcode ) . '_content_text">' . nl2br( $text ) . '</div>';
			$output .= '</a></div>';
		} else {
			$output .= '<div class="' . esc_attr( $this->shortcode ) . '_content">';
				if ( $title != '' ) $output .= '<div class="' . esc_attr( $this->shortcode ) . '_content_title" ' . $title_style_attr . '>' . $title . '</div>';
				if ( $text != '' ) $output .= '<div class="' . esc_attr( $this->shortcode ) . '_content_text">' . nl2br( $text ) . '</div>';
			$output .= '</div>';
		}

		$output = '<div' . $id_attr . ' class="' . esc_attr( implode( ' ', $class ) ) . '"' . $style_attr . ' data-bt-override-class="' . htmlspecialchars( json_encode( $data_override_class, JSON_FORCE_OBJECT ), ENT_QUOTES, 'UTF-8' ) . '">' . $output . '</div>';
		
		$output = apply_filters( 'bt_bb_general_output', $output, $atts );
		$output = apply_filters( $this->shortcode . '_output', $output, $atts );

		return $output;

	}

	function map_shortcode() {

		include( WP_PLUGIN_DIR   . '/bold-page-builder/content_elements_misc/fonts.php' );
		
		$color_scheme_arr = bt_bb_get_color_scheme_param_array();

		bt_bb_map( $this->shortcode, array( 'name' => esc_html__( 'Service', 'aiko' ), 'description' => esc_html__( 'Icon with text', 'aiko' ), 'icon' => $this->prefix_backend . 'icon' . '_' . $this->shortcode,
			'params' => array(
				array( 'param_name' => 'icon', 'type' => 'iconpicker', 'heading' => esc_html__( 'Icon', 'aiko' ), 'preview' => true ),
				array( 'param_name' => 'title', 'type' => 'textfield', 'heading' => esc_html__( 'Title', 'aiko' ), 'preview' => true ),
				array( 'param_name' => 'text', 'type' => 'textarea', 'heading' => esc_html__( 'Text', 'aiko' ) ),
				array( 'param_name' => 'align', 'type' => 'dropdown', 'heading' => esc_html__( 'Icon position', 'aiko' ), 'responsive_override' => true,
					'value' => array(
						esc_html__( 'Inherit', 'aiko' ) => 'inherit',
						esc_html__( 'Left', 'aiko' ) => 'left',
						esc_html__( 'Center', 'aiko' ) => 'center',
						esc_html__( 'Right', 'aiko' ) => 'right'
					)
				),
				array( 'param_name' => 'align_content', 'type' => 'dropdown', 'default' => '', 'heading' => esc_html__( 'Content alignment', 'aiko' ), 
					'value' => array(
						esc_html__( 'Top', 'aiko' ) 				=> 'top',
						esc_html__( 'Center', 'aiko' ) 			=> 'center',
						esc_html__( 'Bottom', 'aiko' ) 			=> 'bottom'
					)
				),


				array( 'param_name' => 'url', 'type' => 'link', 'heading' => esc_html__( 'URL', 'aiko' ), 'group' => esc_html__( 'URL', 'aiko' ), 'description' => esc_html__( 'Enter full or local URL (e.g. https://www.bold-themes.com or /pages/about-us) or post slug (e.g. about-us) or search for existing content.', 'aiko' ) ),
				array( 'param_name' => 'target', 'type' => 'dropdown', 'heading' => esc_html__( 'Target', 'aiko' ), 'group' => esc_html__( 'URL', 'aiko' ),
					'value' => array(
						esc_html__( 'Self (open in same tab)', 'aiko' ) => '_self',
						esc_html__( 'Blank (open in new tab)', 'aiko' ) => '_blank',
						esc_html__( 'Lightbox (open in new layer)', 'aiko' ) => '_lightbox',
					)
				),


				array( 'param_name' => 'size', 'type' => 'dropdown', 'heading' => esc_html__( 'Icon size', 'aiko' ), 'responsive_override' => true, 'preview' => true, 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Extra small', 'aiko' ) => 'xsmall',
						esc_html__( 'Small', 'aiko' ) => 'small',
						esc_html__( 'Normal', 'aiko' ) => 'normal',
						esc_html__( 'Large', 'aiko' ) => 'large',
						esc_html__( 'Extra large', 'aiko' ) => 'xlarge'
					)
				),
				array( 'param_name' => 'color_scheme', 'type' => 'dropdown', 'heading' => esc_html__( 'Color scheme', 'aiko' ), 'description' => esc_html__( 'Define color schemes in Bold Builder settings or define accent and alternate colors in theme customizer (if avaliable)', 'aiko' ), 'value' => $color_scheme_arr, 'preview' => true, 'group' => esc_html__( 'Design', 'aiko' ) ),
				array( 'param_name' => 'style', 'type' => 'dropdown', 'heading' => esc_html__( 'Icon style', 'aiko' ), 'preview' => true, 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Outline', 'aiko' ) => 'outline',
						esc_html__( 'Filled', 'aiko' ) => 'filled',
						esc_html__( 'Borderless', 'aiko' ) => 'borderless'
					)
				),
				array( 'param_name' => 'shape', 'type' => 'dropdown', 'heading' => esc_html__( 'Icon shape', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Circle', 'aiko' ) => 'circle',
						esc_html__( 'Square', 'aiko' ) => 'square',
						esc_html__( 'Rounded Square', 'aiko' ) => 'round'
					)
				),
				array( 'param_name' => 'text_color', 'type' => 'dropdown', 'heading' => esc_html__( 'Text color', 'aiko' ), 'group' => esc_html__( 'Design', 'aiko' ),
					'value' => array(
						esc_html__( 'Inherit', 'aiko' ) 				=> '',
						esc_html__( 'Gray color', 'aiko' ) 			=> 'gray',
						esc_html__( 'Dark color', 'aiko' ) 			=> 'dark',
						esc_html__( 'Light color', 'aiko' ) 			=> 'light',
						esc_html__( 'Accent color', 'aiko' ) 		=> 'accent',
						esc_html__( 'Alternate color', 'aiko' ) 		=> 'alternate'
					)
				),


				array( 'param_name' => 'title_size', 'type' => 'dropdown', 'default' => 'small', 'heading' => esc_html__( 'Title size', 'aiko' ), 'group' => esc_html__( 'Title', 'aiko' ),
					'value' => array(
						esc_html__( 'Default', 'aiko' ) 			=> '',
						esc_html__( 'Extra small', 'aiko' ) 		=> 'extrasmall',
						esc_html__( 'Small', 'aiko' ) 			=> 'small',
						esc_html__( 'Normal', 'aiko' ) 			=> 'normal',
						esc_html__( 'Large', 'aiko' ) 			=> 'large',
						esc_html__( 'Extra large', 'aiko' ) 		=> 'extralarge',
						esc_html__( 'Huge', 'aiko' ) 			=> 'huge'
					)
				),
				array( 'param_name' => 'letter_spacing', 'type' => 'dropdown', 'default' => '', 'heading' => esc_html__( 'Title letter spacing', 'aiko' ), 'group' => esc_html__( 'Title', 'aiko' ),
					'value' => array(
						esc_html__( 'Default', 'aiko' ) 			=> '',
						esc_html__( '1px', 'aiko' ) 				=> '1px',
						esc_html__( '2px', 'aiko' ) 				=> '2px',
						esc_html__( '3px', 'aiko' ) 				=> '3px',
						esc_html__( '4px', 'aiko' ) 				=> '4px',
						esc_html__( '5px', 'aiko' ) 				=> '5px',
						esc_html__( '6px', 'aiko' ) 				=> '6px'
					)
				),
				array( 'param_name' => 'title_font_weight', 'type' => 'dropdown', 'heading' => esc_html__( 'Title font weight', 'aiko' ), 'group' => esc_html__( 'Title', 'aiko' ), 
					'value' => array(
						esc_html__( 'Default', 'aiko' ) 		=> '',
						esc_html__( 'Normal', 'aiko' ) 		=> 'normal',
						esc_html__( 'Bold', 'aiko' ) 		=> 'bold',
						esc_html__( 'Bolder', 'aiko' ) 		=> 'bolder',
						esc_html__( 'Lighter', 'aiko' ) 		=> 'lighter',
						esc_html__( 'Light', 'aiko' ) 		=> 'light',
						esc_html__( 'Thin', 'aiko' ) 		=> 'thin',
						esc_html__( '100', 'aiko' ) 			=> '100',
						esc_html__( '200', 'aiko' ) 			=> '200',
						esc_html__( '300', 'aiko' ) 			=> '300',
						esc_html__( '400', 'aiko' ) 			=> '400',
						esc_html__( '500', 'aiko' ) 			=> '500',
						esc_html__( '600', 'aiko' ) 			=> '600',
						esc_html__( '700', 'aiko' ) 			=> '700',
						esc_html__( '800', 'aiko' ) 			=> '800',
						esc_html__( '900', 'aiko' ) 			=> '900'
					)
				),
				array( 'param_name' => 'font', 'type' => 'dropdown', 'group' => esc_html__( 'Title', 'aiko' ), 'heading' => esc_html__( 'Title font', 'aiko' ), 'preview' => true,
					'value' => array( esc_html__( 'Inherit', 'aiko' ) => 'inherit' ) + $font_arr
				),
				array( 'param_name' => 'font_subset', 'type' => 'textfield', 'group' => esc_html__( 'Title', 'aiko' ), 'heading' => esc_html__( 'Title font subset', 'aiko' ), 'value' => 'latin,latin-ext', 'description' => esc_html__( 'E.g. latin,latin-ext,cyrillic,cyrillic-ext', 'aiko' ) ),
			)
		) );
	}
}